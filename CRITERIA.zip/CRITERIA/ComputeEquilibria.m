% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    CRITERIA (Computing paRametrized posITive EquilibRIA)                  %
%                                                                           %
%    Main Function: ComputeEquilibria                                       %
%                                                                           %
%                                                                           %
% OUTPUT: Returns the analytic equilibria of a chemical reaction network    %
%    (CRN) parametrized by rate constants and free parameters (sigma), if   %
%    any. The system's conservation laws are also listed after the          %  
%    solution. The output variables 'equation', 'species',                  %
%    'free_parameter', 'conservation_law', and 'model' allow the user to    % 
%    view the following, respectively:                                      %
%       - List of parametrization of the steady state of the system         %
%       - List of steady state species of the network                       %
%       - List of free parameters of the steady state                       %
%       - List of conservation laws of the system                           %
%       - Complete network with all the species listed in the 'species'     %
%            field of the structure 'model'                                 %
%    Finally, the elapsed time for producing the output is also displayed   % 
%    using MATLAB's built-in tic and toc functions.                         %
%                                                                           %
% INPUT: model: a structure, representing the CRN (see README.txt for       %
%    details on how to fill out the structure)                              %
%                                                                           %
% Notes:                                                                    %    
%    1. CRITERIA builds on COMPILES [5] by improving its performance.       %
%    2. It is assumed that the CRN has mass action kinetics.                %
%    3. The algorithm first decomposes the network into its finest          %
%          independent decomposition. The subnetworks are then translated   % 
%          into becoming weakly reversible and deficiency zero. Then the    %
%          subnetworks are merged to form one whole network, and finally    %
%          the equilibria of the entire system is solved.                   %
%    3. Decomposition into the finest independent decomposition comes from  %
%          [2].                                                             %
%    4. Translation of network comes from [3].                              %
%    5. Parametrization of steady state solution comes from [4].            %
%    6. Computation of directed spanning trees toward vertices come from    %
%          [1].                                                             %
%                                                                           %
% References                                                                %
%    [1] Gabow H and Meyers E (1978) Finding all spanning trees of directed %
%           and undirected graphs. SIAM J Comput 7(3):280-287.              %
%           https://doi.org/10.1137/0207024                                 %
%    [2] Hernandez B, De la Cruz R (2021) Independent decompositions of     %
%           chemical reaction networks. Bull Math Biol 83(76):1–23.         %
%           https://doi.org/10.1007/s11538-021-00906-3                      %
%    [3] Johnston MD, Burton E (2019) Computing weakly reversible           % 
%           deficiency zero network translations using elementary flux      %
%           modes Bull Math Biol 81:1613–1644.                              %                 
%    [4] Johnston M, Mueller S, Pantea C (2019) A deficiency-based approach %
%           to parametrizing positive equilibria of biochemical reaction    %
%           systems. Bull Math Biol 81:1143–1172.                           %
%           https://doi.org/10.1007/s11538-018-00562-0                      %                  
%    [5] Hernandez BS, Lubenia PVN, Johnston MD, Kim JK (2023) A framework  % 
%           for deriving analytic steady states of biochemical reaction     %
%           networks. PLoS Comput Biol. 19(4):e1011039.                     %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [equation, species, free_parameter, conservation_law, model] = ComputeEquilibria(model)
    % Start to record the time elapsed
    tic
    
    [model,m] = modelSpecies(model);
    [N,~,~,r] = stoichMatrix(model,m);

    P = {1:r};
    
    % Create a vector of reaction numbers for the total number of reactions
    reac_num = [ ];
    for i = 1:numel(model.reaction)
        if model.reaction(i).reversible == 0
            reac_num(end+1) = i;
        else
            reac_num(end+1) = i;
            reac_num(end+1) = i;
        end
    end

    %
    % Get the conservation laws of the system of ODEs
    %

    % Get the conservation laws: the kernel of the transpose of the stoichiometric subspace
    conservation_law_matrix = null(N', 'r');


    % Initialize list of conservation laws
    conservation_law = { };

    % Get the conservation laws
    for i = 1:size(conservation_law_matrix, 2)

        % Get the column
        conservation_law_ = conservation_law_matrix(:, i);

        % Locate the index of nonzero entries of each column
        conservation_law_nnz = find(conservation_law_);

        % Get the conservation law
        for j = 1:length(conservation_law_nnz)
        
            % First entry
            if j == 1

                % Do not show coefficient if it is 1
                if conservation_law_(conservation_law_nnz(j)) == 1
                    law = ['d' model.species{conservation_law_nnz(j)} '/dt'];

                % Just show a negative sign if it is -1
                elseif conservation_law_(conservation_law_nnz(j)) == -1
                    law = ['-d' model.species{conservation_law_nnz(j)} '/dt'];
                
                % All other cases
                else
                    law = [num2str(conservation_law_(conservation_law_nnz(j))) 'd' model.species{conservation_law_nnz(j)} '/dt'];
                end

            % Succeeding entries
            else

                % Do not show coefficient if it is 1
                if conservation_law_(conservation_law_nnz(j)) == 1
                    law = [law ' + d' model.species{conservation_law_nnz(j)} '/dt'];

                % For negative coefficients
                elseif conservation_law_(conservation_law_nnz(j)) < 0

                    % Just show a negative sign if it is -1
                    if conservation_law_(conservation_law_nnz(j)) == -1
                        law = [law ' - d' model.species{conservation_law_nnz(j)} '/dt'];
                    
                    % All other negative coefficients
                    else
                        law = [law ' - ' num2str(abs(conservation_law_(conservation_law_nnz(j)))) 'd' model.species{conservation_law_nnz(j)} '/dt'];
                    end

                % All other cases
                else
                    law = [law ' + ' num2str(conservation_law_(conservation_law_nnz(j))) 'd' model.species{conservation_law_nnz(j)} '/dt'];
                end
            end
        end

        % Add the law to the list
        conservation_law{end+1} = [law ' = 0'];
    end

    %
    % Solve for the steady state of each subnetwork
    %
    
    % Initialize list of constants used in parametrization
    B_ = [ ];
    sigma_ = [ ];
    
    % Initialize list of equations of the steady state solution
    equation = { };             % List of all steady state solutions
    equation_for_solving = { }; % Same list but formatted for using the 'solve' function
    
    % Initialize list of steady state species
    species = [ ];
    
    % Initialize list of unsolved subnetworks
    unsolved_subnetwork = [ ];

    % Go through each subnetwork
    for i = 1:numel(P)

        % Get the corresponding reactions of the subnetwork from the parent network
        model_P(i).id = [model.id ' - Subnetwork ' num2str(i)];
        model_P(i).species = { };
        reac_P = unique(reac_num(P{i}));
        for j = 1:numel(reac_P)
            model_P(i).reaction(j) = model.reaction(reac_P(j));
        end

        % Create a vector of reaction numbers for the total number of reactions in the subnetwork
        reac_num_ = [ ];
        for j = 1:numel(model_P(i).reaction)
            if model_P(i).reaction(j).reversible == 0
                reac_num_(end+1) = j;
            else
                reac_num_(end+1) = j;
                reac_num_(end+1) = j;
            end
        end

        % Get the unique reaction numbers
        reac_num_unique = unique(reac_num_);

        % Initialize list of reactions of the subnetwork
        reac_subnetwork = { };

        % Create list of reactions of the subnetwork
        for j = 1:numel(reac_num_unique)

            % If the reaction is reversible
            if model_P(i).reaction(reac_num_unique(j)).reversible == 1

                % Split the reactant and product complexes
                split_complex = split(model_P(i).reaction(reac_num_unique(j)).id, '<->');
                
                % Add to the list the two reactions separately
                reac_subnetwork{end+1} = [split_complex{1}, '->', split_complex{2}];
                reac_subnetwork{end+1} = [split_complex{2}, '->', split_complex{1}];
            else
                reac_subnetwork{end+1} = model_P(i).reaction(reac_num_unique(j)).id;
            end
        end

        % Get the reaction numbers
        P_ = P{i};

        % Show reactions
        fprintf('- Network -\n\n')
        for j = 1:numel(P_)
            fprintf('R%d: %s\n', P_(j), reac_subnetwork{j})
        end
        fprintf('\nSolving the network...\n\n')

        % Solve for the the steady state of the subnetwork
        [param, B_, sigma_, k, sigma, tau, model_P(i), skip] = analyticSolution(model_P(i), P_, B_, sigma_);

        if isempty(param) && ...
           isempty(B_) && ...
           isempty(sigma_) && ...
           isempty(k) && ...
           isempty(sigma) && ...
           isempty(tau)

           equation = [];
           species = [];
           free_parameter = [];
        
           return;
        end

        fprintf('\n')
    
        % Substitute the tau's for the free parameters of the subnetwork
        for j = 1:length(param)
            if ismember(param(j), tau)
                param = subs(param, param(j), model_P(i).species{j});
            end
        end

        % Substitute the sigma's for the free parameters of the subnetwork
        for j = 1:length(model_P(i).species)
            
            % Get the numerator and denominator of each solution
            [N, D] = numden(param(j));
    
            % Check if it is of the form sigma/k or k/sigma
            if ismember(N, sigma) | ismember(D, sigma)
    
                % Solve for sigma in terms of k, then substitute
                if ismember(N, sigma)
                    sigma_solved = solve(param(j) == model_P(i).species{j}, sigma(find(ismember(sigma, N))));
                    param = subs(param, N, sigma_solved);
                elseif ismember(D, sigma)
                    sigma_solved = solve(param(j) == model_P(i).species{j}, sigma(find(ismember(sigma, D))));
                    param = subs(param, D, sigma_solved);
                end
            end
        end

        % Go through each species of the subnetwork
        for j = 1:length(model_P(i).species)

            % Get only the steady state species
            if model_P(i).species{j} ~= string(param(j))
                equation{end+1} = param(j);
                equation_for_solving{end+1} = model_P(i).species{j} == param(j);
                
                % Collect all steady state species of the subnetwork
                species = [species, cell2sym(model_P(i).species(j))];
            end
        end
    end

    fprintf('Solving positive steady state parametrization of the network...\n\n')
    
    % Get the unique species we have solved so far
    [unique_species, ~, unique_numbering] = unique(species);
    
    % Create a list of species already solved or reserved to be solved
    species_solved = unique_species;

    % Count how many of each species appeared in the initial solution
    unique_species_occurrence = histc(unique_numbering, unique(unique_numbering));
    
    % Get index of species that occur more than once
    not_unique_species_index = find(unique_species_occurrence > 1);
    
    % Go through each species with duplicate equation
    for i = 1:length(not_unique_species_index)
    
        % Look for the equations of the species
        equation_number = find(has(species, unique_species(not_unique_species_index(i))));
        
        % Initialize list of species in each equation
        species_ = [ ];
    
        % Get all species in each equation
        for j = 1:length(equation_number)
            
            % Get all variables involved
            all_var = symvar(equation{equation_number(j)});
    
            % Get the species only
            species_ = [species_, intersect(cell2sym(model.species), all_var)];
        end

        % Removed from considerations the reserved species
        species_ = setdiff(species_, species_solved);
        
        % List down the variables to be solved: should be the number of equations
        % One of them should be the repeated species
        % The rest will come from 'species_'
        vars = [unique_species(not_unique_species_index(i))];
    
        % Determine the possible additional species to be solved for
        additional = nchoosek(species_, length(equation_number) - 1);
    
        % Solve the system of equations
        for j = 1:length(additional)
            
            % Add each combination of possible additional species
            vars_ = [vars, additional(j,:)];

            % Solve for the indicated species
            solution = solve([equation_for_solving{equation_number}], vars_);
    
            % Convert the structure of solutions to cell array
            solution = struct2cell(solution);

            % Initialize solution_
            solution_ = { };

            % For multiple solutions, we'll just get the first one
            for i = 1:length(solution)
                solution_{end+1} = solution{i}(1);
            end

            % This is the solution we'll get
            solution = solution_;

            % Check if the solution is not empty
            if ~isempty(cell2sym(solution))
    
                % Prepare a checker variable
                checker = [ ];

                % Check if any of the solutions has a negative sign
                for k = 1:length(solution)
                    checker = [checker, findstr(string(solution{k}), '-')];
                end

                % No need to consider the other combinations of possible additional species
                if isempty(checker)
                    break
                end
            end
        end

        % Add the species you just solved to the list of solved species
        species_solved = unique([species_solved, vars_]);

        % Get the species of the solution and replace these to the list of species
        for k = 1:length(equation_number)
            species(equation_number(k)) = vars_(k);
        end

        % Get the solutions and replace these to the list of equations
        for k = 1:length(equation_number)
            equation{equation_number(k)} = solution{k};
        end
    end

    % Initialize list of equations in terms of the free parameters
    equation_final = equation;

    % Initialize flag whether to skip the simplification of the solution
    skip_simplification = 0;
    
    % Sort the species
    [species, index] = sort(species);
        
    % Get the free parameters
    free_parameter = string(setdiff(cell2sym(model.species), species));
    
    % If simplification was skipped
    if skip_simplification == 1
    
        % Sort the untouched equations according to the species
        equation = equation(index);

        % Display the untouched steady state solution of the system
        fprintf('The solution is:\n\n')
        for i = 1:length(equation)
            fprintf('%s = %s\n', species(i), equation{i})
        end
    else

        % Otherwise, use the parametrization in terms of free parameters
        equation_final = equation_final(index);

        % Display the parametrized steady state solution of the system
        fprintf('The solution is:\n\n')
        for i = 1:length(equation_final)
            fprintf('%s = %s\n', species(i), equation_final{i})
        end
    end

    % Display the list of free parameters
    if isempty(free_parameter)
        fprintf('Free parameters: None \n\n')
    elseif length(free_parameter) == 1
        fprintf(1, 'Free parameter: ')
        for i = 1:length(free_parameter)-1
            fprintf(1, '%s, ', char(free_parameter(i)'))
        end
        fprintf(1, '%s\n\n', char(free_parameter(end)))
    else
        fprintf(1, 'Free parameters: ')
        for i = 1:length(free_parameter)-1
            fprintf(1, '%s, ', char(free_parameter(i)'))
        end
        fprintf(1, '%s\n\n', char(free_parameter(end)))
    end

    % Display conservation laws
    if isempty(conservation_law_matrix)
        fprintf('Conservation laws: None \n\n')
    elseif length(conservation_law) == 1
        fprintf('Conservation law: %s \n\n', conservation_law{1})
    else
        fprintf('Conservation laws: \n')
        for i = 1:length(conservation_law)
            disp(conservation_law{i})
        end
    end

    % Stop recording time elapsed
    toc

end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% %                                                   % %
% % The following are functions used in the algorithm % %
% %                                                   % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
% Function 1 of 19: indepDecomp                                           %
%                                                                         %
%    - Purpose: To decompose a network into its finest independent        %
%         decomposition                                                   %
%    - Input: model: empty species list                                   %
%    - Outputs                                                            %
%         - model: completed structure                                    %
%         - R: matrix of reaction vectors of the network                  %
%         - G: undirected graph of R                                      %
%         - P: partitions representing the decomposition of the reactions %
%    - Used in TranslationProgramWithDecomp                               %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [model, N, R, G, P] = indepDecomp(model)

    % Create a list of all species indicated in the reactions
    [model, m] = modelSpecies(model);
    
    % Form stoichiometric matrix N
    [N, ~, ~, r] = stoichMatrix(model, m);

    % Get the transpose of N: Each row now represents the reaction vector a reaction    
    R = N';
    
    % Write R in reduced row echelon form: the transpose of R is used so 'basis_reaction_num' will give the pivot rows of R
    %    - 'basis_reaction_num' gives the row numbers of R which form a basis for the rowspace of R
    [~, basis_reaction_num] = rref(R');
    
    % Form a basis for the rowspace of R
    basis = R(basis_reaction_num, :);
    
    % Initialize an undirected graph G
    G = graph();
    
    % Construct the vertex set of undirected graph G
    % Add vertices to G: these are the reaction vectors that form a basis for the rowspace of R
    for i = 1:numel(basis_reaction_num)
        
        % Use the reaction number as label for each vertex
        G = addnode(G, strcat('R', num2str(basis_reaction_num(i))));
    end
    
    % Initialize matrix of linear combinations
    linear_combo = zeros(r, numel(basis_reaction_num));
    
    % Write the nonbasis reaction vectors as a linear combination of the basis vectors
    % Do this for the nonbasis reactions vectors
    for i = 1:r
        if ~ismember(i, basis_reaction_num)
          
          % This gives the coefficients of the linear combinations
          % The basis vectors will have a row of zeros
          linear_combo(i, :) = basis'\R(i, :)';
        end
    end
    
    % Round off values to nearest whole number to avoid round off errors
    linear_combo = round(linear_combo);
        
    % Get the reactions that are linear combinations of at least 2 basis reactions
    % These are the reactions where we'll get the edges
    get_edges = find(sum(abs(linear_combo), 2) > 1);
        
    % Initialize an array for sets of vertices that will form the edges
    vertex_set = { };
     
    % Identify which vertices form edges in each reaction: get those with non-zero coefficients in the linear combinations
    for i = 1:numel(get_edges)
        vertex_set{i} = find(linear_combo(get_edges(i), :) ~= 0);
    end
    
    % Initialize the edge set
    edges = [ ];
    
    % Get all possible combinations (not permutations) of the reactions involved in the linear combinations
    for i = 1:numel(vertex_set)
        edges = [edges; nchoosek(vertex_set{i}, 2)];
    end
    
    % Get just the unique edges
    edges = unique(edges, 'rows');
    
    % Add these edges to graph G
    for i = 1:size(edges, 1)
        G = addedge(G, strcat('R', num2str(basis_reaction_num(edges(i, 1)))), strcat('R', num2str(basis_reaction_num(edges(i, 2)))));
    end
        
    % Determine to which component each vertex belongs to
    component_numbers = conncomp(G);
    
    % Determine the number of connected components of G: this is the number of partitions R will be decomposed to
    num_components = max(component_numbers);
    
    % For the case of only one connected component
    if num_components == 1
        P = [ ];
    end
    
    % Initialize the list of partitions
    P = cell(1, num_components);
    
    % Basis vectors: assign them first into their respective partition based on their component number
    for i = 1:numel(component_numbers)
        P{component_numbers(i)}(end+1) = basis_reaction_num(i);
    end
    
    % Nonbasis vectors: they go to the same partition as the basis vectors that form their linear combination
    for i = 1:numel(P)
        for j = 1:numel(P{i})
            
            % Get the column number representing the basis vectors in 'linear_combo'
            col = find(basis_reaction_num == P{i}(j));
            
            % Check which reactions used a particular basis vector and assign them to their respective partition
            P{i} = [P{i} find(linear_combo(:, col) ~= 0)'];
        end
    end
    
    % Get only unique elements in each partition
    for i = 1:numel(P)
        P{i} = unique(P{i});
    end

    % If some reactions are missing, then redo starting from the linear combination part
    if length(cell2mat(P)) ~= size(R, 1)

        % Do not round off the coefficients of the linear combinations
        linear_combination = linear_combo;

        get_edges = find(sum(abs(linear_combination), 2) > 1);
        vertex_set = { };
        for i = 1:numel(get_edges)
            vertex_set{i} = find(linear_combination(get_edges(i), :) ~= 0);
        end
        edges = [ ];
        for i = 1:numel(vertex_set)
            edges = [edges; nchoosek(vertex_set{i}, 2)];
        end
        edges = unique(edges, 'rows');
        for i = 1:size(edges, 1)
            G = addedge(G, strcat('R', num2str(basis_reaction_num(edges(i, 1)))), strcat('R', num2str(basis_reaction_num(edges(i, 2)))));
        end
        
        component_numbers = conncomp(G);
        num_components = max(component_numbers);
        if num_components == 1
            P = [ ];
        end
        
        P = cell(1, num_components);
        for i = 1:numel(component_numbers)
            P{component_numbers(i)}(end+1) = basis_reaction_num(i);
        end
        for i = 1:numel(P)
            for j = 1:numel(P{i})
                col = find(basis_reaction_num == P{i}(j));
                P{i} = [P{i} find(linear_combination(:, col) ~= 0)'];
            end
        end
        for i = 1:numel(P)
            P{i} = unique(P{i});
        end
    end

end


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 2 of 19: analyticSolution                                        %
%                                                                           %
%    - Purpose: To solve for the parametrized steady state solution of a    %
%         network                                                           %
%    - Inputs                                                               %
%         - model: empty species list                                       %
%         - P_: list of reaction numbers from the independent decomposition %
%         - B_: list of tau's already used in parametrization               %
%         - sigma_: list of sigma's already used in parametrization         %
%    - Outputs                                                              %
%         - param: list of parametrization of the species of the system     %
%         - B_: updated list of tau's already used in parametrization       %
%         - sigma_: updated list of sigma's already used in parametrization %
%         - k: list of rate constants of the system                         %
%         - sigma: list of sigma's of the system                            %
%         - tau: list of tau's of the system                                %
%         - model: completed structure                                      %
%         - skip: logical; indicator for steadyState to skip solving the    %
%              subnetwork                                                   %
%    - Used in ComputeEquilibria                                            %
%    - Note: The function uses the class graph_.m (which uses edge.m and    %
%         vertex.m)                                                         %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [param, B_, sigma_, k, sigma, tau, model, skip] = analyticSolution(model, P_, B_, sigma_)

    % Create a list of all species indicated in the reactions
    [model, m] = modelSpecies(model);
    
    % Form stoichiometric matrix N
    [N, reactant_complex, product_complex, r] = stoichMatrix(model, m);

    % Get just the unique complexes
    % index(i) is the index in all_complex of the reactant complex in reaction i
    all_complex = unique([reactant_complex product_complex]', 'rows');
    
    % Construct the matrix of complexes
    all_complex = all_complex';
    
    % Count the number of complexes
    n = size(all_complex, 2);

    % Determine the number of linkage and strong linkage classes
    [l, sl] = linkageClass(reactant_complex, product_complex);
    
    % Check if weakly reversible
    is_weakly_reversible = sl == l;
    
    % Get the rank of the reaction network
    s = rank(N);
    
    % Compute the deficiency of the reaction network
    deficiency = n - l - s;
    
    % Initialize indicator if steadyStage needs to skip the subnetwork
    skip = 0;

    % If the network has deficiency 0 and is weakly reversible, no need to translate
    if is_weakly_reversible & deficiency == 0
        disp("Network is already weakly reverisble and deficiency 0.")
        
        % Get the matrix of reactant and product complexes
        stoichiometric_complex_reactant = reactant_complex;
        stoichiometric_complex_product = product_complex;
    
        % Create generalized chemical reaction network (GCRN) vertices
        GCRN_reactant = [stoichiometric_complex_reactant; stoichiometric_complex_reactant];
        GCRN_product = [stoichiometric_complex_product; stoichiometric_complex_product];
        GCRN_vertex = unique([GCRN_reactant, GCRN_product]', 'rows');
        GCRN_vertex = GCRN_vertex';
       
    else
    
        % Generate the GCRN
        [stoichiometric_complex_reactant, stoichiometric_complex_product, kinetic_complex_reactant, kinetic_complex_product, model, skip] = GCRN(model);

        if isempty(stoichiometric_complex_reactant) && ...
           isempty(stoichiometric_complex_product) && ...
           isempty(kinetic_complex_reactant) && ...
           isempty(kinetic_complex_product)

           param = [];
           B_ = [];
           sigma_ = [];
           k = [];
           sigma = [];
           tau = [];

           return;
        end

        % Create GCRN vertices
        GCRN_reactant = [kinetic_complex_reactant];
        GCRN_product = [kinetic_complex_product];
        GCRN_vertex = unique([kinetic_complex_reactant, kinetic_complex_product]', 'rows');
        GCRN_vertex = GCRN_vertex';
    end
    
    % Initialize graph edges
    GCRN_graph = zeros(2, size(GCRN_reactant, 2));

    for i = 1:size(GCRN_reactant, 2)
        % Fill out the reactants
        GCRN_graph(1, i) = find(ismember(GCRN_vertex', GCRN_reactant(:, i)', 'rows'));
        % Fill out the products
        GCRN_graph(2, i) = find(ismember(GCRN_vertex', GCRN_product(:, i)', 'rows'));
    end

    % Construct matrix M per linkage class
    [~, ~, ~, linkageClasses] = linkageClass(GCRN_reactant, GCRN_product);

    M = []; % Initialize as empty, will concatenate class by class

    for c = 1:numel(linkageClasses)
        rxns = linkageClasses{c};
        complexes = unique([GCRN_reactant(:,rxns), GCRN_product(:,rxns)]','rows')';

        % Pick first complex in this class as reference
        ref = complexes(:,1);

        m = size(kinetic_complex_reactant, 1);
        Mc = zeros(m, size(complexes,2)-1);
        for j = 2:size(complexes,2)
            Mc(:, j-1) = complexes(:, j) - ref;
        end

        M = [M, Mc];
    end

    % Let Mp be M' 
    Mp = M';

    % Create a symbolic matrix H
    syms H [size(M, 1) size(M, 2)] matrix
    H = symmatrix2sym(H); % To see the elements of H

    % We want to solve H in M' * H * M' = M'
    % LHS
    H_ = M' * H * M';

    % Solve for H when LHS = RHS
    H_ = solve([H_(:) == Mp(:)]);

    % Extract the solution and place them in matrix H
    % H is the generalized inverse of M'
    for i = 1:length(fieldnames(H_))
        H(i) = getfield(H_, string(H(i)));
    end

    % For the case when H has only 1 entry
    if isempty(H(i))
        H = 1;
    end

    % Form B: outputs the answer as rational numbers
    B = null(M', 'r');
    c = null(M, 'r');
    exponent = null(M, 'r');

    % Number of vertices
    V = size(GCRN_vertex, 2);

    % Initialize digraph
    G = graph_(V);

    % Add digraph edges
    for i = 1:size(GCRN_graph, 2)
        G.addEdge(GCRN_graph(1, i), GCRN_graph(2, i));
    end

    % Get linkage classes (for reactions → complexes)
    [~, ~, ~, linkageClasses] = linkageClass(GCRN_reactant, GCRN_product);

    % Convert from reactions to complexes per class
    complexClasses = cell(1, numel(linkageClasses));
    for cc = 1:numel(linkageClasses)
        rxns = linkageClasses{cc};
        complexClasses{cc} = unique([GCRN_graph(1,rxns), GCRN_graph(2,rxns)]);
    end

    % Initialize outputs
    spanTree_edge = cell(1, V);
    tree_constant_reaction = cell(1, V);

    % Spanning trees only inside each linkage class
    for cc = 1:numel(complexClasses)
        classVertices = complexClasses{cc};
        localIndex = containers.Map(classVertices, 1:numel(classVertices));

        % Build reduced graph for this class
        G_class = graph_(numel(classVertices));
        for i = 1:size(GCRN_graph, 2)
            u = GCRN_graph(1,i);
            v = GCRN_graph(2,i);
            if ismember(u, classVertices) && ismember(v, classVertices)
                G_class.addEdge(localIndex(u), localIndex(v));
            end
        end

        % Run spanning tree search for vertices in this class
        for v = classVertices
            v_local = localIndex(v);

            spanTree = directedSpanTreeTowards(G_class, v_local);

            % Map edges back to global indices
            for j = 1:length(spanTree)
                globalEdges = [classVertices(spanTree{j}(1,:)); ...
                               classVertices(spanTree{j}(2,:))];
                spanTree_edge{v}{end+1} = globalEdges;
            end

            % Map spanning tree edges back to reaction indices
            for j = 1:length(spanTree_edge{v})
                tree_constant_reaction{v}{end+1} = ...
                    find(ismember(GCRN_graph', spanTree_edge{v}{j}', 'rows'));
            end
        end
    end

    % k: rate constants
    % Create rate constants based on reaction number of decomposition
    for i = 1:length(P_)
        try
            k(end+1) = sym(strcat('k', string(P_(i))));
        catch
            k = sym(strcat('k', string(P_(i))));
        end
    end

    % sigma: phantom edge rate constants
    if size(GCRN_graph, 2) - r == 0
        sigma = [ ];
    else
        for i = 1:size(GCRN_graph, 2) - r
            % Create tracker of sizes of sigma
            sigma_(end+1) = length(sigma_) + 1;

            % Create the sigma's, continuing the numbering from previous subnetwork
            try
                sigma(end+1) = sym(strcat('sigma', string(length(sigma_))));
            catch
                sigma = sym(strcat('sigma', string(length(sigma_))));
            end
        end
    end

    % K: tree constants
    K = sym('K', [1 V]);
    kappa = sym('kappa', [1 size(H,2)]);

    % tau
    if isempty(B)
        tau = [ ];
    else
        for i = 1:size(B, 2)

            % Create tracker of sizes of B
            B_(end+1) = length(B_) + 1;

            % Create the tau's, continuing the numbering from previous subnetwork
            try
                tau(end+1) = sym(strcat('tau', string(length(B_))));
            catch
                tau = sym(strcat('tau', string(length(B_))));
            end
        end
    end

    % Create list of rate constants including for phantom edges (if they exist)
    rate_constants = [k, sigma];

    % Form the tree constants
    for i = 1:length(K)
        for j = 1:length(tree_constant_reaction{i})
            if j == 1
                K(i) = prod(rate_constants(tree_constant_reaction{i}{j}));
            else
                K(i) = K(i) + prod(rate_constants(tree_constant_reaction{i}{j}));
            end

        end
    end

    idx = 1;
    
    for cc = 1:numel(complexClasses)
        classVertices = complexClasses{cc};
        ref = classVertices(1);

        for v = classVertices(2:end)
            kappa(idx) = simplify(K(v)/K(ref));
            idx = idx + 1;
        end
    end

    %
    % Include additional conditions for positive deficiency case
    %

    num_free = size(c,2);
    num_kappa = length(kappa);

    free_expr = sym('free', [1 size(c,2)]);

    if size(exponent,2) > 0
        for j = 1:num_free
            expr = sym(1);
            for i = 1:num_kappa
                expr = expr * kappa(i)^exponent(i,j);
            end
            free_expr(j) = simplify(expr);
        end
    
        fprintf('----------------------');
        fprintf('\n');
        disp('Additional conditions to the parametrization:')
        for j = 1:num_free
            fprintf('Eq %d: 1 = %s\n', j, char(free_expr(j)));
        end
        fprintf('----------------------');
        fprintf('\n\n');
    end

    % Generate the parametrization of the steady state
    try
        param = [(kappa.^H.').' (tau.^B.').'];
        param = prod(param.');

    % If there are no tau's
    catch
        param = [(kappa.^H.').'];
        param = prod(param.');
    end
   
    % Display the result
    for i = 1:length(model.species)
        fprintf('%s = %s \n', model.species{i}, string(param(i)))
    end

end

            
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                     %
% Function 3 of 19: modelSpecies                                      %
%                                                                     %
%    - Purpose: To fill out list of species based on given reactions  %
%    - Input: model: empty species list                               %
%    - Outputs                                                        %
%         - model: completed structure                                %
%         - m: number of species                                      %
%    - Used in                                                        %
%         - GCRN                                                      %
%         - TranslationProgramWithDecomp                              %
%         - TranslationProgram                                        %
%         - indepDecomp                                               %
%         - ComputeEquilibria                                         %
%         - analyticSolution                                          %
%                                                                     %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [model, m] = modelSpecies(model)

    % Initialize list of species
    model.species = { };

    % Get all species from reactants
    for i = 1:numel(model.reaction)
        for j = 1:numel(model.reaction(i).reactant)
            model.species{end+1} = model.reaction(i).reactant(j).species;
        end
    end
    
    % Get species from products
    for i = 1:numel(model.reaction)
        for j = 1:numel(model.reaction(i).product)
            model.species{end+1} = model.reaction(i).product(j).species;
        end
    end
    
    % Get only unique species
    model.species = unique(model.species);
    
    % Count the number of species
    m = numel(model.species);
    
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 4 of 19: stoichMatrix                                            %
%                                                                           %
%    - Purpose: To form the stoichometrix matrix N and the set of reactant  %
%          and product complexes                                            %
%    - Inputs                                                               %
%         - model: complete structure                                       %
%         - m: number of species                                            %
%    - Outputs                                                              %
%         - N: stoichiometric matrix                                        %
%         - reactant_complex: matrix of reactant complexes                  %
%         - product_complex: matrix of product complexes                    %
%         - r: total number of reactions                                    %
%    - Used in                                                              %
%         - ComputeEquilibria                                               %
%         - indepDecomp                                                     %
%         - analyticSolution                                                %
%         - GCRN                                                            %
%         - TranslationProgramWithDecomp                                    %
%         - TranslationProgram                                              %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [N, reactant_complex, product_complex, r] = stoichMatrix(model, m)

    % Initialize the matrix of reactant complexes
    reactant_complex = [ ];
    
    % Initialize the matrix of product complexes
    product_complex = [ ];
    
    % Initialize the stoichiometric matrix
    N = [ ];
    
    % For each reaction in the model
    for i = 1:numel(model.reaction)
      
        % Initialize the vector for the reaction's reactant complex
        reactant_complex(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the reactant complex
        for j = 1:numel(model.reaction(i).reactant)
            reactant_complex(find(strcmp(model.reaction(i).reactant(j).species, model.species), 1), end) = model.reaction(i).reactant(j).stoichiometry;
        end
        
        % Initialize the vector for the reaction's product complex
        product_complex(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the product complex
        for j = 1:numel(model.reaction(i).product)
            product_complex(find(strcmp(model.reaction(i).product(j).species, model.species), 1), end) = model.reaction(i).product(j).stoichiometry;
        end
        
        % Create a vector for the stoichiometric matrix: Difference between the two previous vectors
        N(:, end+1) = product_complex(:, end) - reactant_complex(:, end);
        
        % If the reaction is reversible
        if model.reaction(i).reversible
          
            % Insert a new vector for the reactant complex: make it same as the product complex
            reactant_complex(:, end+1) = product_complex(:, end);
            
            % Insert a new vector for the product complex: make it the same as the reactant complex
            product_complex(:, end+1) = reactant_complex(:, end-1);
            
            % Insert a new vector in the stoichiometric matrix: make it the additive inverse of the vector formed earlier
            N(:, end+1) = -N(:, end);
        end
    end
    
    % Count the total number of reactions
    r = size(N, 2);

end



% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 5 of 19: GCRN                                                    %
%                                                                           %
%    - Purpose: To create the GCRN of a translated network                  %
%    - Input: model: empty species list                                     %
%    - Outputs                                                              %
%         - stoichiometric_complex_reactant: reactant stoichiometric        %
%              complex of the GCRN                                          %
%         - stoichiometric_complex_product: product stoichiometric complex  %
%              of the GCRN                                                  %
%         - kinetic_complex_reactant: kinetic complex associated with the   %
%              reactant stoichiometric complex                              %
%         - kinetic_complex_product: kinetic complex associated with the    %
%              product stoichiometric complex                               %
%         - model: completed structure                                      %
%         - skip: logical; indicator for steadyState to skip solving the    %
%              subnetwork                                                   %
%    - Used in analyticSolution                                             %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [stoichiometric_complex_reactant, stoichiometric_complex_product, kinetic_complex_reactant, kinetic_complex_product, model, skip] = GCRN(model)

    % Create a list of all species indicated in the reactions
    [model, m] = modelSpecies(model);
    
    % Form stoichiometric matrix N
    [~, reactant_complex, product_complex, r] = stoichMatrix(model, m);

    % Get the translation of the network
    [Solution, Index, skip] = TranslationProgramWithDecomp(model);

    if isempty(Solution)
        stoichiometric_complex_reactant = [];
        stoichiometric_complex_product = [];
        kinetic_complex_reactant = [];
        kinetic_complex_product = [];
        return
    end

    % If the subnetwork needs to be skipped
    if skip == 1

        % Empty results since no translation was found
        stoichiometric_complex_reactant = [ ];
        stoichiometric_complex_product = [ ];
        kinetic_complex_reactant = [ ];
        kinetic_complex_product = [ ];
        return
    end

    for i = 1:numel(Solution)
        % Extract the translated network from the cell
        translated_network = Solution{i};
    
        % Extract the corresponding index
        Index_ = Index{i};
    end

    % Go through each translation
    for i = 1:size(Solution, 1)

        % Get the translation
        translated_network = Solution(i, :);

        % Get the Index
        Index_ = Index(i, :);

        translated_network_reactant = translated_network{1};
        translated_network_product = translated_network{2};

        % Get unique complexes of the translation
        translation_complex = unique([translated_network_reactant, translated_network_product]', 'rows');
        translation_complex = translation_complex';
    
        % Initialize list of count of kinetic complexes per stoichiometric complex
        % The index corresponds to the complex in translation_complex
        kinetic_count = zeros(1, size(translation_complex, 2));
    
        % Initialize list of translation reactant complexes which occurs multiple times
        translation_reactant_complex_count = zeros(1, size(translation_complex, 2));
        
        % Assign kinetic complexes to each stoichiometric complex
        % Go through each unique stoichiometric complex
        for j = 1:numel(kinetic_count)
    
            % Look for the index of this complex in translated_network_reactant
            index_in_translation_reactant = find(ismember(translated_network_reactant', translation_complex(:, j)', 'rows'));
    
            % Assign the number of indices to translation_reactant_complex_multiple
            translation_reactant_complex_count(j) = numel(index_in_translation_reactant);
    
            % Assign the kinetic complex of these reaction numbers to the stoichiometric complex
            kinetic = unique(reactant_complex(:, index_in_translation_reactant)', 'rows')';
    
            % Count how many kinetic complexes
            kinetic_count(j) = size(kinetic, 2);
        end
    
        % Construct a list of reactant complexes in the translation that appear multiple times
        translation_reactant_complex_multiple = find(translation_reactant_complex_count > 1);
    
        % Check if a stoichiometric complex has more than one kinetic complex
        % If yes, no need to add phantom edges
        if ~any(kinetic_count > 1)

            % Form matrices of stoichiometric complexes
            stoichiometric_complex_reactant = translated_network_reactant;
            stoichiometric_complex_product = translated_network_product;

            % Form matrices of kinetic complexes
            kinetic_complex_reactant = reactant_complex;
            kinetic_complex_product = zeros(m, r);

            % For the matrix of product kinetic complexes, create a matrix of vertex numbers matching reactants and products
            [~, reactant_vertex] = ismember(translated_network_reactant', translation_complex', 'rows');
            [~, product_vertex] = ismember(translated_network_product', translation_complex', 'rows');
            translation_vertex = [reactant_vertex'; product_vertex'];


            % Initialize GCRN vertices
            GCRN_vertices = zeros(2, r);

            % Fill out the vertex numbers for the reactant
            GCRN_vertices(1, :) = 1:r;

            % % Fill out the vertex numbers for the product: match them with the numbering of the row for reactants
            for j = 1:r

                % Simply get the first in the list of reaction numbers if there are multiple ones
                if ismember(translation_vertex(2, j), translation_reactant_complex_multiple)
                    reaction_number = find(translation_vertex(1, :) == translation_vertex(2, j));
                    GCRN_vertices(2, j) = reaction_number(1);
                else
                    GCRN_vertices(2, j) = find(translation_vertex(1, :) == translation_vertex(2, j));
                end
            end


            % Finish the matrix of product kinetic complexes
            kinetic_complex_product(:, 1:r) = kinetic_complex_reactant(:, GCRN_vertices(2, 1:r));


            % Compute the kinetic deficiency
            kinetic_deficiency = kineticDeficiency(kinetic_complex_reactant, kinetic_complex_product);
            fprintf('\n');
            fprintf('----------------------');
            fprintf('\n');
            fprintf('Kinetic deficiency: %d\n', kinetic_deficiency);
            fprintf('----------------------');
            fprintf('\n\n');

            % End once the kinetic deficiency is 0
            if kinetic_deficiency == 0
                break
            end

        % Otherwise, phantom edges are needed
        else

            %
            % Ensure that there are no self-loops in the kinetic-order crn
            %

            % Form matrices of stoichiometric complexes
            stoichiometric_complex_reactant = translated_network_reactant;
            stoichiometric_complex_product = translated_network_product;

            % Form matrices of kinetic complexes
            kinetic_complex_reactant = reactant_complex;
            kinetic_complex_product = zeros(m, r);

            % Create vertex numbers matching reactants and products
            [~, reactant_vertex] = ismember(translated_network_reactant', translation_complex', 'rows');
            [~, product_vertex] = ismember(translated_network_product', translation_complex', 'rows');
            translation_vertex = [reactant_vertex'; product_vertex'];

            % Initialize GCRN vertices
            GCRN_vertices = zeros(2, r);
            GCRN_vertices(1,:) = 1:r;

            % Identify complexes needing phantom edges
            complex_need_phantom_edge = find(kinetic_count > 1);

            % Fill product vertex numbers for reactions not needing phantom edges
            for j = 1:r
                if ismember(translation_vertex(2,j), complex_need_phantom_edge)
                    GCRN_vertices(2,j) = 0;
                else
                    reaction_number = find(translation_vertex(1,:) == translation_vertex(2,j));
                    GCRN_vertices(2,j) = reaction_number(1);
                end
            end

            % Construct phantom edges
            for j = 1:numel(complex_need_phantom_edge)
                list_reaction_number = find(translation_vertex(1,:) == complex_need_phantom_edge(j));
                keep_index = list_reaction_number(1);
                list_reaction_number(1) = [];

                for k = 1:numel(list_reaction_number)
                    delete_index = list_reaction_number(k);

                    GCRN_vertices(1,end+1) = size(GCRN_vertices,2)+1;
                    GCRN_vertices(2,end) = delete_index;

                    stoichiometric_complex_reactant(:, end+1) = stoichiometric_complex_reactant(:, keep_index);
                    stoichiometric_complex_product(:, end+1) = stoichiometric_complex_reactant(:, keep_index);
                    kinetic_complex_reactant(:, end+1) = kinetic_complex_reactant(:, keep_index);
                    kinetic_complex_product(:, end+1) = kinetic_complex_reactant(:, delete_index);
                end

                % Assign kept reactions
                need_replacement = find(translation_vertex(2,:) == complex_need_phantom_edge(j));
                for k = 1:numel(need_replacement)
                    if numel(find(GCRN_vertices(1,:) == need_replacement(k))) == 1
                        GCRN_vertices(2, need_replacement(k)) = keep_index;
                    else
                        GCRN_vertices(2, need_replacement(k)) = delete_index;
                    end
                end
            end

            % Remove self-loop columns
            kinetic_complex_product(:,1:r) = kinetic_complex_reactant(:, GCRN_vertices(2,1:r));

            duplicate_cols = false(1,size(kinetic_complex_product,2));
            for j = 1:size(kinetic_complex_product,2)
                if isequal(kinetic_complex_product(:,j), kinetic_complex_reactant(:,j))
                    duplicate_cols(j) = true;
                end
            end

            % Drop duplicate columns in all matrices
            kinetic_complex_product(:, duplicate_cols) = [];
            kinetic_complex_reactant(:, duplicate_cols) = [];
            stoichiometric_complex_reactant(:, duplicate_cols) = [];
            stoichiometric_complex_product(:, duplicate_cols) = [];
            GCRN_vertices(:, duplicate_cols) = [];

            % Compute kinetic deficiency
            kinetic_deficiency = kineticDeficiency(kinetic_complex_reactant, kinetic_complex_product);

            fprintf('\n');
            fprintf('----------------------');
            fprintf('\n');
            fprintf('Kinetic deficiency: %d\n', kinetic_deficiency);
            fprintf('----------------------');
            fprintf('\n\n');

            % End if deficiency is zero
            if kinetic_deficiency == 0
                break
            end
        end
    end

end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 6 of 19: kineticDeficiency                                       %
%                                                                           %
%    - Purpose: To determine the kinetic deficiency of a GCRN               %
%    - Inputs                                                               %
%         - kinetic_complex_reactant: matrix of kinetic reactant complexes  %
%         - kinetic_complex_product: matrix of kinetic product complexes    %
%    - Output: kinetic_deficiency: kinetic deficiency                       %
%    - Used in GCRN                                                         %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function kinetic_deficiency = kineticDeficiency(kinetic_complex_reactant, kinetic_complex_product)

    % Get unique kinetic complexes
    complex_translated = unique([kinetic_complex_reactant, kinetic_complex_product]', 'rows');
    complex_translated = complex_translated';
    
    % Get number of kinetic complexes
    n_translated = size(complex_translated, 2);
    
    % Get number of linkage classes
    [l_translated, ~] = linkageClass(kinetic_complex_reactant, kinetic_complex_product);
    
    % Get rank of the network of kinetic complexes
    s_translated = rank(kinetic_complex_product - kinetic_complex_reactant);
    
    % Compute the kinetic deficiency
    kinetic_deficiency = n_translated - l_translated - s_translated;

end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                     %
% Function 7 of 19: linkageClass                                      %
%                                                                     %
%    - Purpose: To determine the number of linkage and strong linkage %
%         classes. This also builds the incidence matrix and groups   % 
%         reactions based on what linkage class they belong.          %                                          %
%    - Inputs                                                         %
%         - reactant_complex: matrix of reactant complexes            %
%         - product_complex: matrix of product complexes              %
%    - Outputs                                                        %
%         - l: number of linkage classes                              %
%         - sl: number of strong linkage classes                      %
%         - incidence: incidence matrix of the network                %
%         - linkageClasses: an array that groups reactions by linkage %
%                           class                                     %
%    - Used in                                                        %
%         - analyticSolution                                          %
%         - kineticDeficiency                                         %
%         - TranslationProgramWithDecomp                              %
%         - TranslationProgram                                        %
%                                                                     %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [l, sl, incidence, linkageClasses] = linkageClass(reactant_complex, product_complex)

    % Get the number of reactions
    r = size(reactant_complex, 2); 
    
    % Get just the unique complexes
    [complex, ~, index] = unique([reactant_complex, product_complex]', 'rows');
    complex = complex';
    n = size(complex, 2);

    % Initialize graph structures
    reacts_to = false(n, n);
    reacts_in = zeros(n, r); % This is the incidence matrix eventually
    
    % Fill out the entries of the matrices
    for i = 1:r
        
        % reacts_to(i, j) = true iff there is a reaction r: y_i -> y_j
        reacts_to(index(i), index(i + r)) = true;
        
        % reacts_in(i, r) = -1 and reacts_in(j, r) = 1) iff there is a reaction r: y_i -> y_j
        reacts_in(index(i), i) = -1;
        reacts_in(index(i+r), i) = 1;
    end
    
    % Count number of connected components of an undirected graph
    linkage_class = conncomp(graph(reacts_to | reacts_to'));
    
    % Count the number of linkage classes
    l = max(linkage_class);

    % Check if the network is reversible
    is_reversible = isequal(reacts_to, reacts_to');
    
    % Count number of strongly connected components of an directed graph
    if is_reversible
        strong_linkage_class = linkage_class;
    else
        % Count number of connected components of a directed graph
        strong_linkage_class = conncomp(digraph(reacts_to));
    end
    
    % Count the number of strong linkage classes
    sl = max(strong_linkage_class);

    incidence = reacts_in;

    % Group reactions by linkage class
    reaction_linkage = linkage_class(index(1:r));
    linkageClasses = cell(1, l); 
    for i = 1:r
        cls = reaction_linkage(i);
        linkageClasses{cls}(end+1) = i;
    end

end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 8 of 19: directedSpanTreeTowards                                %
%                                                                           %
%    - Purpose: To create a list of directed spanning trees towards the     %
%         indicated root vertex of a directed graph                         %
%    - Inputs                                                               %
%         - G: directed graph with vertices and edges                       %
%         - r: root vertex                                                  %
%    - Output: spanTree: edges of the directed spanning tree towards the    %
%         root vertex                                                       %
%    - Used in analyticSolution                                             %
%    - Note: The function uses the class graph_.m (which uses edge.m and    %
%         vertex.m)                                                         %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function spanTree = directedSpanTreeTowards(G, r)

    % Create a new graph for the reversed edges
    G2 = graph_(G.V);

    % Initialize reversed edges
    reverse_edge = cell(1, G.V);

    % Reverse the edges of G
    for i = 1:G.V
        for j = 1:length(G.edge{i})
            reverse_edge{G.edge{i}(j)}(end+1) = i;
        end
    end

    % Replace the edges of G
    G2.edge = reverse_edge;

    % Root vertex where the spanning trees will come from
    G2.root_vertex = r;

    % Initialize subtree for spanning tree generation
    T = graph_(G2.V);

    % Initialize latest spanning tree found
    L = graph_(G2.V);

    % Initialize list of all edges directed from vertices in T to vertices not in T
    F = [ ];

    % Initialize count of spanning trees rooted at G.root_vertex
    spanTreeCount = 0;

    % Initialize list of spanning trees found
    spanTree = { };

    % Initialize F to contain all edges from the root vertex
    % Go through each vertex to which the root vertex is connected to
    for i = 1:length(G2.edge{G2.root_vertex})

        % Insert at the beginning of F each edge from the root vertex
        F = [edge(G2.root_vertex, G2.edge{G2.root_vertex}(i)), F];
    end

    % Generate spanning trees
    spanTree = grow(G2.V, G2, T, L, F, spanTreeCount, spanTree);

end


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 9 of 19: grow                                                   %
%                                                                           %
%    - Purpose: To generate the spanning trees away from the root vertex    %
%    - Inputs                                                               %
%         - V: number of vertices in the graph                              %
%         - G: given digraph                                                %
%         - T: subtree for spanning tree generation                         %
%         - L: latest spanning tree found                                   %
%         - F: list of all edges directed from vertices in T to vertices    %
%              not in T                                                     %
%         - spanTreeCount: number of spanning trees                         %
%         - spanTree: list of edges of the directed spanning tree towards   %
%              the root vertex                                              %
%    - Outputs                                                              %
%         - spanTree: list of edges of the directed spanning tree towards   %
%              the root vertex                                              %
%         - spanTreeCount: count of spanning trees rooted at G.root_vertex  %
%    - Used in directedSpanTreeTowards                                      %
%    - Notes                                                                %
%         - The function uses the class edge.m                              %
%         - This function was converted from Python to Matlab               %
%         - Python code can be found in https://github.com/ricelink/        %
%              finding-all-spanning-trees-in-directed-graph                 %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
 
function [spanTree, spanTreeCount] = grow(V, G, T, L, F, spanTreeCount, spanTree)

    % Make sure the root vertex of the subgraphs are the same as that of the main graph
    T.root_vertex = G.root_vertex;
    L.root_vertex = G.root_vertex;

    % Check if subtree T already contains all the vertices
    if T.connectedVertices == V

        % If yes, then T becomes L, the latest spanning tree found
        % We deepcopy T to L
        L.V = T.V;
        L.root_vertex = T.root_vertex;
        L.edge = T.edge;
        L.time = T.time;
        L.vertex = T.vertex;

        % Initialize the reversed back edges
        reverse_edge_back = cell(1, V);
        
        % Reverse back the edges
        for i = 1:V
            for j = 1:length(L.edge{i})
                reverse_edge_back{L.edge{i}(j)}(end+1) = i;
            end
        end
        
        % Replace the edges of L
        L.edge = reverse_edge_back;

        % Add 1 to the count of spanning trees
        spanTreeCount = spanTreeCount + 1;

        % Initialize vertex of spanning tree reactions
        spanTreeReaction = zeros(2, length(cell2mat(L.edge)));
        
        % Get the edges from the spanning tree
        i = 1;
        for j = 1:L.V
            if ~isempty(L.edge{j})
                for k = 1:length(L.edge{j})
                    spanTreeReaction(1, i) = j;
                    spanTreeReaction(2, i) = L.edge{j}(k);
                    i = i + 1;
                end
            end
        end
        
        % Add the spanning tree to the list
        spanTree{spanTreeCount} = spanTreeReaction;
        
        % Initialize the reversed reverse_edge_back
        reverse_edge_back_again = cell(1, V);

        % Reverse back the edges
        for i = 1:V
            for j = 1:length(L.edge{i})
                reverse_edge_back_again{L.edge{i}(j)}(end+1) = i;
            end
        end

        % Replace the edges of L
        L.edge = reverse_edge_back_again;

        % Visit all the vertices of L
        L.depthFirstSearch(L.root_vertex);
    else

        % Initialize FF, a list of edges
        FF = [ ];

        % Run the following block of codes until it breaks
        while true
                
            % If F is not empty, pop an edge e from F
            if ~isempty(F)
    
                % Get the first element of F (an edge)
                e = F(1);
    
                % Remove the first element from F
                F(1) = [ ];
            else
    
                % If F is empty, then the function ends
                return
            end
    
            % Get the ending node of edge e
            % This vertex v is not yet in T
            v = e.to_node;
    
            % Add edge e to T
            T.addEdge(e.from_node, v);
            % disp("Connected so far: " + num2str(T.connectedVertices) + " / " + num2str(V));


            % Deepcopy F to F_copy
            F_copy = [ ];
            F_copy = F(:)';
    
            % Push each edge (v, w), where w is NOT in T, onto F
            % Go through each vertex to which vertex v is connected to
            for i = 1:length(G.edge{v})
    
                % Get each ending node
                w = G.edge{v}(i);
    
                % If vertex w is not a vertex of any edge in T
                if T.connectedVertex(w) == 0
    
                    % Insert the edge at the beginning of F
                    F = [edge(v, w), F];
                end
            end
            
            % Remove each edge (w, v), where w IS in T, from F
            % Go through each vertex w
            for w = 1:length(G.edge)
    
                % If vertex w is a vertex of an edge in T
                if T.connectedVertex(w) == 1
    
                    % Initialize checker if w -> v exists in T
                    w_to_v = [ ];
    
                    % Go through each vertex to which vertex w is connected to
                    for j = 1:length(G.edge{w})
    
                        % If vertex w is connected to vertex v
                        if G.edge{w}(j) == v
    
                            % Append (i.e., place at the end) the index of v to the checker
                            w_to_v = [w_to_v, j];
                        end
                    end
    
                    % If there is w -> v in T
                    if ~isempty(w_to_v)
    
                        % Initialize checker of location of w -> v in F
                        w_to_v_loc = [ ];
    
                        % Go through each element of F
                        for j = 1:length(F)
    
                            % Look for the location of w -> v in F
                            if (F(j).from_node == w) & (F(j).to_node == v)
    
                                % Append the index in F to the checker
                                w_to_v_loc = [w_to_v_loc, j];
                            end
                        end
    
                        % If w -> v is located in F
                        if ~isempty(w_to_v_loc)
    
                            % j decreases by 1 each step until it reaches 1
                            for j = length(w_to_v_loc):-1:1
                                
                                % Remove the w -> v from F
                                F(w_to_v_loc(j)) = [ ];
                            end
                        end
                    end
                end
            end
    
            % Recurse
            [spanTree, spanTreeCount] = grow(G.V, G, T, L, F, spanTreeCount, spanTree);
           
            % Pop each edge (v, w), where w is NOT in T, from F and restore each edge (w, v), where w IS in T, in F
            % Deepcopy F_copy to F
            F = F_copy(:)';

            % Remove edge e from graphs T and G
            T.removeEdge(e.from_node, e.to_node);
            G.removeEdge(e.from_node, e.to_node);

            % Insert edge e at the beginning of FF
            FF = [e, FF];
    
            % Bridge Test
            %    - An edge e is a bridge if G\{e} is NOT connected
            %    - Check if there is an edge (w, v), where w is NOT a descendant of v in L

            % Initialize b as true
            b = 1;
    
            % Go through each vertex
            for w = 1:length(G.edge)
    
                % Variable to check for an edge w -> v
                w_to_v = -1;
    
                % Go through each vertex to which vertex w is connected to
                for j = 1:length(G.edge{w})

                    % If vertex w is connected to vertex v
                    if G.edge{w}(j) == v

                        % j is the index of v s.t. w -> v
                        % This confirms that w is NOT a descendant of v
                        w_to_v = j;
                    end
                end



                % If w is NOT directly connected to v
                if w_to_v ~= -1

                    % Check if w is a descendant of any child of v in L
                    if ((L.vertex{v}.d < L.vertex{w}.d) & (L.vertex{w}.d < L.vertex{w}.f) & (L.vertex{w}.f < L.vertex{v}.f)) == 0
    
                        % Change b to 0 (i.e., the Bridge Test fails)
                        b = 0;
    
                        % Get out of the for-loop for w
                        break
                    end
                end
            end
    
            % If b is still 1 (i.e., the Bridge Test passes)
            if b == 1

                % Get out of the while-true loop
                break
            end
        end
    
        % Reconstruct G
        while ~isempty(FF)
    
            % Get the first element of FF (an edge)
            e = FF(1);
    
            % Remove it from FF
            FF(1) = [ ];
    
            % Insert it at the beginning of F
            F = [e, F];
    
            % Add it to G
            G.addEdge(e.from_node, e.to_node);
        end

    end

end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 10 of 13: TranslationProgramWithDecomp                           %
%                                                                           %
%    - Purpose: To obtain a weakly reversible and deficiency zero           %
%               translation of a reaction network combined with network     %
%               decomposition                                               %
%    - Input                                                                %
%         - model: reaction network structure                               %
%    - Outputs                                                              %
%         - Solution: cell array {R, P} where                               %
%               R = translated reactant complexes matrix                    %
%               P = translated product complexes matrix                     %
%         - Index: cell array mapping translated reactions back to their    %
%               corresponding original reaction indices                     %            
%         - skip: logical; indicator whether or not to skip solving the     %
%              subnetwork                                                   %
%    - Used in GCRN                                                         %
%    - Notes                                                                %
%         - This function does not perform the EFM-based translation per    %
%              se, but rather this handles the decomposition of the network %
%              into its independent subnetworks and merging of the          %
%              subnetworks into one whole network after translation of the  %
%              subnetworks.                                                 %
%         - The TranslationProgram function handles the EFM-based           %
%              translation. It is called inside this function.              %
%         - Final outputs are constructed to preserve consistency           %
%              with the original network, ensuring that reaction            %
%              indices align with those of the parent network.              %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [Solution, Index, skip] = TranslationProgramWithDecomp(model)

    % Decompose the network into its finest independent subnetworks
    [model, N, R, G, P] = indepDecomp(model);

    % Extract species and stoichiometric information of the original network
    [model,m] = modelSpecies(model);
    [N,~,~,r] = stoichMatrix(model,m);

    
    if numel(P) == 1
        fprintf('The network has no nontrival independent decomposition.\n\n')
    else
        fprintf('The network has %d subnetworks.\n\n', numel(P))
    end

    % Build a reaction index list
    reac_num = [ ];
    parent_indices = {};  
    for i = 1:numel(model.reaction)
        if model.reaction(i).reversible == 0
            reac_num(end+1) = i;
            parent_indices{end+1} = i;
        else
            reac_num(end+1) = i;
            parent_indices{end+1} = i;

            reac_num(end+1) = i;
            parent_indices{end+1} = i;
        end
    end

    % Initialize storage for outputs
    Solution_all = cell(1, numel(P));
    Index_all = cell(1, numel(P));
    Skip_all = cell(1, numel(P));

    for i = 1:numel(P)
        % Get the corresponding reactions of the subnetwork from the parent network
        model_P(i).id = [model.id ' - Subnetwork ' num2str(i)];
        model_P(i).species = { };
        reac_P = unique(reac_num(P{i}));

        for j = 1:numel(reac_P)
            model_P(i).reaction(j) = model.reaction(reac_P(j));
        end

        % Rebuild reaction list
        reac_num_ = [ ];
        for j = 1:numel(model_P(i).reaction)
            if model_P(i).reaction(j).reversible == 0
                reac_num_(end+1) = j;
            else
                reac_num_(end+1) = j;
                reac_num_(end+1) = j;
            end
        end

        % Get the unique reaction numbers
        reac_num_unique = unique(reac_num_);
        
        % Create list of reactions of the subnetwork
        reac_subnetwork = { };
        for j = 1:numel(reac_num_unique)
            if model_P(i).reaction(reac_num_unique(j)).reversible == 1
                split_complex = split(model_P(i).reaction(reac_num_unique(j)).id, '<->');

                reac_subnetwork{end+1} = [split_complex{1}, '->', split_complex{2}];
                reac_subnetwork{end+1} = [split_complex{2}, '->', split_complex{1}];
            else
                reac_subnetwork{end+1} = model_P(i).reaction(reac_num_unique(j)).id;
            end
        end

        % Get the reaction numbers from the independent decomposition
        P_ = P{i};
    
        if numel(P) == 1
            fprintf('- Network -\n\n')
        else
            fprintf('- Subnetwork %d -\n\n', i)
        end

        % Show reactions of the subnetwork
        for j = 1:numel(P_)
            fprintf('R%d: %s\n', P_(j), reac_subnetwork{j})
        end

        if numel(P) == 1
            fprintf('\nSolving the network...\n\n')
        else
            fprintf('\nSolving Subnetwork %d...\n\n', i)
        end

        % Have subnetwork use the global species list
        model_P(i).species = model.species;  
        m_subnetwork = numel(model.species);

        % Build stoichiometric matrix of the subnetwork
        [N_subnetwork, reactant_subnetwork, product_subnetwork, ~] = stoichMatrix(model_P(i), m_subnetwork);

        % Get number of complexes
        all_complex_subnetwork = unique([reactant_subnetwork product_subnetwork]', 'rows');

        all_complex_subnetwork = all_complex_subnetwork';
        n_subnetwork = size(all_complex_subnetwork, 2);

        % Determine linkage class and strong linkage class of the subnetwork
        [l_subnetwork, sl_subnetwork,~,~] = linkageClass(reactant_subnetwork, product_subnetwork);

        % Weak reversibility check
        is_weakly_reversible_subnetwork = sl_subnetwork == l_subnetwork;

        % Compute deficiency
        s_subnetwork = rank(N_subnetwork);
        deficiency_subnetwork = n_subnetwork - l_subnetwork - s_subnetwork;

        % Perform EFM-based network translation
        this_parent_indices = parent_indices(P{i});

        if is_weakly_reversible_subnetwork && deficiency_subnetwork == 0
            disp("Network is already weakly reverisble and deficiency 0.")
            Solution = [{reactant_subnetwork, product_subnetwork}];
            Index = this_parent_indices;
            skip = 0;
        else
            [Solution, Index, skip] = TranslationProgram(model_P(i), this_parent_indices);
        end

        if isempty(Solution)
            Solution = [];
            Index = [];
            skip = 0;
            return
        end

        % Store results
        Solution_all{i} = Solution;
        Index_all{i} = Index;
        Skip_all{i} = skip;
    end

    % Ensure all subnetworks use same species dimension
    numSpecies = size(model.species, 2);
    all_complexes = [];
    
    for i = 1:numel(Solution_all)
        R = Solution_all{i}{1};  % Reactant matrix of subnetwork i
        P = Solution_all{i}{2};  % Product matrix of subnetwork i

        % Pad with zeroes if needed
        if size(R,1) < numSpecies
            R = [R; zeros(numSpecies - size(R,1), size(R,2))];
        end
        if size(P,1) < numSpecies
            P = [P; zeros(numSpecies - size(P,1), size(P,2))];
        end
        
        % Collect complexes
        all_complexes = [all_complexes, R, P];

        % Overwrite with padded verisons
        Solution_all{i}{1} = R;
        Solution_all{i}{2} = P;
    end

    % Merge all translated subnetworks into one big network
    MergedReactant = [];
    MergedProduct = [];
    MergedIndexReactant = [];
    MergedIndexProduct = [];

    for i = 1:numel(Solution_all)
        MergedReactant = [MergedReactant, Solution_all{i}{1}];
        MergedProduct = [MergedProduct, Solution_all{i}{2}];

        % Track original reaction indices
        MergedIndexReactant   = [MergedIndexReactant, Index_all{i}];
        MergedIndexProduct   = [MergedIndexProduct, Index_all{i}];
    end

    % Convert to numeric array
    IR = cell2mat(MergedIndexReactant);
    IP = cell2mat(MergedIndexProduct);
    
    % Sort reactions according to original order
    [~, sortOrder] = sort(IR);
    
    % Reorder matrices
    MergedReactant = MergedReactant(:, sortOrder);
    MergedProduct  = MergedProduct(:, sortOrder);
    
    % Reorder indices as well
    MergedIndexReactant = num2cell(IR(sortOrder));
    MergedIndexProduct  = num2cell(IP(sortOrder));

    % Final output
    Solution = {MergedReactant, MergedProduct};
    Index    = {MergedIndexReactant, MergedIndexProduct};
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 11 of 19: TranslationProgram                                     %                              
%                                                                           %
%    - Purpose: To perform the EFM-based network translation procedure.     %
%    - Inputs                                                               %
%         - model: reaction network structure                               %
%         - parent_indices: reaction indices of the original network        %                                              
%    - Outputs                                                              %
%         - Solution: translated reactant and product complexes             %
%         - Index: cell array mapping translated reactions back to their    %
%               corresponding original reaction indices                     %
%         - skip: flag indicating if translation was skipped                %
%    - Used in TranslationProgramWithDecomp                                 %
%    - Notes                                                                %
%         - This function performs the two major steps of the EFM-based     %
%               translation procedure: computation of the EFMs and          %
%               construction of the reaction-to-reaction graph.             %
%         - The third step is implemented in a separate function            %
%               (TranslationComplex), which is called inside this function. %
%         - EFMs are computed using the canonical basis method (a variation % 
%               of the double description algorithm).                       %
%         - A binary optimization problem is formulated to construct the    %
%               reaction-to-reaction graph.                                 %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [Solution, Index, skip] = TranslationProgram(model, parent_indices)

    %
    % Preprocessing: ensure consistent species set
    %

    % Ensure model has valid species list
    % Rebuild is missing, otherwise use existing list to get species list and count
    if ~isfield(model, 'species') || isempty(model.species)
        [model, m] = modelSpecies(model); 
    else
        m = numel(model.species);      
    end

    % Build stoichiometric matrix
    [N,reactant_complex, product_complex,d] = stoichMatrix(model,m); % d is the number of reactions

    if d == 1
        disp("There is only one reaction.")
        disp("There is no valid weakly reversible and deficiency zero translation.")

        Solution = [];
        Index = [];
        skip = 0;
        return
    end

    % 
    % Compute EFMs via Double Description Method
    %

    % Initialize DD pair
    A_old = eye(d);
    A_init = eye(d);
    R_old = eye(d);

    k = d + 2;

    % Iteratively construct extreme rays
    while k < d + 2*m + 2
        % Select new constraint (row of N not yet used)
        available_vectors = setdiff(N, A_init, 'rows');

        if isempty(available_vectors)
            break;
        end

        new_vector = available_vectors(1, :);

        % Update constraint matrix
        A_new = [A_old; new_vector; -new_vector];
        A_init = [A_init; new_vector];

        % Partition rays into Lambda sets
        R_star = R_old;
        q_old = size(R_old, 2);

        Lambda_plus = [];
        Lambda_zero = [];
        Lambda_minus = [];

        for j = 1:q_old
            dot_product =  new_vector * R_old(:, j);
            if dot_product > 0
                Lambda_plus = [Lambda_plus, j];
            elseif dot_product == 0
                Lambda_zero = [Lambda_zero, j];
            else
                Lambda_minus = [Lambda_minus, j];
            end
        end

        % Generate candidate new rays
        for j_plus = Lambda_plus
            for j_minus = Lambda_minus
                r_new = (new_vector * R_old(:, j_plus)) * R_old(:, j_minus) - (new_vector * R_old(:, j_minus)) * R_old(:, j_plus);

                % Keep only extreme rays (rank test)
                if isExtremeRayRankTest(A_new, r_new, d)
                    R_star = [R_star r_new];
                end
            end
        end

        % Remove rays violating constraints
        R_new = R_star;
        columns_remove = union(Lambda_plus,Lambda_minus);
        R_new(:, columns_remove) = [];

        % Update iteration
        k = k + 2;
        R_old = R_new;
        A_old = A_new;
    end

    % Final set of EFMs
    R = R_old;

    % Check whether the computed set of EFMs is unitary
    [R_rows, R_cols] = size(R);

    for i = 1:R_rows
        for j = 1:R_cols
            if R(i,j) > 1
                disp("The set of EFMs is not unitary.")
                disp("The method cannot find a weakly reversible and deficiency zero translation.")

                Solution = [];
                Index = [];
                skip = 0;
                return
            end
        end
    end

    % 
    % Build reaction-to-reaction graph via a binary linear program 
    %

    [~,~,incidence, linkageClasses] = linkageClass(reactant_complex, product_complex);

    % Group reactions by source complex
    F = groupBySourceComplex(incidence);

    % Matrix of EFMs
    E = R';
    [numEFMs, numReactions] = size(E);

    % Define binary decision variables for the construction of the reaction-to-reaction graph
    x = optimvar('x', numReactions, numReactions, 'Type', 'integer', 'LowerBound', 0, 'UpperBound', 1);
    
    % Objective function
    objective = sum(x(:));
    
    % Initialize set of constraints
    constraints = [];
    inequalityConstraints = [];
    
    % Constraint set 1
    for k = 1:numEFMs
        activeReactions1 = find(E(k,:) == 1);
        numActive1 = length(activeReactions1);
    
        excludeDiagonals1 = ones(numActive1,numActive1) - eye(numActive1);
        constraints = [constraints; sum(x(activeReactions1, activeReactions1) .* ...
            excludeDiagonals1, 'all') == numActive1];
    end
    
    % Constraint set 2 and 3
    for i = 1:numEFMs
        activeReactions2 = find(E(i,:) == 1);
        numActive2 = length(activeReactions2);
    
        for k = activeReactions2
            constraints = [constraints; sum(x(k,activeReactions2)) - x(k,k) == 1];
            constraints = [constraints; sum(x(activeReactions2,k)) - x(k,k) == 1]; 
        end
    end
    
    % Constraint set 4
    for k = 1:numEFMs
        activeReactions3 = find(E(k, :) == 1);
        numActive3 = length(activeReactions3);
    
        if numActive3 >= 4 
            halfSize = floor(length(activeReactions3) / 2);
    
            for subSize = 2:halfSize
                subsets = nchoosek(activeReactions3, subSize);
    
                for s = 1:size(subsets, 1)
                    subsetReactions = subsets(s, :);
                    numSubset = length(subsetReactions);
                    excludeDiagonals2 = ones(numSubset,numSubset) - eye(numSubset);
    
                    ineq = sum(x(subsetReactions, subsetReactions) .* excludeDiagonals2, 'all') <= subSize - 1;
                    inequalityConstraints = [inequalityConstraints; ineq];
                end
            end
        end
    end
    
    % Constraint set 5
    for l = 1:length(F)
        for i = 1:length(F{l})
            for j = i+1:length(F{l})
                constraints = [constraints; x(:,F{l}(i)) == x(:,F{l}(j))];
            end
        end
    end
    
    % Constraint set 6
    equivClass = 1:numEFMs;
    
    for i = 1:numEFMs
        for j = i+1:numEFMs
            if any(E(i,:) & E(j,:))
                equivClass = merge(i, j, equivClass);
            end
        end
    end
    

    for i = 1:numEFMs
        for j = i+1:numEFMs
            for u = 1:length(F)
                if any(E(i,F{u})) && any(E(j,F{u}))
                    equivClass = merge(i, j, equivClass);
                end
            end
        end
    end
    
    for k = 1:numEFMs
        for l = k+1:numEFMs
            if findRoot(k, equivClass) ~= findRoot(l, equivClass)
                reactionsK = find(E(k,:) == 1);
                reactionsL = find(E(l,:) == 1);
                for u = 1:length(reactionsK)
                    for v = 1:length(reactionsL)
                        constraints = [constraints; x(reactionsK(u), reactionsL(v)) == 0];
                    end
                end
            end
        end
    end
    
    % Solve the binary linear programming problem
    problem = optimproblem('Objective', objective, ...
        'Constraints', struct('eqConstraints', constraints, 'ineqConstraints', inequalityConstraints));
    xOpt = solve(problem, 'Options', optimoptions('intlinprog', 'Display', 'off'));

    X = xOpt.x;

    % Ensure that the binary linary program has a solution
    if isempty(X)
        disp("Binary linear program has no solution.")
        disp("A valid reaction-to-reaction graph cannot be constructed.")

        Solution = [];
        Index = [];
        skip = 0;
        return
    end

    if isvector(X)
        X = reshape(X, numReactions, numReactions);
    end
    
    % Extract reaction-to-reaction graph edges
    [source, target] = find(X); 
    edges = [source, target]; 

    % 
    % Determine translation complexes
    %

    sourceComplexes = reactant_complex';
    productComplexes = product_complex';

    numSpecies = size(sourceComplexes, 2);
    numReactions = size(sourceComplexes, 1);
    numEdgesRR = size(edges, 1);

    % Build linear system 
    A = zeros(numEdgesRR, numReactions);
    b = zeros(numEdgesRR, numSpecies);
    
    for k = 1:numEdgesRR
        i = edges(k,1); 
        j = edges(k,2);
    
        A(k,i) = 1; 
        A(k,j) = -1;
        b(k,:) = sourceComplexes(j,:) - productComplexes(i,:);
    end
    
    % Check consistency of linear system
    if rank(A) ~= rank([A b])
        disp("The method cannot find a weakly reversible and deficiency zero translation.")

        Solution = [];
        Index = [];
        skip = 0;
        return
    end
    
    % Ensure that the resulting network is weakly reversible and deficiency zero
    maxTries = 1000;
    for attempt = 1:maxTries
        [alpha, translatedSource, translatedProduct, Solution, Index] = TranslationComplex(edges, sourceComplexes, productComplexes, linkageClasses);
        [l, sl] = linkageClass(translatedSource', translatedProduct');
        
        if l == sl
            fprintf("We found a weakly reversible and deficiency zero translation. \n");
            break;
        elseif attempt == maxTries
            warning("The method cannot find a weakly reversible and deficiency zero translation.");
        end
    end

    % Display translated reactions
    speciesNames = model.species;
    for i = 1:size(sourceComplexes, 1)
        reactant = complexToString(translatedSource(i, :), speciesNames);
        product  = complexToString(translatedProduct(i, :), speciesNames);

        fprintf('R%d: %s -> %s\n', parent_indices{i}, reactant, product);
    end
    
    % Final outputs
    Index = parent_indices; 
    skip = 0;

end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 12 of 19: ZeroSet                                                %                              
%                                                                           %
%    - Purpose: To determine the indices of the row vectors of A that are   %
%               satisfied by v with equality.                               %
%    - Inputs                                                               %
%         - A: matrix whose rows are tested                                 %
%         - v: vector used for dot product evaluation                       %                                              
%    - Output                                                               %
%         - Z: indices of rows of A whose dot product with v is zero        %
%    - Used in isExtremeRayRankTest                                         %
%    - Notes                                                                %
%         - A tolerance is used in checking whether the dot product is zero %
%               to ensure numerical stability in computations.              %                  
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function Z = ZeroSet(A, v)
    % Compute the dot product of each row of A with v
    row_products = A*v;

    % Find the indices where A_i * v = 0
    Z = find(abs(row_products) < 1e-16); % Use tolerance for numerical stability
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 13 of 19: isExtremeRayRankTest                                   %                              
%                                                                           %
%    - Purpose: To determine whether a candidate vector is an EFM           %
%    - Inputs                                                               %
%         - A_new: constraint matrix                                        %
%         - r_new: candidate ray vector                                     %
%         - d: number of reactions in the network                           %                    
%    - Output                                                              %
%         - flag: logical value indicating whether r_new is an EFM          %
%    - Used in TranslationProgram                                           %                 
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function flag = isExtremeRayRankTest(A_new, r_new, d)

    % Compute the zero set of the candidate ray
    zero_set = ZeroSet(A_new, r_new);

    % Construct the zero-set matrix
    A_zeroset = A_new(zero_set, :);
  
    % Rank test for extremeness
    flag = rank(A_zeroset) == d - 1;
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 14 of 19: groupBySourceComplex                                   %                              
%                                                                           %
%    - Purpose: To group reactions of the reaction network according to     %
%               their source complex                                        %
%    - Input                                                                %
%         - incidence: incidence matrix                                     %                                            
%    - Output                                                               %
%         - F: cell array where each entry contains indices of reactions    %
%              sharing the same source complex                              %
%    - Used in TranslationProgram                                           %                 
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function F = groupBySourceComplex(incidence)

    [n, r] = size(incidence);
    source_indices = zeros(1, r);
    
    % Extract the index of source complex for each reaction
    for j = 1:r
        source_indices(j) = find(incidence(:, j) == -1);
    end

    % Determine unique source complexes
    [unique_sources, ~, group_ids] = unique(source_indices);

    % Group reactions by source complex
    F = cell(1, length(unique_sources));
    for i = 1:length(unique_sources)
        F{i} = find(group_ids == i);
    end
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 15 of 19: findRoot                                               %                              
%                                                                           %
%    - Purpose: To track equivalence classes of EFMs                        %
%    - Inputs                                                               %
%         - i: index of the EFM                                             %
%         - classVec: vector defining equivalence classes                   %                                      
%    - Output                                                              %
%         - root: representative of the equivalence class containing        %
%              EFM i                                                        %
%    - Used in                                                              %
%         - TranslationProgram                                              %
%         - merge                                                           %
%    - Notes                                                                %
%         - EFMs are grouped into equivalence classes based on shared       %
%              reactions and common source complexes.                       %
%         - This function determines whether two EFMs belong to the same    %
%              equivalence class, a requirement for enforcing constraints   %
%              in the binary linear program used to construct the           %
%              reaction-to-reaction graph.                                  %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function root = findRoot(i, classVec)
    while classVec(i) ~= i
        i = classVec(i);
    end
    root = i;
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 16 of 19: merge                                                  %                              
%                                                                           %
%    - Purpose: To merge the equivalence classes of two EFMs                %
%    - Inputs                                                               %
%         - i: index of the first EFM                                       %
%         - j: index of the second EFM                                      %
%         - classVec: vector defining equivalence classes                   %                                      
%    - Output                                                               %
%         - classVec: updated vector after merging the equivalence          %
%               classes of EFM i and EFM j                                  %                   
%    - Used in TranslationProgram                                           %
%    - Notes                                                                %
%         - EFMs are merged into the same class if they share reactions or  %
%               are connected via common source complexes.                  %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function classVec = merge(i, j, classVec)

    % Determine the representative elements of the classes containing EFM i and EFM j
    rootI = findRoot(i, classVec);
    rootJ = findRoot(j, classVec);

    % Merge equivalence classes of EFM i and EFM j into one equivalence class
    if rootI ~= rootJ
        classVec(rootJ) = rootI;
    end
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 17 of 19: TranslationComplex                                     %                              
%                                                                           %
%    - Purpose: To determine translation complexes in the network           %
%               translation procedure                                       %
%    - Inputs                                                               %
%         - edges: edge list of the reaction-to-reaction graph              %
%         - sourceComplexes: original reactant complexes                    %
%         - productComplexes: original product complexes                    %
%         - linkageClasses: list of linkage classes                         %                                      
%    - Outputs                                                              %
%         - alphaAdjusted: translation complexes applied to reactions       %
%         - translatedSource: translated reactant complexes                 %
%         - translatedProduct: translated product complexes                 %
%         - Solution: translated network                                    %
%         - Index: mapping of reactions to complexes                        %                   
%    - Used in TranslationProgram                                           %
%    - Notes                                                                %
%         - This is the third step in the overall translation procedure.    %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [alphaAdjusted, translatedSource, translatedProduct, Solution, Index] = TranslationComplex(edges, sourceComplexes, productComplexes, linkageClasses)
    
    % Initialize matrix of translation complexes
    numReactions = size(sourceComplexes, 1);
    numSpecies = size(sourceComplexes, 2);
    alpha = NaN(numReactions, numSpecies);

    % Build sparse adjacency matrix for reaction-to-reaction graph
    edgeMap = sparse(edges(:,1), edges(:,2), 1, numReactions, numReactions);

    % Boolean array to track unprocessed reactions
    P = true(1, numReactions); 

    % Start of the graph traversal algorithm
    while any(P)
        ri = find(P, 1);      % Pick first unprocessed reaction  
        alpha(ri,:) = 0;      % Initialize it as the zero translation complex
        P(ri) = false;        % Mark as processed
        Pprime = ri;          % Prepare for breadth-first search (BFS)

        % BFS proceudre
        while ~isempty(Pprime)
            Pprime2 = [];
            for ri = Pprime
                neighbors = find(edgeMap(ri,:));
                for rj = neighbors
                    if P(rj) % If reaction is unprocessed 
                        % Compute translation complex
                        alpha(rj,:) = productComplexes(ri,:) - sourceComplexes(rj,:) + alpha(ri,:);
                        Pprime2(end+1) = rj;
                        P(rj) = false; % Mark as processed
                    end
                end
            end
            Pprime = Pprime2;
        end
    end

    % Apply translation complexes to network
    translatedSource = sourceComplexes + alpha;
    translatedProduct = productComplexes + alpha;

    % Ensure nonnegativity within each linkage class 
    updatedlinkageClasses = computeLinkageClassesByReactions(translatedSource,translatedProduct);

    for k = 1:length(updatedlinkageClasses)
        classReactions = updatedlinkageClasses{k};
        allComplexes = [translatedSource; translatedProduct];

        % Compute the minimum values for each species across all complexes
        minVals = min(allComplexes, [], 1);

        % Shift to ensure nonnegativity
        shift = max(0, -minVals); 
        alpha(classReactions,:) = alpha(classReactions,:) + shift;
    end

    % Apply the shift across all reactions in the translated network
    alphaAdjusted = alpha;
    translatedSource = sourceComplexes + alphaAdjusted;
    translatedProduct = productComplexes + alphaAdjusted;

    % Initialize outputs
    Solution = [];
    Index = [];
 
    % Find unique complexes and index mapping
    complexes_tmp = [translatedSource; translatedProduct];
    [complexes_unique, ~, ic] = unique(complexes_tmp, 'rows');
       
    % Get indices of source and product complexes in the unique list
    [numReactions, numSpecies] = size(sourceComplexes);
    source_indices = ic(1:numReactions);             
    product_indices = ic(numReactions+1:end);   
    
    % Create matrices of unique complexes
    sources_unique = complexes_unique(source_indices, :)';
    products_unique = complexes_unique(product_indices, :)';
    
    % Store the translated network
    Solution = [Solution; {sources_unique, products_unique}];
    
    % Construct index mapping
    K_trans = size(complexes_unique, 1);
    indexset = cell(1, K_trans);
    for j = 1:numReactions
        indexset{source_indices(j)} = [indexset{source_indices(j)}, j];
        indexset{product_indices(j)} = [indexset{product_indices(j)}, j];
    end
    
    Index = [Index; indexset];

end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 18 of 19: computeLinkageClassesByReactions                       %                              
%                                                                           %
%    - Purpose: To group reactions of the reaction network into its         %
%               linkage classes                                             %
%    - Inputs                                                               %
%         - sourceComplexes: reactant complexes                             %
%         - productComplexes: product complexes                             %                                     
%    - Output                                                               %
%         - reactionClasses: cell array where each cell contains indices of %
%               reactions belonging to the same linkage class               %                   
%    - Used in TranslationComplex                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function reactionClasses = computeLinkageClassesByReactions(sourceComplexes, productComplexes)

    % Stack reactant and product complexes into a single matrix
    allComplexes = [sourceComplexes; productComplexes];

    % Find unique complexes and assign an ID
    [uniqueComplexes, ~, complexIDs] = unique(allComplexes, 'rows', 'stable');

    % Number of reactions in the network
    numReactions = size(sourceComplexes, 1);

    % Map reactant and product complexes to unique IDs
    srcIDs = complexIDs(1:numReactions); % IDs of the source complexes
    tgtIDs = complexIDs(numReactions+1:end); % IDs of the product complexes

    % Create directed graph
    G = digraph(srcIDs, tgtIDs, [], size(uniqueComplexes, 1));

    % Convert to undirected graph for the determination of the linkage classes
    UG = graph(G.adjacency | G.adjacency');

    % Determine linkage classes
    complexToClass = conncomp(UG);

    % Assign each reaction to its linkage class
    reactionClassLabels = complexToClass(srcIDs);

    % Group reaction indices according to their corresponding linkage classes
    numClasses = max(reactionClassLabels);
    reactionClasses = cell(numClasses, 1);

    for i = 1:numClasses
        reactionClasses{i} = find(reactionClassLabels == i);
    end
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 19 of 19: complexToString                                        %                              
%                                                                           %
%    - Purpose: To convert a numeric complex vector into a human-readable   %
%               string using species names.                                 %
%    - Inputs                                                               %
%         - vec: vector representing a complex                              %
%         - speciesNames: cell array containing names of species            %                                     
%    - Output                                                               %
%         - str: string representation of the complex                       %                   
%    - Used in TranslationProgram                                           %
%    - Notes                                                                %
%         - If the complex is empty, output is '0'.                         %
%         - Species of coefficients 1 are not explicitly printed.           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function str = complexToString(vec, speciesNames)

    % Initialize cell array to hold terms of the complex
    terms = {};

    % Loop over species in the complexes
    for i = 1:length(vec)
        if vec(i) == 1
            % Coefficient of the species in a complex is 1: only include species name
            terms{end+1} = speciesNames{i}; 
        elseif vec(i) > 1
            % Coefficient of the species in a complex is greater than 1: include coefficient and species name
            terms{end+1} = sprintf('%d%s', vec(i), speciesNames{i});
        end
    end

    % Combine terms as a single string
    if isempty(terms)
        str = '0';
    else
        str = strjoin(terms, ' + ');
    end
end