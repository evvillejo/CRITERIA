% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16
syms K M X XK XM Xp XpK XpM Xpp XppM XpsM
syms sigma1

% ODEs
odeK = k2*XK + k3*XK + k5*XpK + k6*XpK - K*k1*X - K*k4*Xp;
odeM = k15*XM + k10*XpM + k8*XppM + k13*XpsM - k16*M*X - k11*M*Xp - k12*M*Xp - k7*M*Xpp;
odeX = k2*XK + k15*XM - K*k1*X - k16*M*X;
odeXK = K*k1*X - k3*XK - k2*XK;
odeXM = k14*XpsM - k15*XM + k16*M*X;
odeXp = k3*XK + k5*XpK + k10*XpM + k13*XpsM - K*k4*Xp - k11*M*Xp - k12*M*Xp;
odeXpK = K*k4*Xp - k6*XpK - k5*XpK;
odeXpM = k9*XppM - k10*XpM + k11*M*Xp;
odeXpp = k6*XpK + k8*XppM - k7*M*Xpp;
odeXppM = k7*M*Xpp - k9*XppM - k8*XppM;
odeXpsM = k12*M*Xp - k14*XpsM - k13*XpsM;

% Solution
sigma2 = (k4*k6*k12*k14*k16*sigma1*(k2 + k3)*(k8 + k9))/(k1*k3*k7*k9*k11*(k5 + k6)*(k13 + k14));

K = (XpM*k7*k9*k10*k11*(k5 + k6))/(Xpp*k4*k6*sigma1*(k7*k9 + k8*sigma1 + k9*sigma1));
M = (XpM*k10*(k8 + k9))/(Xpp*(k7*k9 + k8*sigma1 + k9*sigma1));
X = (Xpp*sigma1*sigma2)/(k11*k16);
XK = (XpM*k10*k12*k14*sigma1*(k8 + k9))/(k3*k11*(k13 + k14)*(k7*k9 + k8*sigma1 + k9*sigma1));
XM = (XpM*k10*sigma1*(k8 + k9)*(k12*k14 + k13*sigma2 + k14*sigma2))/(k11*k15*(k13 + k14)*(k7*k9 + k8*sigma1 + k9*sigma1));
Xp = (Xpp*sigma1)/k11;
XpK = (XpM*k7*k9*k10)/(k6*(k7*k9 + k8*sigma1 + k9*sigma1));
XppM = (XpM*k7*k10)/(k7*k9 + k8*sigma1 + k9*sigma1);
XpsM = (XpM*k10*k12*sigma1*(k8 + k9))/(k11*(k13 + k14)*(k7*k9 + k8*sigma1 + k9*sigma1));

% Check
checkK  = simplify(subs(odeK))
checkM  = simplify(subs(odeM))
checkX  = simplify(subs(odeX))
checkXK  = simplify(subs(odeXK))
checkXM  = simplify(subs(odeXM))
checkXp  = simplify(subs(odeXp))
checkXpK  = simplify(subs(odeXpK))
checkXpM  = simplify(subs(odeXpM))
checkXpp  = simplify(subs(odeXpp))
checkXppM  = simplify(subs(odeXppM))
checkXpsM  = simplify(subs(odeXpsM))