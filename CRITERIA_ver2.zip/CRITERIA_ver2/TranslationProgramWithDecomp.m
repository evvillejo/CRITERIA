% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    REWARDZ (tRanslation via Elementary flux modes towards WeAkly           %
%               Reversible Deficiency Zero network)                         %
%                                                                           %
%    Main Function: TranslationProgramWithDecomp                            %
%                                                                           %
%                                                                           %
% OUTPUT: Returns a weakly reversible and deficiency zero translation of a  %
%         given reaction network using the elementary flux mode-based       %
%         method as outlined in the main paper together with network        %
%         decomposition. The output variables 'N', 'R', 'x',                %
%         'translatedSource', 'translatedProduct', and 'Index_all' allow    %
%         the user to view the following, respectively:                     %                
%       - Stoichiometric matrix of the network                              %
%       - Set of EFMs                                                       %
%       - BLP solution in the construction of the reaction-to-reaction      %
%         graph                                                             %
%       - Matrix of translated source complexes                             %
%       - Matrix of translated product complexes                            %
%       - Cell array mapping translated reactions back to their             %
%               corresponding original reaction indices                     %               %
%    Finally, the elapsed time for producing the output is also displayed   % 
%    using MATLAB's built-in tic and toc functions.                         %
%                                                                           %
% INPUT: model: a structure, representing the CRN (see README.txt for       %
%    details on how to fill out the structure)                              %
%                                                                           %
% Notes:                                                                    %    
%    1. This function is part of the workflow of CRITERIA which computes    %
%          the analytic equilibria of the reaction network.                 %
%    2. Unlike the function TranslationProgram, this function incorporates  %
%          network decompostion in its procedure.                           %
%    3. There are four major steps in the whole procedure: decomposition of %
%          the network into its finest independent subnetworks, computation %
%          of the EFMs per subnetwork, construction of reaction-to-reaction %
%          graph (via solving a BLP) per subnetwork , and determination of  %
%          the translation complexes (via a graph traversal method) per     %
%          subnetwork.                                                      %
%    4. Decomposition into the finest independent decomposition comes from  %
%          [1].                                                             %
%    5. EFMs are computed using the Canonical Basis Method (a variant of    %
%          the Double Description Method) [2].                              %
%    6. More details on the formulation of the BLP can be found on [3].     %
%    7. The graph traversal algorithm for determining the translation       % 
%          complexes can be found in [3].                                   %
%                                                                           %
% References                                                                %
%    [1] Hernandez B, De la Cruz R (2021) Independent decompositions of     %
%           chemical reaction networks. Bull Math Biol 83(76):1–23.         %
%           https://doi.org/10.1007/s11538-021-00906-3                      %
%    [2] Klapper I, Szyld DB, Zhao K. Metabolic networks, elementary flux   %
%          modes, and polyhedral cones Society for Industrial and Applied   %
%          Mathematics; 2021.                                               %
%    [3] Johnston MD, Burton E. Computing weakly reversible deficiency      %
%          zero network translations using elementary flux modes Bull Math  %
%          Biol. 2019;81:1613–1644.                                         %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [N, R, x, translatedSource, translatedProduct, Index_all] = TranslationProgramWithDecomp(model)
    tic

    % Decompose the network into its finest independent subnetworks
    [model, N, R, G, P] = indepDecomp(model);

    % Extract species and stoichiometric information of the original network
    [model,m] = modelSpecies(model);
    [N,~,~,r] = stoichMatrix(model,m);

    
    if numel(P) == 1
        fprintf('The network has no nontrival independent decomposition.\n\n')
    else
        fprintf('The network has %d subnetworks.\n\n', numel(P))
    end

    % Build a reaction index list
    reac_num = [ ];
    parent_indices = {};  
    for i = 1:numel(model.reaction)
        if model.reaction(i).reversible == 0
            reac_num(end+1) = i;
            parent_indices{end+1} = i;
        else
            reac_num(end+1) = i;
            parent_indices{end+1} = i;

            reac_num(end+1) = i;
            parent_indices{end+1} = i;
        end
    end

    % Initialize storage for outputs
    Index_all = cell(1, numel(P));

    for i = 1:numel(P)
        % Get the corresponding reactions of the subnetwork from the parent network
        model_P(i).id = [model.id ' - Subnetwork ' num2str(i)];
        model_P(i).species = { };
        reac_P = unique(reac_num(P{i}));
        for j = 1:numel(reac_P)
            model_P(i).reaction(j) = model.reaction(reac_P(j));
        end

        % Rebuild reaction list
        reac_num_ = [ ];
        for j = 1:numel(model_P(i).reaction)
            if model_P(i).reaction(j).reversible == 0
                reac_num_(end+1) = j;
            else
                reac_num_(end+1) = j;
                reac_num_(end+1) = j;
            end
        end

        % Get the unique reaction numbers
        reac_num_unique = unique(reac_num_);

        % Create list of reactions of the subnetwork
        reac_subnetwork = { };
        for j = 1:numel(reac_num_unique)
            if model_P(i).reaction(reac_num_unique(j)).reversible == 1
                split_complex = split(model_P(i).reaction(reac_num_unique(j)).id, '<->');

                reac_subnetwork{end+1} = [split_complex{1}, '->', split_complex{2}];
                reac_subnetwork{end+1} = [split_complex{2}, '->', split_complex{1}];
            else
                reac_subnetwork{end+1} = model_P(i).reaction(reac_num_unique(j)).id;
            end
        end

        % Get the reaction numbers from the independent decomposition
        P_ = P{i};
    
        if numel(P) == 1
            fprintf('- Network -\n\n')
        else
            fprintf('- Subnetwork %d -\n\n', i)
        end

        % Show reactions of the subnetwork
        for j = 1:numel(P_)
            fprintf('R%d: %s\n', P_(j), reac_subnetwork{j})
        end

        if numel(P) == 1
            fprintf('\nSolving the network...\n\n')
        else
            fprintf('\nSolving Subnetwork %d...\n\n', i)
        end

        % Have subnetwork use the global species list
        model_P(i).species = model.species;  
        m_subnetwork = numel(model.species);

        % Build stoichiometric matrix of the subnetwork
        [N_subnetwork,reactant_subnetwork, product_subnetwork,~] = stoichMatrix(model_P(i), m_subnetwork);

        % Get number of complexes
        all_complex_subnetwork = unique([reactant_subnetwork product_subnetwork]', 'rows');
    
        all_complex_subnetwork = all_complex_subnetwork';
        n_subnetwork = size(all_complex_subnetwork, 2);

        % Determine linkage class and strong linkage class of the subnetwork
        [l_subnetwork, sl_subnetwork,~,~] = linkageClass(reactant_subnetwork, product_subnetwork);

        % Weak reversibility check
        is_weakly_reversible_subnetwork = sl_subnetwork == l_subnetwork;
   
        % Compute deficiency
        s_subnetwork = rank(N_subnetwork);
        deficiency_subnetwork = n_subnetwork - l_subnetwork - s_subnetwork;

        % Perform EFM-based network translation
        this_parent_indices = parent_indices(P{i});

        if is_weakly_reversible_subnetwork && deficiency_subnetwork == 0
            disp("Network is already weakly reverisble and deficiency 0.")
            Index = this_parent_indices;
        else
            [N, R, x, translatedSource, translatedProduct] = TranslationProgram(model_P(i), this_parent_indices);
        end
    end
    toc
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% %                                                   % %
% % The following are functions used in the procedure % %
% %                                                   % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % %

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 1 of 13: TranslationProgram                                      %                              
%                                                                           %
%    - Purpose: To perform the EFM-based network translation procedure.     %
%    - Inputs                                                               %
%         - model: reaction network structure                               %
%         - parent_indices: reaction indices of the original network        %
%    - Outputs                                                              %
%         - N: stoichiometric complex of the network                        %
%         - R: Set of EFMs                                                  %
%         - x: BLP solution in the construction of the reaction-to-reaction %
%              graph                                                        %
%         - translatedSource: Matrix of translated source complexes         %
%         - translatedProduct: Matrix of translated product complexes       %
%    - Used in TranslationProgramWithDecomp                                 %
%    - Notes                                                                %
%         - This function performs the two major steps of the EFM-based     %
%               translation procedure: computation of the EFMs and          %
%               construction of the reaction-to-reaction graph.             %
%         - The third step is implemented in a separate function            %
%               (TranslationComplex), which is called inside this function. %  
%         - EFMs are computed using the canonical basis method (a variation % 
%               of the double description algorithm).                       %
%         - A binary optimization problem is formulated to construct the    %
%               reaction-to-reaction graph.                                 %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [N, R, x, translatedSource, translatedProduct] = TranslationProgram(model, parent_indices)

    %
    % Preprocessing: ensure consistent species set
    %

    % Ensure model has valid species list
    % Rebuild is missing, otherwise use existing list to get species list and count
    if ~isfield(model, 'species') || isempty(model.species)
        [model, m] = modelSpecies(model); 
    else
        m = numel(model.species);      
    end
    
    % Build stoichiometric matrix
    [N,reactant_complex, product_complex,d] = stoichMatrix(model,m); % d is the number of reactions

    if d == 1
        disp("There is only one reaction.")
        disp("There is no valid weakly reversible and deficiency zero translation.")

        R = [];
        x = [];
        translatedSource = [];
        translatedProduct = [];
        return
    end

    % 
    % Compute EFMs via Double Description Method
    %

    R = [];
    x = [];
    translatedSource = [];
    translatedProduct = [];

    % Initialize DD pair
    A_old = eye(d);
    A_init = eye(d);
    R_old = eye(d);
    k = d + 2;

    % Iteratively construct extreme rays
    while k < d + 2*m + 2
        % Select new constraint (row of N not yet used)
        available_vectors = setdiff(N, A_init, 'rows');

        if isempty(available_vectors)
            break;
        end
        
        new_vector = available_vectors(1, :);

        % Update constraint matrix
        A_new = [A_old; new_vector; -new_vector];
        A_init = [A_init; new_vector];

        % Partition rays into Lambda sets
        R_star = R_old;
        q_old = size(R_old, 2);

        Lambda_plus = [];
        Lambda_zero = [];
        Lambda_minus = [];

        for j = 1:q_old
            dot_product =  new_vector * R_old(:, j);
            if dot_product > 0
                Lambda_plus = [Lambda_plus, j];
            elseif dot_product == 0
                Lambda_zero = [Lambda_zero, j];
            else
                Lambda_minus = [Lambda_minus, j];
            end
        end

        % Generate candidate new rays
        for j_plus = Lambda_plus
            for j_minus = Lambda_minus
                r_new = (new_vector * R_old(:, j_plus)) * R_old(:, j_minus) - (new_vector * R_old(:, j_minus)) * R_old(:, j_plus);

                % Keep only extreme rays (rank test)
                if isExtremeRayRankTest(A_new, r_new, d)
                    R_star = [R_star r_new];
                end
            end
        end

        % Remove rays violating constraints
        R_new = R_star;
        columns_remove = union(Lambda_plus,Lambda_minus);
        R_new(:, columns_remove) = [];

        % Update iteration
        k = k + 2;
        R_old = R_new;
        A_old = A_new;
    end

    % Final set of EFMs
    R = R_old;

    % Check whether the computed set of EFMs is unitary
    [R_rows, R_cols] = size(R);

    for i = 1:R_rows
        for j = 1:R_cols
            if R(i,j) > 1
                disp("Set of EFMs is not unitary.")
                disp("Method cannot find a weakly reversible and deficiency zero translation.")

                R = [];
                x = [];
                translatedSource = [];
                translatedProduct = [];
                return
            end
        end
    end
    
    % 
    % Build reaction-to-reaction graph via a binary linear program 
    %
    
    [~,~,incidence, linkageClasses] = linkageClass(reactant_complex, product_complex);

    % Group reactions by source complex
    F = groupBySourceComplex(incidence);

    % Matrix of EFMs
    E = R';
    [numEFMs, numReactions] = size(E);

    % Define binary decision variables for edges in the reaction-to-reaction graph
    x = optimvar('x', numReactions, numReactions, 'Type', 'integer', 'LowerBound', 0, 'UpperBound', 1);
    
    % Objective function
    objective = sum(x(:));
    
    % Initialize set of constraints
    constraints = [];
    inequalityConstraints = [];
    
    % Constraint set 1
    for k = 1:numEFMs
        activeReactions1 = find(E(k,:) == 1);
        numActive1 = length(activeReactions1);
    
        excludeDiagonals1 = ones(numActive1,numActive1) - eye(numActive1);
        constraints = [constraints; sum(x(activeReactions1, activeReactions1) .* ...
            excludeDiagonals1, 'all') == numActive1];
    end
    
    % Constraint set 2 and 3
    for i = 1:numEFMs
        activeReactions2 = find(E(i,:) == 1);
        numActive2 = length(activeReactions2);
    
        for k = activeReactions2
            constraints = [constraints; sum(x(k,activeReactions2)) - x(k,k) == 1]; % Constraint set #6
            constraints = [constraints; sum(x(activeReactions2,k)) - x(k,k) == 1]; % Constraint set #5
        end
    end
    
    % Constraint set 4
    for k = 1:numEFMs
        activeReactions3 = find(E(k, :) == 1);
        numActive3 = length(activeReactions3);
    
        if numActive3 >= 4 
            halfSize = floor(length(activeReactions3) / 2);
    
            for subSize = 2:halfSize
                subsets = nchoosek(activeReactions3, subSize);
    
                for s = 1:size(subsets, 1)
                    subsetReactions = subsets(s, :);
                    numSubset = length(subsetReactions);
                    excludeDiagonals2 = ones(numSubset,numSubset) - eye(numSubset);
    
                    ineq = sum(x(subsetReactions, subsetReactions) .* excludeDiagonals2, 'all') <= subSize - 1;
                    inequalityConstraints = [inequalityConstraints; ineq];
                end
            end
        end
    end
    
    % Constraint set 5
    for l = 1:length(F)
        for i = 1:length(F{l})
            for j = i+1:length(F{l})
                constraints = [constraints; x(:,F{l}(i)) == x(:,F{l}(j))];
            end
        end
    end
    
    % Constraint set 6
    equivClass = 1:numEFMs;
    
    for i = 1:numEFMs
        for j = i+1:numEFMs
            if any(E(i,:) & E(j,:))
                equivClass = merge(i, j, equivClass);
            end
        end
    end
    
    for i = 1:numEFMs
        for j = i+1:numEFMs
            for u = 1:length(F)
                if any(E(i,F{u})) && any(E(j,F{u}))
                    equivClass = merge(i, j, equivClass);
                end
            end
        end
    end
    
    for k = 1:numEFMs
        for l = k+1:numEFMs
            if findRoot(k, equivClass) ~= findRoot(l, equivClass)
                reactionsK = find(E(k,:) == 1);
                reactionsL = find(E(l,:) == 1);
                for u = 1:length(reactionsK)
                    for v = 1:length(reactionsL)
                        constraints = [constraints; x(reactionsK(u), reactionsL(v)) == 0];
                    end
                end
            end
        end
    end
    
    % Solve the binary linear programming problem
    problem = optimproblem('Objective', objective, ...
        'Constraints', struct('eqConstraints', constraints, 'ineqConstraints', inequalityConstraints));
    xOpt = solve(problem, 'Options', optimoptions('intlinprog', 'Display', 'off'));

    X = xOpt.x;

    % Ensure that the binary linary program has a solution
    if isempty(X)
        disp("LP problem has no solution.")

        R = [];
        x = [];
        translatedSource = [];
        translatedProduct = [];
        return
    end

    if isvector(X)
        X = reshape(X, numReactions, numReactions);
    end
    
    % Extract edges from non-zero entries
    [source, target] = find(X); 
    edges = [source, target]; 

    % 
    % Determine translation complexes
    %

    sourceComplexes = reactant_complex';
    productComplexes = product_complex';

    numSpecies = size(sourceComplexes, 2);
    numReactions = size(sourceComplexes, 1);
    numEdgesRR = size(edges, 1);

    % Build linear system
    A = zeros(numEdgesRR, numReactions);
    b = zeros(numEdgesRR, numSpecies);
    
    for k = 1:numEdgesRR
        i = edges(k,1); 
        j = edges(k,2);
    
        A(k,i) = 1; 
        A(k,j) = -1;
        b(k,:) = sourceComplexes(j,:) - productComplexes(i,:);
    end
    
   % Check consistency of linear system
    if rank(A) ~= rank([A b])
        disp("The network does not admit a weakly reversible and deficiency zero translation.")

        R = [];
        x = [];
        translatedSource = [];
        translatedProduct = [];
        return
    end
    
    % Ensure that the resulting network is weakly reversible and deficiency zero
    maxTries = 1000;
    for attempt = 1:maxTries
        [alpha, translatedSource, translatedProduct] = TranslationComplex(edges, sourceComplexes, productComplexes, linkageClasses);
        [l, sl] = linkageClass(translatedSource', translatedProduct');
        
        if l == sl
            fprintf("We found a weakly reversible and deficiency zero translation. \n");
            break;
        elseif attempt == maxTries
            warning("Max attempts reached without finding a weakly reversible and deficiency zero translation.");
        end
    end

    % Display translated reactions
    speciesNames = model.species;
    for i = 1:size(sourceComplexes, 1)
        reactant = complexToString(translatedSource(i, :), speciesNames);
        product  = complexToString(translatedProduct(i, :), speciesNames);

        fprintf('R%d: %s -> %s\n', parent_indices{i}, reactant, product);
    end

    Index = parent_indices;
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 2 of 13: ZeroSet                                                 %                              
%                                                                           %
%    - Purpose: To determine the indices of the row vectors of A that are   %
%               satisfied by v with equality.                               %
%    - Inputs                                                               %
%         - A: matrix whose rows are tested                                 %
%         - v: vector used for dot product evaluation                       %                   
%    - Output                                                               %
%         - Z: indices of rows of A whose dot product with v is zero        %
%    - Used in isExtremeRayRankTest                                         %
%    - Notes                                                                %
%         - A tolerance is used in checking whether the dot product is zero %
%               to ensure numerical stability in computations.              %                  
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function Z = ZeroSet(A, v)
    % Compute the dot product of each row of A with v
    row_products = A*v;

    % Find the indices where A_i * v = 0
    Z = find(abs(row_products) < 1e-16); % Use tolerance for numerical stability
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 3 of 13: isExtremeRayRankTest                                    %                              
%                                                                           %
%    - Purpose: To determine whether a candidate vector is an EFM           %
%    - Inputs                                                               %
%         - A_new: constraint matrix                                        %
%         - r_new: candidate ray vector                                     %
%         - d: number of reactions in the network                           %                     
%    - Output                                                               %
%         - flag: logical value indicating whether r_new is an EFM          %
%    - Used in TranslationProgram                                           %                 
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function flag = isExtremeRayRankTest(A_new, r_new, d)

    % Compute the zero set of the candidate ray
    zero_set = ZeroSet(A_new, r_new);

    % Construct the zero-set matrix
    A_zeroset = A_new(zero_set, :);
  
    % Rank test for extremeness
    flag = rank(A_zeroset) == d - 1;
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                     %
% Function 4 of 13: modelSpecies                                      %
%                                                                     %
%    - Purpose: To fill out list of species based on given reactions  %
%    - Input: model: empty species list                               %
%    - Outputs                                                        %
%         - model: completed structure                                %
%         - m: number of species                                      %
%    - Used in                                                        %
%         - TranslationProgramWithDecomp                              %
%         - TranslationProgram                                        %
%         - indepDecomp                                               %
%                                                                     %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [model, m] = modelSpecies(model)

    % Initialize list of species
    model.species = { };

    % Get all species from reactants
    for i = 1:numel(model.reaction)
        for j = 1:numel(model.reaction(i).reactant)
            model.species{end+1} = model.reaction(i).reactant(j).species;
        end
    end
    
    % Get species from products
    for i = 1:numel(model.reaction)
        for j = 1:numel(model.reaction(i).product)
            model.species{end+1} = model.reaction(i).product(j).species;
        end
    end
    
    % Get only unique species
    model.species = unique(model.species);
    
    % Count the number of species
    m = numel(model.species);
    
end


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 5 of 13: stoichMatrix                                            %
%                                                                           %
%    - Purpose: To form the stoichometrix matrix N and the set of reactant  %
%          and product complexes                                            %
%    - Inputs                                                               %
%         - model: complete structure                                       %
%         - m: number of species                                            %
%    - Outputs                                                              %
%         - N: stoichiometric matrix                                        %
%         - reactant_complex: matrix of reactant complexes                  %
%         - product_complex: matrix of product complexes                    %
%         - r: total number of reactions                                    %
%    - Used in                                                              %
%         - indepDecomp                                                     %
%         - TranslationProgramWithDecomp                                    %
%         - TranslationProgram                                              %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [N, reactant_complex, product_complex, r] = stoichMatrix(model, m)

    % Initialize the matrix of reactant complexes
    reactant_complex = [ ];
    
    % Initialize the matrix of product complexes
    product_complex = [ ];
    
    % Initialize the stoichiometric matrix
    N = [ ];
    
    % For each reaction in the model
    for i = 1:numel(model.reaction)
      
        % Initialize the vector for the reaction's reactant complex
        reactant_complex(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the reactant complex
        for j = 1:numel(model.reaction(i).reactant)
            reactant_complex(find(strcmp(model.reaction(i).reactant(j).species, model.species), 1), end) = model.reaction(i).reactant(j).stoichiometry;
        end
        
        % Initialize the vector for the reaction's product complex
        product_complex(:, end+1) = zeros(m, 1);
        
        % Fill it out with the stoichiometric coefficients of the species in the product complex
        for j = 1:numel(model.reaction(i).product)
            product_complex(find(strcmp(model.reaction(i).product(j).species, model.species), 1), end) = model.reaction(i).product(j).stoichiometry;
        end
        
        % Create a vector for the stoichiometric matrix: Difference between the two previous vectors
        N(:, end+1) = product_complex(:, end) - reactant_complex(:, end);
        
        % If the reaction is reversible
        if model.reaction(i).reversible
          
            % Insert a new vector for the reactant complex: make it same as the product complex
            reactant_complex(:, end+1) = product_complex(:, end);
            
            % Insert a new vector for the product complex: make it the same as the reactant complex
            product_complex(:, end+1) = reactant_complex(:, end-1);
            
            % Insert a new vector in the stoichiometric matrix: make it the additive inverse of the vector formed earlier
            N(:, end+1) = -N(:, end);
        end
    end
    
    % Count the total number of reactions
    r = size(N, 2);

end


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                     %
% Function 6 of 13: linkageClass                                      %
%                                                                     %
%    - Purpose: To determine the number of linkage and strong linkage %
%         classes. This also builds the incidence matrix and groups   % 
%         reactions based on what linkage class they belong.          %                                          %
%    - Inputs                                                         %
%         - reactant_complex: matrix of reactant complexes            %
%         - product_complex: matrix of product complexes              %
%    - Outputs                                                        %
%         - l: number of linkage classes                              %
%         - sl: number of strong linkage classes                      %
%         - incidence: incidence matrix of the network                %
%         - linkageClasses: an array that groups reactions by linkage %
%                           class                                     %
%    - Used in                                                        %
%         - TranslationProgramWithDecomp                              %
%         - TranslationProgram                                        %
%                                                                     %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [l, sl, incidence, linkageClasses] = linkageClass(reactant_complex, product_complex)

    % Get the number of reactions
    r = size(reactant_complex, 2); 
    
    % Get just the unique complexes
    [complex, ~, index] = unique([reactant_complex, product_complex]', 'rows');
    complex = complex';
    n = size(complex, 2);

    % Initialize graph structures
    reacts_to = false(n, n);
    reacts_in = zeros(n, r); % This is the incidence matrix eventually
    
    % Fill out the entries of the matrices
    for i = 1:r
        
        % reacts_to(i, j) = true iff there is a reaction r: y_i -> y_j
        reacts_to(index(i), index(i + r)) = true;
        
        % reacts_in(i, r) = -1 and reacts_in(j, r) = 1) iff there is a reaction r: y_i -> y_j
        reacts_in(index(i), i) = -1;
        reacts_in(index(i+r), i) = 1;
    end
    
    % Count number of connected components of an undirected graph
    linkage_class = conncomp(graph(reacts_to | reacts_to'));
    
    % Count the number of linkage classes
    l = max(linkage_class);

    % Check if the network is reversible
    is_reversible = isequal(reacts_to, reacts_to');
    
    % Count number of strongly connected components of an directed graph
    if is_reversible
        strong_linkage_class = linkage_class;
    else
        % Count number of connected components of a directed graph
        strong_linkage_class = conncomp(digraph(reacts_to));
    end
    
    % Count the number of strong linkage classes
    sl = max(strong_linkage_class);

    incidence = reacts_in;

    % Group reactions by linkage class
    reaction_linkage = linkage_class(index(1:r));
    linkageClasses = cell(1, l); 
    for i = 1:r
        cls = reaction_linkage(i);
        linkageClasses{cls}(end+1) = i;
    end

end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 7 of 13: groupBySourceComplex                                    %                              
%                                                                           %
%    - Purpose: To group reactions of the reaction network according to     %
%               their source complex                                        %
%    - Input                                                                %
%         - incidence: incidence matrix                                     %                                            
%    - Output                                                               %
%         - F: cell array where each entry contains indices of reactions    %
%              sharing the same source complex                              %
%    - Used in TranslationProgram                                           %                 
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function F = groupBySourceComplex(incidence)

    [n, r] = size(incidence);
    source_indices = zeros(1, r);
    
    % Extract the index of source complex for each reaction
    for j = 1:r
        source_indices(j) = find(incidence(:, j) == -1);
    end

    % Determine unique source complexes
    [unique_sources, ~, group_ids] = unique(source_indices);

    % Group reactions by source complex
    F = cell(1, length(unique_sources));
    for i = 1:length(unique_sources)
        F{i} = find(group_ids == i);
    end
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 8 of 13: findRoot                                                %                              
%                                                                           %
%    - Purpose: To track equivalence classes of EFMs                        %
%    - Inputs                                                               %
%         - i: index of the EFM                                             %
%         - classVec: vector defining equivalence classes                   %                                      
%    - Output                                                               %
%         - root: representative of the equivalence class containing        %
%              EFM i                                                        %
%    - Used in                                                              %
%         - TranslationProgram                                              %
%         - merge                                                           %
%    - Notes                                                                %
%         - EFMs are grouped into equivalence classes based on shared       %
%              reactions and common source complexes.                       %
%         - This function determines whether two EFMs belong to the same    %
%              equivalence class, a requirement for enforcing constraints   %
%              in the binary linear program used to construct the           %
%              reaction-to-reaction graph.                                  %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function root = findRoot(i, classVec)
    while classVec(i) ~= i
        i = classVec(i);
    end
    root = i;
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 9 of 13: merge                                                   %                              
%                                                                           %
%    - Purpose: To merge the equivalence classes of two EFMs                %
%    - Inputs                                                               %
%         - i: index of the first EFM                                       %
%         - j: index of the second EFM                                      %
%         - classVec: vector defining equivalence classes                   %                                      
%    - Output                                                               %
%         - classVec: updated vector after merging the equivalence          %
%               classess of EFM i and EFM j                                 %                   
%    - Used in TranslationProgram                                           %
%    - Notes                                                                %
%         - EFMs are merged into the same class if they share reactions or  %
%               are connected via common source complexes.                  %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function classVec = merge(i, j, classVec)

    % Determine the representative elements of the classes containing EFM i and EFM j
    rootI = findRoot(i, classVec);
    rootJ = findRoot(j, classVec);

    % Merge equivalence classes of EFM i and EFM j into one equivalence class
    if rootI ~= rootJ
        classVec(rootJ) = rootI;
    end
end


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 10 of 13: TranslationComplex                                     %                              
%                                                                           %
%    - Purpose: To determine translation complexes in the network           %
%               translation procedure                                       %
%    - Inputs                                                               %
%         - edges: edge list of the reaction-to-reaction graph              %
%         - sourceComplexes: original reactant complexes                    %
%         - productComplexes: original product complexes                    %
%         - linkageClasses: list of linkage classes                         %                                      
%    - Outputs                                                              %
%         - alphaAdjusted: translation complexes applied to reactions       %
%         - translatedSource: translated reactant complexes                 %
%         - translatedProduct: translated product complexes                 %                  
%    - Used in TranslationProgram                                           %
%    - Notes                                                                %
%         - This is the third step in the overall translation procedure.    %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [alphaAdjusted, translatedSource, translatedProduct] = TranslationComplex(edges, sourceComplexes, productComplexes, linkageClasses)
    
    % Initialize matrix of translation complexes
    numReactions = size(sourceComplexes, 1);
    numSpecies = size(sourceComplexes, 2);
    alpha = NaN(numReactions, numSpecies);

    % Build sparse adjacency matrix for reaction-to-reaction graph
    edgeMap = sparse(edges(:,1), edges(:,2), 1, numReactions, numReactions);

    % Boolean array to track unprocessed reactions
    P = true(1, numReactions); 

    % Start of the graph traversal algorithm
    while any(P)
        ri = find(P, 1);      % Pick first unprocessed reaction  
        alpha(ri,:) = 0;      % Initialize it as the zero translation complex
        P(ri) = false;        % Mark as processed
        Pprime = ri;          % Prepare for breadth-first search (BFS)

        % BFS proceudre
        while ~isempty(Pprime)
            Pprime2 = [];
            for ri = Pprime
                neighbors = find(edgeMap(ri,:));
                for rj = neighbors
                    if P(rj) % If reaction is unprocessed 
                        % Compute translation complex
                        alpha(rj,:) = productComplexes(ri,:) - sourceComplexes(rj,:) + alpha(ri,:);
                        Pprime2(end+1) = rj;
                        P(rj) = false; % Mark as processed
                    end
                end
            end
            Pprime = Pprime2;
        end
    end

    % Apply translation complexes to network
    translatedSource = sourceComplexes + alpha;
    translatedProduct = productComplexes + alpha;

    % Ensure nonnegativity within each linkage class 
    updatedlinkageClasses = computeLinkageClassesByReactions(translatedSource,translatedProduct);

    for k = 1:length(updatedlinkageClasses)
        classReactions = updatedlinkageClasses{k};
        allComplexes = [translatedSource; translatedProduct];

        % Compute the minimum values for each species across all complexes
        minVals = min(allComplexes, [], 1);

        % Shift to ensure nonnegativity
        shift = max(0, -minVals); 
        alpha(classReactions,:) = alpha(classReactions,:) + shift;
    end

    % Apply the shift across all reactions in the translated network
    alphaAdjusted = alpha;
    translatedSource = sourceComplexes + alphaAdjusted;
    translatedProduct = productComplexes + alphaAdjusted;
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 11 of 13: computeLinkageClassesByReactions                       %                              
%                                                                           %
%    - Purpose: To group reactions of the reaction network into its         %
%               linkage classes                                             %
%    - Inputs                                                               %
%         - sourceComplexes: original reactant complexes                    %
%         - productComplexes: original product complexes                    %                                     
%    - Output                                                               %
%         - reactionClasses: cell array where each cell contains indices of %
%               reactions belonging to the same linkage class               %                   
%    - Used in TranslationComplex                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function reactionClasses = computeLinkageClassesByReactions(sourceComplexes, productComplexes)

    % Stack reactant and product complexes into a single matrix
    allComplexes = [sourceComplexes; productComplexes];

    % Find unique complexes and assign an ID
    [uniqueComplexes, ~, complexIDs] = unique(allComplexes, 'rows', 'stable');

    % Number of reactions in the network
    numReactions = size(sourceComplexes, 1);

    % Map reactant and product complexes to unique IDs
    srcIDs = complexIDs(1:numReactions); % IDs of the source complexes
    tgtIDs = complexIDs(numReactions+1:end); % IDs of the product complexes

    % Create directed graph
    G = digraph(srcIDs, tgtIDs, [], size(uniqueComplexes, 1));

    % Convert to undirected graph for the determination of the linkage classes
    UG = graph(G.adjacency | G.adjacency');

    % Determine linkage classes
    complexToClass = conncomp(UG);

    % Assign each reaction to its linkage class
    reactionClassLabels = complexToClass(srcIDs);

    % Group reaction indices according to their corresponding linkage classes
    numClasses = max(reactionClassLabels);
    reactionClasses = cell(numClasses, 1);

    for i = 1:numClasses
        reactionClasses{i} = find(reactionClassLabels == i);
    end
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
% Function 12 of 13: complexToString                                        %                              
%                                                                           %
%    - Purpose: To convert a numeric complex vector into a human-readable   %
%               string using species names.                                 %
%    - Inputs                                                               %
%         - vec: vector representing a complex                              %
%         - speciesNames: cell array containing names of species            %                                     
%    - Output                                                               %
%         - str: string representation of the complex                       %                   
%    - Used in TranslationProgram                                           %
%    - Notes                                                                %
%         - If the complex is empty, output is '0'.                         %
%         - Species of coefficients 1 are not explicitly printed.           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function str = complexToString(vec, speciesNames)

    % Initialize cell array to hold terms of the complex
    terms = {};

    % Loop over species in the complexes
    for i = 1:length(vec)
        if vec(i) == 1
            % Coefficient of the species in a complex is 1: only include species name
            terms{end+1} = speciesNames{i}; 
        elseif vec(i) > 1
            % Coefficient of the species in a complex is greater than 1: include coefficient and species name
            terms{end+1} = sprintf('%d%s', vec(i), speciesNames{i});
        end
    end

    % Combine terms as a single string
    if isempty(terms)
        str = '0';
    else
        str = strjoin(terms, ' + ');
    end
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
% Function 13 of 13: indepDecomp                                          %
%                                                                         %
%    - Purpose: To decompose a network into its finest independent        %
%         decomposition                                                   %
%    - Input: model: empty species list                                   %
%    - Outputs                                                            %
%         - model: completed structure                                    %
%         - R: matrix of reaction vectors of the network                  %
%         - G: undirected graph of R                                      %
%         - P: partitions representing the decomposition of the reactions %
%    - Used in TranslationProgramWithDecomp                               %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function [model, N, R, G, P] = indepDecomp(model)

    % Create a list of all species indicated in the reactions
    [model, m] = modelSpecies(model);
    
    % Form stoichiometric matrix N
    [N, ~, ~, r] = stoichMatrix(model, m);

    % Get the transpose of N: Each row now represents the reaction vector a reaction    
    R = N';
    
    % Write R in reduced row echelon form: the transpose of R is used so 'basis_reaction_num' will give the pivot rows of R
    %    - 'basis_reaction_num' gives the row numbers of R which form a basis for the rowspace of R
    [~, basis_reaction_num] = rref(R');
    
    % Form a basis for the rowspace of R
    basis = R(basis_reaction_num, :);
    
    % Initialize an undirected graph G
    G = graph();
    
    % Construct the vertex set of undirected graph G
    % Add vertices to G: these are the reaction vectors that form a basis for the rowspace of R
    for i = 1:numel(basis_reaction_num)
        
        % Use the reaction number as label for each vertex
        G = addnode(G, strcat('R', num2str(basis_reaction_num(i))));
    end
    
    % Initialize matrix of linear combinations
    linear_combo = zeros(r, numel(basis_reaction_num));
    
    % Write the nonbasis reaction vectors as a linear combination of the basis vectors
    % Do this for the nonbasis reactions vectors
    for i = 1:r
        if ~ismember(i, basis_reaction_num)
          
          % This gives the coefficients of the linear combinations
          % The basis vectors will have a row of zeros
          linear_combo(i, :) = basis'\R(i, :)';
        end
    end
    
    % Round off values to nearest whole number to avoid round off errors
    linear_combo = round(linear_combo);
        
    % Get the reactions that are linear combinations of at least 2 basis reactions
    % These are the reactions where we'll get the edges
    get_edges = find(sum(abs(linear_combo), 2) > 1);
        
    % Initialize an array for sets of vertices that will form the edges
    vertex_set = { };
     
    % Identify which vertices form edges in each reaction: get those with non-zero coefficients in the linear combinations
    for i = 1:numel(get_edges)
        vertex_set{i} = find(linear_combo(get_edges(i), :) ~= 0);
    end
    
    % Initialize the edge set
    edges = [ ];
    
    % Get all possible combinations (not permutations) of the reactions involved in the linear combinations
    for i = 1:numel(vertex_set)
        edges = [edges; nchoosek(vertex_set{i}, 2)];
    end
    
    % Get just the unique edges
    edges = unique(edges, 'rows');
    
    % Add these edges to graph G
    for i = 1:size(edges, 1)
        G = addedge(G, strcat('R', num2str(basis_reaction_num(edges(i, 1)))), strcat('R', num2str(basis_reaction_num(edges(i, 2)))));
    end
        
    % Determine to which component each vertex belongs to
    component_numbers = conncomp(G);
    
    % Determine the number of connected components of G: this is the number of partitions R will be decomposed to
    num_components = max(component_numbers);
    
    % For the case of only one connected component
    if num_components == 1
        P = [ ];
    end
    
    % Initialize the list of partitions
    P = cell(1, num_components);
    
    % Basis vectors: assign them first into their respective partition based on their component number
    for i = 1:numel(component_numbers)
        P{component_numbers(i)}(end+1) = basis_reaction_num(i);
    end
    
    % Nonbasis vectors: they go to the same partition as the basis vectors that form their linear combination
    for i = 1:numel(P)
        for j = 1:numel(P{i})
            
            % Get the column number representing the basis vectors in 'linear_combo'
            col = find(basis_reaction_num == P{i}(j));
            
            % Check which reactions used a particular basis vector and assign them to their respective partition
            P{i} = [P{i} find(linear_combo(:, col) ~= 0)'];
        end
    end
    
    % Get only unique elements in each partition
    for i = 1:numel(P)
        P{i} = unique(P{i});
    end

    % If some reactions are missing, then redo starting from the linear combination part
    if length(cell2mat(P)) ~= size(R, 1)

        % Do not round off the coefficients of the linear combinations
        linear_combination = linear_combo;

        get_edges = find(sum(abs(linear_combination), 2) > 1);
        vertex_set = { };
        for i = 1:numel(get_edges)
            vertex_set{i} = find(linear_combination(get_edges(i), :) ~= 0);
        end
        edges = [ ];
        for i = 1:numel(vertex_set)
            edges = [edges; nchoosek(vertex_set{i}, 2)];
        end
        edges = unique(edges, 'rows');
        for i = 1:size(edges, 1)
            G = addedge(G, strcat('R', num2str(basis_reaction_num(edges(i, 1)))), strcat('R', num2str(basis_reaction_num(edges(i, 2)))));
        end
        
        component_numbers = conncomp(G);
        num_components = max(component_numbers);
        if num_components == 1
            P = [ ];
        end
        
        P = cell(1, num_components);
        for i = 1:numel(component_numbers)
            P{component_numbers(i)}(end+1) = basis_reaction_num(i);
        end
        for i = 1:numel(P)
            for j = 1:numel(P{i})
                col = find(basis_reaction_num == P{i}(j));
                P{i} = [P{i} find(linear_combination(:, col) ~= 0)'];
            end
        end
        for i = 1:numel(P)
            P{i} = unique(P{i});
        end
    end

end