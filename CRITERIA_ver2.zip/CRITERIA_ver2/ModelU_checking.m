% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16 k17 k18 k19 k20 k21 k22
syms Cas Cassg1 Cassg2 Casssg1 Casssg2 G1 G1P2 G1P2U1 G1P2U2 G2 G2P1 G2P1U1 G2P1U2 sg1 sg2
syms tau4

% ODEs
ODECas = k18 - Cas*k17 + Casssg1*k3 + Casssg2*k14 - Cas*k2*sg1 - Cas*k13*sg2;
ODECassg1 = G1P2U1*k11 + G2P1U1*k9 - Cassg1*G1P2*k10 - Cassg1*G2P1*k8;
ODECassg2 = G1P2U2*k20 + G2P1U2*k22 - Cassg2*G1P2*k19 - Cassg2*G2P1*k21;
ODECasssg1 = G2P1*k5 - Casssg1*k3 - Casssg1*G2*k4 + Cas*k2*sg1;
ODECasssg2 = G1P2*k7 - Casssg2*k14 - Casssg2*G1*k6 + Cas*k13*sg2;
ODEG1 = G1P2*k7 - Casssg2*G1*k6;
ODEG1P2 = G1P2U1*k11 - G1P2*k7 + G1P2U2*k20 + Casssg2*G1*k6 - Cassg1*G1P2*k10 - Cassg2*G1P2*k19;
ODEG1P2U1 = Cassg1*G1P2*k10 - G1P2U1*k11;
ODEG1P2U2 = Cassg2*G1P2*k19 - G1P2U2*k20;
ODEG2 = G2P1*k5 - Casssg1*G2*k4;
ODEG2P1 = G2P1U1*k9 - G2P1*k5 + G2P1U2*k22 + Casssg1*G2*k4 - Cassg1*G2P1*k8 - Cassg2*G2P1*k21;
ODEG2P1U1 = Cassg1*G2P1*k8 - G2P1U1*k9;
ODEG2P1U2 = Cassg2*G2P1*k21 - G2P1U2*k22;
ODEsg1 = Casssg1*k3 + G1*k1 - k15*sg1 - Cas*k2*sg1;
ODEsg2 = Casssg2*k14 + G2*k12 - k16*sg2 - Cas*k13*sg2;

% Solution
Cas = k18/k17;
Cassg1 = (G1P2U1*k11)/(G1*k10*tau4);
Cassg2 = (G1P2U2*k20)/(G1*k19*tau4);
Casssg1 = (G1*k1*k2*k18)/(k3*k15*k17);
Casssg2 = (k7*tau4)/k6;
G2 = (k7*k14*k16*k17*tau4)/(k6*k12*k13*k18);
G1P2 = G1*tau4;
G2P1 = (G1*k1*k2*k4*k7*k14*k16*tau4)/(k3*k5*k6*k12*k13*k15);
G2P1U1 = (G1P2U1*k1*k2*k4*k7*k8*k11*k14*k16)/(k3*k5*k6*k9*k10*k12*k13*k15);
G2P1U2 = (G1P2U2*k1*k2*k4*k7*k14*k16*k20*k21)/(k3*k5*k6*k12*k13*k15*k19*k22);
sg1 = (G1*k1)/k15;
sg2 = (k7*k14*k17*tau4)/(k6*k13*k18);

% Check
checkCas  = simplify(subs(ODECas))
checkCassg1  = simplify(subs(ODECassg1))
checkCassg2  = simplify(subs(ODECassg2))
checkCasssg1  = simplify(subs(ODECasssg1))
checkCasssg2  = simplify(subs(ODECasssg2))
checkG1  = simplify(subs(ODEG1))
checkG1P2  = simplify(subs(ODEG1P2))
checkG1P2U1  = simplify(subs(ODEG1P2U1))
checkG1P2U2  = simplify(subs(ODEG1P2U2))
checkG2  = simplify(subs(ODEG2))
checkG2P1  = simplify(subs(ODEG2P1))
checkG2P1U1  = simplify(subs(ODEG2P1U1))
checkG2P1U2  = simplify(subs(ODEG2P1U2))
checksg1  = simplify(subs(ODEsg1))
checksg2  = simplify(subs(ODEsg2))


