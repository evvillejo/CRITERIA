% Clear all variables
clear all
clc;
clear;

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16 k17 k18 k19 k20 k21 k22 k23 k24 k25 k26 k27 k28 k29 k30 k31
syms X1 X2 X3 X4 X5 X6 X7 X8 X9 X10 X11 X12 X13 X14 X15 X16 X17 X18 X19
syms sigma1 sigma2 sigma3 sigma4 tau1 tau2

% ODEs
odeX1 = k2*X2 - k1*X1;
odeX2 = k1*X1 - k2*X2 - k3*X2 + k4*X3 + k16*X14 + k17*X14 - k15*X2*X4;
odeX3 = k3*X2 - k4*X3 + k10*X15 + k11*X15 - k9*X3*X6;
odeX4 = k16*X14 + k20*X16 + k22*X18 + k23*X18 - k15*X2*X4 - k21*X4*X10;
odeX5 = k6*X7 - k5*X5 + k17*X14 + k19*X16 - k18*X5*X8;
odeX6 = k10*X15 + k14*X17 + k25*X19 + k26*X19 - k9*X3*X6 - k24*X6*X11;
odeX7 = k5*X5 - k6*X7 + k11*X15 + k13*X17 - k12*X7*X9;
odeX8 = k19*X16 + k20*X16 - k18*X5*X8;
odeX9 = k13*X17 + k14*X17 - k12*X7*X9;
odeX10 = k30 - k27*X10 + k28*X11 + k22*X18 - k31*X10 - k21*X4*X10;
odeX11 = k8*X13 + k27*X10 - k28*X11 - k29*X11 + k25*X19 - k7*X11*X12 - k24*X6*X11;
odeX12 = k8*X13 - k7*X11*X12;
odeX13 = k7*X11*X12 - k8*X13;
odeX14 = k15*X2*X4 - k17*X14 - k16*X14;
odeX15 = k9*X3*X6 - k11*X15 - k10*X15;
odeX16 = k18*X5*X8 - k20*X16 - k19*X16;
odeX17 = k12*X7*X9 - k14*X17 - k13*X17;
odeX18 = k21*X4*X10 - k23*X18 - k22*X18;
odeX19 = k24*X6*X11 - k26*X19 - k25*X19;

% Solution
X1 = (X9*k2*k4*k14*sigma1*sigma2*tau2*(k10 + k11))/(k1*k3*k9*k11*(k28 + k29));
X2 = (X9*k4*k14*sigma1*sigma2*tau2*(k10 + k11))/(k3*k9*k11*(k28 + k29));
X3 = (X9*k14*sigma1*sigma2*tau2*(k10 + k11))/(k9*k11*(k28 + k29));
X4 = (k27 + k31)/(sigma3*sigma4);
X5 = (k6*tau2*(k13 + k14))/(k5*k12);
X6 = (k28 + k29)/(sigma1*sigma2);
X7 = (tau2*(k13 + k14))/k12;
X8 = (X9*k4*k5*k12*k14*k15*k17*sigma1*sigma2*(k10 + k11)*(k19 + k20)*(k27 + k31))/(k3*k6*k9*k11*k18*k20*sigma3*sigma4*(k13 + k14)*(k16 + k17)*(k28 + k29));
X10 = (k30*sigma3*sigma4*(k22 + k23)*(k28 + k29)*(k24*k26 + k25*sigma1*sigma2 + k26*sigma1*sigma2))/(k21*k23*k24*k26*k27*k28 + k21*k23*k24*k26*k27*k29 + k21*k23*k24*k26*k28*k31 + k21*k23*k24*k26*k29*k31 + k21*k23*k25*k27*k28*sigma1*sigma2 + k21*k23*k25*k27*k29*sigma1*sigma2 + k21*k23*k26*k27*k28*sigma1*sigma2 + k21*k23*k26*k27*k29*sigma1*sigma2 + k21*k23*k25*k28*k31*sigma1*sigma2 + k21*k23*k25*k29*k31*sigma1*sigma2 + k21*k23*k26*k28*k31*sigma1*sigma2 + k21*k23*k26*k29*k31*sigma1*sigma2 + k22*k24*k26*k27*k28*sigma3*sigma4 + k22*k24*k26*k27*k29*sigma3*sigma4 + k23*k24*k26*k27*k28*sigma3*sigma4 + k23*k24*k26*k27*k29*sigma3*sigma4 + k22*k24*k26*k28*k31*sigma3*sigma4 + k22*k24*k26*k29*k31*sigma3*sigma4 + k23*k24*k26*k28*k31*sigma3*sigma4 + k23*k24*k26*k29*k31*sigma3*sigma4 + k22*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k29*k31*sigma1*sigma2*sigma3*sigma4);
X11 = (k27*k30*sigma1*sigma2*sigma3*sigma4*(k22 + k23)*(k25 + k26))/(k21*k23*k24*k26*k27*k28 + k21*k23*k24*k26*k27*k29 + k21*k23*k24*k26*k28*k31 + k21*k23*k24*k26*k29*k31 + k21*k23*k25*k27*k28*sigma1*sigma2 + k21*k23*k25*k27*k29*sigma1*sigma2 + k21*k23*k26*k27*k28*sigma1*sigma2 + k21*k23*k26*k27*k29*sigma1*sigma2 + k21*k23*k25*k28*k31*sigma1*sigma2 + k21*k23*k25*k29*k31*sigma1*sigma2 + k21*k23*k26*k28*k31*sigma1*sigma2 + k21*k23*k26*k29*k31*sigma1*sigma2 + k22*k24*k26*k27*k28*sigma3*sigma4 + k22*k24*k26*k27*k29*sigma3*sigma4 + k23*k24*k26*k27*k28*sigma3*sigma4 + k23*k24*k26*k27*k29*sigma3*sigma4 + k22*k24*k26*k28*k31*sigma3*sigma4 + k22*k24*k26*k29*k31*sigma3*sigma4 + k23*k24*k26*k28*k31*sigma3*sigma4 + k23*k24*k26*k29*k31*sigma3*sigma4 + k22*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k29*k31*sigma1*sigma2*sigma3*sigma4);
X12 = (X13*k8*(k21*k23*k24*k26*k27*k28 + k21*k23*k24*k26*k27*k29 + k21*k23*k24*k26*k28*k31 + k21*k23*k24*k26*k29*k31 + k21*k23*k25*k27*k28*sigma1*sigma2 + k21*k23*k25*k27*k29*sigma1*sigma2 + k21*k23*k26*k27*k28*sigma1*sigma2 + k21*k23*k26*k27*k29*sigma1*sigma2 + k21*k23*k25*k28*k31*sigma1*sigma2 + k21*k23*k25*k29*k31*sigma1*sigma2 + k21*k23*k26*k28*k31*sigma1*sigma2 + k21*k23*k26*k29*k31*sigma1*sigma2 + k22*k24*k26*k27*k28*sigma3*sigma4 + k22*k24*k26*k27*k29*sigma3*sigma4 + k23*k24*k26*k27*k28*sigma3*sigma4 + k23*k24*k26*k27*k29*sigma3*sigma4 + k22*k24*k26*k28*k31*sigma3*sigma4 + k22*k24*k26*k29*k31*sigma3*sigma4 + k23*k24*k26*k28*k31*sigma3*sigma4 + k23*k24*k26*k29*k31*sigma3*sigma4 + k22*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k29*k31*sigma1*sigma2*sigma3*sigma4))/(k7*k27*k30*sigma1*sigma2*sigma3*sigma4*(k22 + k23)*(k25 + k26));
X14 = (X9*k4*k14*k15*sigma1*sigma2*tau2*(k10 + k11)*(k27 + k31))/(k3*k9*k11*sigma3*sigma4*(k16 + k17)*(k28 + k29));
X15 = (X9*k14*tau2)/k11;
X16 = (X9*k4*k14*k15*k17*sigma1*sigma2*tau2*(k10 + k11)*(k27 + k31))/(k3*k9*k11*k20*sigma3*sigma4*(k16 + k17)*(k28 + k29));
X17 = X9*tau2;
X18 = (k21*k30*(k28 + k29)*(k27 + k31)*(k24*k26 + k25*sigma1*sigma2 + k26*sigma1*sigma2))/(k21*k23*k24*k26*k27*k28 + k21*k23*k24*k26*k27*k29 + k21*k23*k24*k26*k28*k31 + k21*k23*k24*k26*k29*k31 + k21*k23*k25*k27*k28*sigma1*sigma2 + k21*k23*k25*k27*k29*sigma1*sigma2 + k21*k23*k26*k27*k28*sigma1*sigma2 + k21*k23*k26*k27*k29*sigma1*sigma2 + k21*k23*k25*k28*k31*sigma1*sigma2 + k21*k23*k25*k29*k31*sigma1*sigma2 + k21*k23*k26*k28*k31*sigma1*sigma2 + k21*k23*k26*k29*k31*sigma1*sigma2 + k22*k24*k26*k27*k28*sigma3*sigma4 + k22*k24*k26*k27*k29*sigma3*sigma4 + k23*k24*k26*k27*k28*sigma3*sigma4 + k23*k24*k26*k27*k29*sigma3*sigma4 + k22*k24*k26*k28*k31*sigma3*sigma4 + k22*k24*k26*k29*k31*sigma3*sigma4 + k23*k24*k26*k28*k31*sigma3*sigma4 + k23*k24*k26*k29*k31*sigma3*sigma4 + k22*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k29*k31*sigma1*sigma2*sigma3*sigma4);
X19 = (k24*k27*k30*sigma3*sigma4*(k22 + k23)*(k28 + k29))/(k21*k23*k24*k26*k27*k28 + k21*k23*k24*k26*k27*k29 + k21*k23*k24*k26*k28*k31 + k21*k23*k24*k26*k29*k31 + k21*k23*k25*k27*k28*sigma1*sigma2 + k21*k23*k25*k27*k29*sigma1*sigma2 + k21*k23*k26*k27*k28*sigma1*sigma2 + k21*k23*k26*k27*k29*sigma1*sigma2 + k21*k23*k25*k28*k31*sigma1*sigma2 + k21*k23*k25*k29*k31*sigma1*sigma2 + k21*k23*k26*k28*k31*sigma1*sigma2 + k21*k23*k26*k29*k31*sigma1*sigma2 + k22*k24*k26*k27*k28*sigma3*sigma4 + k22*k24*k26*k27*k29*sigma3*sigma4 + k23*k24*k26*k27*k28*sigma3*sigma4 + k23*k24*k26*k27*k29*sigma3*sigma4 + k22*k24*k26*k28*k31*sigma3*sigma4 + k22*k24*k26*k29*k31*sigma3*sigma4 + k23*k24*k26*k28*k31*sigma3*sigma4 + k23*k24*k26*k29*k31*sigma3*sigma4 + k22*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k25*k27*k29*sigma1*sigma2*sigma3*sigma4 + k23*k26*k27*k29*sigma1*sigma2*sigma3*sigma4 + k22*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k28*k31*sigma1*sigma2*sigma3*sigma4 + k22*k26*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k25*k29*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k28*k31*sigma1*sigma2*sigma3*sigma4 + k23*k26*k29*k31*sigma1*sigma2*sigma3*sigma4);

% Check
checkX1  = simplify(subs(odeX1))
checkX2  = simplify(subs(odeX2))
checkX3  = simplify(subs(odeX3))
checkX4  = simplify(subs(odeX4))
checkX5  = simplify(subs(odeX5))
checkX6  = simplify(subs(odeX6))
checkX7  = simplify(subs(odeX7))
checkX8  = simplify(subs(odeX8))
checkX9  = simplify(subs(odeX9))
checkX10  = simplify(subs(odeX10))
checkX11  = simplify(subs(odeX11))
checkX12  = simplify(subs(odeX12))
checkX13  = simplify(subs(odeX13))
checkX14  = simplify(subs(odeX14))
checkX15  = simplify(subs(odeX15))
checkX16  = simplify(subs(odeX16))
checkX17  = simplify(subs(odeX17))
checkX18  = simplify(subs(odeX18))
checkX19  = simplify(subs(odeX19))