% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14
syms X XD XDYp XT XTYp Xp XpY Y Yp
syms sigma1

% ODEs
odeX  = k1*XD - k3*X - k2*X + k8*XpY + k4*XT;
odeXD  = k2*X - k1*XD + k10*XDYp + k11*XDYp - k9*XD*Yp;
odeXDYp  = k9*XD*Yp - k11*XDYp - k10*XDYp;
odeXT  = k3*X - k4*XT - k5*XT + k13*XTYp + k14*XTYp - k12*XT*Yp;
odeXTYp  = k12*XT*Yp - k14*XTYp - k13*XTYp;
odeXp  = k7*XpY + k5*XT - k6*Xp*Y;
odeXpY  = k6*Xp*Y - k8*XpY - k7*XpY;
odeY  = k11*XDYp + k7*XpY + k14*XTYp - k6*Xp*Y;
odeYp  = k10*XDYp + k8*XpY + k13*XTYp - k9*XD*Yp - k12*XT*Yp;

% sigma1 = k1*k3*k12/(k2*(k4+k5));

% % Solution
% X = (XpY*k8*(k4 + k5))/(k3*k5);
% XD = (XpY*k2*k8*(k4 + k5))/(k1*k3*k5);
% XDYp = (XpY*k8*k9*(k13 + k14))/(k9*k11*k13 + k9*k11*k14 + k10*k14*sigma1 + k11*k14*sigma1);
% XT = (XpY*k8)/k5;
% XTYp = (XpY*k8*sigma1*(k10 + k11))/(k9*k11*k13 + k9*k11*k14 + k10*k14*sigma1 + k11*k14*sigma1);
% Xp = (XpY*(k7 + k8))/(Y*k6);
% Yp = (k5*sigma1*(k10 + k11)*(k13 + k14))/(k12*(k9*k11*k13 + k9*k11*k14 + k10*k14*sigma1 + k11*k14*sigma1));

X = (XpY*k8*(k4 + k5))/(k3*k5);
XD = (XpY*k2*k8*(k4 + k5))/(k1*k3*k5);
XDYp = (XpY*k8*k9*(k13 + k14))/(k9*k11*k13 + k9*k11*k14 + k10*k14*sigma1 + k11*k14*sigma1);
XT = (XpY*k8)/k5;
XTYp = (XpY*k8*sigma1*(k10 + k11))/(k9*k11*k13 + k9*k11*k14 + k10*k14*sigma1 + k11*k14*sigma1);
Xp = (XpY*(k7 + k8))/(Y*k6);
Yp = (k5*sigma1*(k10 + k11)*(k13 + k14))/(k12*(k9*k11*k13 + k9*k11*k14 + k10*k14*sigma1 + k11*k14*sigma1));

% Check
checkX  = simplify(subs(odeX))
checkXD  = simplify(subs(odeXD))
checkXDYp  = simplify(subs(odeXDYp))
checkXT  = simplify(subs(odeXT))
checkXTYp  = simplify(subs(odeXTYp))
checkXp  = simplify(subs(odeXp))
checkXpY  = simplify(subs(odeXpY))
checkY  = simplify(subs(odeY))
checkYp  = simplify(subs(odeYp))

