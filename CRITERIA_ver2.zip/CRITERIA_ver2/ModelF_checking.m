% Clear all variables
clear all
clc;
clear;

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9
syms S1 Y1 S2 Y2 S3 Y3 S4 S5

% ODEs
ODES1 = k6*Y2 - k1*S1;
ODEY1 = k5*Y2 - k4*Y1 - k3*Y1 + k2*S2*S3;
ODES2 = k1*S1 + k3*Y1 - k2*S2*S3;
ODEY2 = k4*Y1 - k5*Y2 - k6*Y2;
ODES3 = k3*Y1 + k9*Y3 - k2*S2*S3;
ODEY3 = k7*S4*S5 - k9*Y3 - k8*Y3;
ODES4 = k6*Y2 + k8*Y3 - k7*S4*S5;
ODES5 = k8*Y3 + k9*Y3 - k7*S4*S5;

% Solution
S1 = (Y3*k9)/k1;
S2 = (Y3*k9*(k3*k5 + k3*k6 + k4*k6))/(S3*k2*k4*k6);
S4 = (Y3*(k8 + k9))/(S5*k7);
Y1 = (Y3*k9*(k5 + k6))/(k4*k6);
Y2 = (Y3*k9)/k6;

% Check
checkS1  = simplify(subs(ODES1))
checkY1  = simplify(subs(ODEY1))
checkS2  = simplify(subs(ODES2))
checkY2  = simplify(subs(ODEY2))
checkS3  = simplify(subs(ODES3))
checkY3  = simplify(subs(ODEY3))
checkS4  = simplify(subs(ODES4))
checkS5  = simplify(subs(ODES5))