% Clear all variables
clc
clear all

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16
syms S1 S2 S3 S4 S5 S6 S7 S8 S9
syms sigma2

% ODEs
ODES1 = k9*S4*S6 - k8*S1 - k7*S1 + k6*S5*S9;
ODES2 = k10*S6*S7 - k12*S2 - k11*S2;
ODES3 = k13*S6*S8 - k15*S3 - k14*S3;
ODES4 = k1*S8 - k3*S4 - k2*S4 + k8*S1 + k4*S7 - k9*S4*S6;
ODES5 = k7*S1 + k12*S2 + k15*S3 + k16*S6 - k6*S5*S9;
ODES6 = k8*S1 + k11*S2 + k14*S3 - k16*S6 - k9*S4*S6 - k10*S6*S7 - k13*S6*S8;
ODES7 = k3*S4 - k4*S7 - k5*S7 + k11*S2 + k12*S2 - k10*S6*S7;
ODES8 = k2*S4 - k1*S8 + k14*S3 + k15*S3 - k13*S6*S8;
ODES9 = k7*S1 + k5*S7 - k6*S5*S9;

% Free Parameter
sigma1 = (k2*k13*(k4 + k5))/(k1*k3);
sigma3 = (k1*k3*k5*k9*sigma1*(k11 + k12)*(k14 + k15))/(k2*k13*(k4 + k5)*(k10*k12*k14 + k10*k12*k15 + k11*k14*sigma2 + k11*k15*sigma1 + k11*k15*sigma2 + k12*k14*sigma2 + k12*k15*sigma1 + k12*k15*sigma2));

% Solution
S1 = (k1*k16*sigma1*(k3*k5 + k4*sigma3 + k5*sigma3))/(k2*k8*k13*sigma2*(k4 + k5));
S2 = (k1*k3*k5*k10*k16*sigma1*(k14 + k15))/(k2*k13*sigma2*(k4 + k5)*(k10*k12*k14 + k10*k12*k15 + k11*k14*sigma2 + k11*k15*sigma1 + k11*k15*sigma2 + k12*k14*sigma2 + k12*k15*sigma1 + k12*k15*sigma2));
S3 = (k1*k3*k5*k16*sigma1^2*(k11 + k12))/(k2*k13*sigma2*(k4 + k5)*(k10*k12*k14 + k10*k12*k15 + k11*k14*sigma2 + k11*k15*sigma1 + k11*k15*sigma2 + k12*k14*sigma2 + k12*k15*sigma1 + k12*k15*sigma2));
S4 = (k1*k16*sigma1)/(k2*k13*sigma2);
S5 = (k1*k16*sigma1*(k3*k5*k7 + k3*k5*k8 + k4*k7*sigma3 + k5*k7*sigma3))/(S9*k2*k6*k8*k13*sigma2*(k4 + k5));
S6 = (k1*k3*k5*sigma1*(k11 + k12)*(k14 + k15))/(k2*k13*(k4 + k5)*(k10*k12*k14 + k10*k12*k15 + k11*k14*sigma2 + k11*k15*sigma1 + k11*k15*sigma2 + k12*k14*sigma2 + k12*k15*sigma1 + k12*k15*sigma2));
S7 = (k1*k3*k16*sigma1)/(k2*k13*sigma2*(k4 + k5));
S8 = (k16*sigma1)/(k13*sigma2);

% Check
checkS1  = simplify(subs(ODES1))
checkS2  = simplify(subs(ODES2))
checkS3  = simplify(subs(ODES3))
checkS4  = simplify(subs(ODES4))
checkS5  = simplify(subs(ODES5))
checkS6  = simplify(subs(ODES6))
checkS7  = simplify(subs(ODES7))
checkS8  = simplify(subs(ODES8))
checkS9  = simplify(subs(ODES9))