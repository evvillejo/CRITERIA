% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16 k17 k18
syms E F S00 S00E S01 S01E S01F S10 S10E S10F S11 S11F
syms sigma1

% ODEs
ODEE = k2*S00E + k4*S01E + k6*S01E + k7*S10E + k8*S10E - E*k1*S00 - E*k5*S01 - E*k9*S10;
ODEF = k16*S01F + k17*S01F + k11*S11F + k13*S10F + k15*S10F - F*k18*S01 - F*k10*S11 - F*k14*S10;
ODES00 = k2*S00E + k16*S01F + k15*S10F - E*k1*S00;
ODES00E = E*k1*S00 - k3*S00E - k2*S00E;
ODES01 = k4*S01E + k17*S01F - E*k5*S01 - F*k18*S01;
ODES01E = k3*S00E - k4*S01E - k6*S01E + E*k5*S01;
ODES01F = F*k18*S01 - k17*S01F - k16*S01F;
ODES10 = k8*S10E + k13*S10F - E*k9*S10 - F*k14*S10;
ODES10E = E*k9*S10 - k8*S10E - k7*S10E;
ODES10F = k12*S11F - k13*S10F - k15*S10F + F*k14*S10;
ODES11 = k6*S01E + k7*S10E + k11*S11F - F*k10*S11;
ODES11F = F*k10*S11 - k12*S11F - k11*S11F;

sigma2 = (k18*sigma1)/(k14);

% Solution
E = (S10E*(k7 + k8))/(S10*k9);
F = (S10E*sigma1*(k7 + k8))/(S10*k9*k14);
S00 = (S10*k15*(k2 + k3)*(k7*k9 + k7*sigma1 + k8*sigma1)*(k5*k6*k16 + k5*k6*k17 + k4*k16*sigma2 + k6*k16*sigma2))/(k1*k3*k6*k13*(k7 + k8)*(k5*k16 + k5*k17 + k16*sigma2));
S01 = (S10*k4*k14*k15*sigma2*(k16 + k17)*(k7*k9 + k7*sigma1 + k8*sigma1))/(k6*k13*k18*sigma1*(k7 + k8)*(k5*k16 + k5*k17 + k16*sigma2));
S11 = (S10*k14*(k11 + k12)*(k7*k9*k13 + k7*k9*k15 + k7*k15*sigma1 + k8*k15*sigma1))/(k10*k12*k13*sigma1*(k7 + k8));
S00E = (S10E*k15*(k7*k9 + k7*sigma1 + k8*sigma1)*(k5*k6*k16 + k5*k6*k17 + k4*k16*sigma2 + k6*k16*sigma2))/(k3*k6*k9*k13*(k5*k16 + k5*k17 + k16*sigma2));
S01E = (S10E*k15*(k7*k9 + k7*sigma1 + k8*sigma1))/(k6*k9*k13);
S01F = (S10E*k4*k15*sigma2*(k7*k9 + k7*sigma1 + k8*sigma1))/(k6*k9*k13*(k5*k16 + k5*k17 + k16*sigma2));
S10F = (S10E*(k7*k9 + k7*sigma1 + k8*sigma1))/(k9*k13);
S11F = (S10E*(k7*k9*k13 + k7*k9*k15 + k7*k15*sigma1 + k8*k15*sigma1))/(k9*k12*k13);

% Check
checkE  = simplify(subs(ODEE))
checkF  = simplify(subs(ODEF))
checkS00  = simplify(subs(ODES00))
checkS00E  = simplify(subs(ODES00E))
checkS01  = simplify(subs(ODES01))
checkS01E  = simplify(subs(ODES01E))
checkS01F  = simplify(subs(ODES01F))
checkS10  = simplify(subs(ODES10))
checkS10E  = simplify(subs(ODES10E))
checkS10F  = simplify(subs(ODES10F))
checkS11  = simplify(subs(ODES11))
checkS11F  = simplify(subs(ODES11F))

