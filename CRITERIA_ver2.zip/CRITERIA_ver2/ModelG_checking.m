% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10
syms C1 C2 D G1 G2 P1 P2
syms sigma1 sigma2 sigma3 sigma4 sigma5 sigma6

% ODEs
odeC1  = G2*k7*P1 - C1*k8;
odeC2  = D*G1*k9 - C2*k10;
odeD   = C2*k10 - D*k6 + k5*P2^2 - D*G1*k9;
odeG1  = C2*k10 - D*G1*k9;
odeG2  = C1*k8 - G2*k7*P1;
odeP1  = C1*k8 + G1*k1 - k3*P1 - G2*k7*P1;
odeP2  = 2*D*k6 + G2*k2 - k4*P2 - 2*k5*P2^2;

% Solution
C1 = (P1*P2*k4*k7)/(k2*k8);
C2 = (P1*P2^2*k3*k5*k9)/(k1*k6*k10);
D = (P2^2*k5)/k6;
G1 = (P1*k3)/k1;
G2 = (P2*k4)/k2;

% Check
checkC1  = simplify(subs(odeC1))
checkC2 = simplify(subs(odeC2))
checkD  = simplify(subs(odeD))
checkG1 = simplify(subs(odeG1))
checkG2 = simplify(subs(odeG2))
checkP1 = simplify(subs(odeP1))
checkP2 = simplify(subs(odeP2))
