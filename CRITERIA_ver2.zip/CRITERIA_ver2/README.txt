
This README file contains the detailed information on the functions used in the parametrization and translation programs being developed. The MATLAB programs are as follows:

1. CRITERIA (Computing paRametrized posITive EquilibRIA) - a MATLAB program used to obtain an equilibrium parametrization of a given reaction network
2. REWARDZ (tRanslation via Elementary flux modes towards WeAkly Reversible Deficiency Zero network) - a MATLAB program used to construct a weakly reversible and deficiency zero translation of a given reaction network. This has two versions: 1) one that first breaks down the network into its finest independent subnetworks before performing the translation procedure, and 2) one that performs the translation procedure to the whole network as is.


=========================================================

  CRITERIA: Computing paRametrized posITive EquilibRIA

=========================================================

=========
Functions
=========

Main function: ComputeEquilibria

The function ComputeEquilibria returns the analytic equilibria of a chemical reaction network (CRN) parametrized by rate constants and free parameters (sigma), if any. The system's conservation laws are also listed after the solution. The output variables 'equation', 'species', 'free_parameter', 'conservation_law', and 'model' allow the user to view the following, respectively:                

        - List of parametrization of the steady state of the system         
        - List of steady state species of the network                       
        - List of free parameters of the steady state                       
        - List of conservation laws of the system                          
        - Complete network with all the species listed in the 'species' field of the structure 'model'    
                             
Finally, the elapsed time for producing the output is also displayed using MATLAB's built-in tic and toc functions. 

INPUT - model: a structure representing the CRN (see below for the details on how to fill out the structure)


ComputeEquilibria uses the following functions:     1. indepDecomp
           - OUTPUT: Decomposes a network into its finest independent decomposition. The output variables 'model', 'R', 'G', and 'P' allow the user to view the completed structure, matrix of reaction vectors of the network, undirected graph of R, and partitions representing the decomposition of the reactions, respectively.
           - INPUT: model: a structure representing the CRN

     2. analyticSolution
           - OUTPUT: Solves for the parametrized steady state solution of a network. The output variables 'param', 'B_', 'sigma_', 'k', 'sigma', 'tau', 'kinetic_deficiency', 'model', and 'skip' allow the user to view the list of parametrization of the species of the system, updated list of tau's already used in parametrization, updated list of sigma's already used in parametrization, list of rate constants of the system, list of sigma's of the system, list of tau's of the system, kinetic deficiency of the network, completed structure, and the indicator for ComputeEquilibria to skip solving the subnetwork, respectively.
           - INPUTS
                - model: a structure representing the CRN
                - P_: list of reaction numbers from the independent decomposition
                - B_: list of tau's already used in parametrization
                - sigma_: list of sigma's already used in parametrization

     3. modelSpecies
           - OUTPUT: Creates a complete model structure where the species list is filled out. The output variables 'model' and 'm' allow the user to view the complete model and the number of species, respectively.
           - INPUT: model: a structure representing the CRN

     4. stoichMatrix           - OUTPUT: Creates the stoichiometric matrix of the system. The output variables 'N', 'reactant_complex', 'product_complex', and 'r' allow the user to view the stoichiometric matrix, matrix of reactant complexes, matrix of product complexes, and number of reactions, respectively.
           - INPUTS
                - model: a structure representing the CRN
                - m: number of species

     5. GCRN
           - OUTPUT: Creates the generalized chemical reaction network (GCRN) of a translated network. The output variables 'stoichiometric_complex_reactant', 'stoichiometric_complex_product', 'kinetic_complex_reactant', 'kinetic_complex_product', 'kinetic_deficiency', 'model', and 'skip' allow the user to view the reactant stoichiometric complex of the GCRN, product stoichiometric complex of the GCRN, kinetic complex associated with the reactant stoichiometric complex, kinetic complex associated with the product stoichiometric complex, kinetic deficiency of the network, completed structure, and the indicator for ComputeEquilibria to skip solving the subnetwork, respectively.
           - INPUT: model: a structure representing the CRN

     6. kineticDeficiency
           - OUTPUT: Determines the kinetic deficiency of a GCRN. The output variable 'kinetic_deficiency' allows the user to view the kinetic deficiency.
           - INPUTS
                - kinetic_complex_reactant: matrix of kinetic reactant complexes
                - kinetic_complex_product: matrix of kinetic product complexes

     7. linkageClass
           - OUTPUT: Determines the number of linkage and strong linkage classes of the CRN. This also builds the incidence matrix of the CRN as well as groups the reactions based on the linkage class they belong. The output variables 'l', 'sl', 'incidence', and 'linkageClasses' allow the user to view the number of linkage classes, strong linkage classes, incidence matrix of the CRN, and the groupings of reactions by linkage classes, respectively.
           - INPUTS
                - reactant_complex: matrix of reactant complexes
                - product_complex: matrix of product complexes

     8. directedSpanTreeTowards
           - OUTPUT: Creates a list of directed spanning trees towards the indicated root vertex of a directed graph. The output variable 'spanTree' allows the user to view the edges of the directed spanning tree towards the root vertex.
           - INPUTS
                - G: directed graph with vertices and edges
                - r: root vertex

     9. grow           - OUTPUT: Returns the spanning trees away from the root vertex. The output variables 'spanTree' and 'spanTreeCount' allow the user to view the list of edges of the directed spanning tree towards the root vertex and the count of spanning trees rooted at G.root_vertex, respectively
           - INPUTS
                - V: number of vertices in the graph
                - G: given digraph
                - T: subtree for spanning tree generation
                - L: latest spanning tree found
                - F: list of all edges directed from vertices in T to vertices not in T
                - spanTreeCount: number of spanning trees
                - spanTree: list of edges of the directed spanning tree towards the root vertex

     10. TranslationProgramWithDecomp
	   - OUTPUT: Obtains a weakly reversible and deficiency zero translation of a CRN which incorporates network decomposition in its procedure. The output variables 'Solution', 'Index', and 'skip' allow the user to view the matrices of translated reactant and product complexes, the mapping of the translated reaction labels back to their corresponding original reaction indices, and indicator for ComputeEquilibria to skip solving the subnetwork, respectively. 
           - INPUT: model: a structure representing the CRN

     11. TranslationProgram
	   - OUTPUT: Returns the translated complexes by performing the elementary flux mode-based translation procedure. The output variables 'Solution', 'Index', and 'skip' allow the user to view the matrices of translated reactant and product complexes, the mapping of the translated reaction labels back to their corresponding original reaction indices, and indicator for ComputeEquilibria to skip solving the subnetwork, respectively.
	   - INPUTS
		- model: a structure representing the CRN
  		- parent_indices: a tracker of the original indices of the reactions in the CRN

     12. ZeroSet
	   - OUTPUT: Returns the indices of the row vectors of the matrix A that are satisfied by the vector v with equality. The output variable 'Z' allows the user to view the indices of the rows of A who dot product with v is zero. 
	   - INPUTS
		- A: matrix whose rows are tested
		- v: vector used for dot product evaluation 

     13. isExtremeRayRankTest
	   - OUTPUT: Determines whether a candidate vector is an elementary flux mode of the CRN. The output variable 'flag' serves as an indicator whether or not a candidate vector is an elementary flux mode.
	   - INPUTS
		- A_new: constraint matrix
		- r_new: candidate ray vector
		- d: number of reactions in the CRN

     14. groupBySourceComplex
	   - OUTPUT: Groups the reactions of the CRN according to their source complex. That is, reactions with the same source complex are grouped in a single list. The output variable 'F' allows the user to view the list of reaction groupings with a common source complex.
	   - INPUT: incidence: incidence matrix of the CRN

     15. findRoot
	   - OUTPUT: Determines equivalence class representatives of elementary flux modes. The output variable 'root' allows the user to track the representative of the equivalence class of a particular elementary flux mode. 
	   - INPUTS
		- i: index of the elementary flux mode
		- classVec: vector defining equivalence classes

     16. merge
	   - OUTPUT: Merges equivalence classes of two elementary flux modes. The output variable 'classVec' allows the user to view the updated vector defining the equivalence classes.
	   - INPUTS
		- i: index of the first elementary flux mode
		- j: index of the second elementary flux mode
		- classVec: vector defining the equivalence classes

     17. TranslationComplex
	   - OUTPUT: Determines the translation complexes necessary to obtain a valid weakly reversible and deficiency zero translation of a given network. The output variables 'alphaAdjusted', 'translatedSource', 'translatedProduct', 'Solution', and 'Index' allow the user to view the translation complexes, translated reactant complexes, translated product complexes, translated network, and the mapping of the translated reaction labels back to their corresponding original reaction indices, respectively.
	   - INPUTS:
		- edges: edge list of the reaction-to-reaction graph
		- sourceComplexes: original reactant complexes
		- productComplexes: original product complexes
		- linkageClasses: list of linkage classes

     18. computeLinkageClassesByReactions
	    - OUTPUT: Groups the reactions of the CRN according to its linkage classes. The output variable 'reactionClasses' allows the user to view the groupings of reactions by linkage classes.
	    - INPUTS:
		- sourceComplexes: reactant complexes
		- productComplexes: product complexes    

     19. complexToString
	    - OUTPUT: Converts a numeric vector of complexes into a human-readable string using species name. The output variable 'str' allows the user to view the string representation of the complex.
	    - INPUTS:
		- vec: vector representing a complex
		- speciesName: array containing names of species


The following classes are also used:     1. graph_
           - OUTPUT: Returns a digraph with 'V' vertices and corresponding default properties. The edges of the digraph are equally weighted.
           - INPUT: V: number of vertices in the digraph
           - This class has 8 functions inside it:
                a. noKnownEdge: To check if the edge we are trying to add is NOT YET recorded
                b. addEdge: To add an edge to the digraph
                c. removeEdge: To remove an edge from the digraph
                d. connectedVertex: To check if a vertex is a node of any edge
                e. connectedVertices: To check how many vertices of the graph are connected (but does not indicated number of components)
                f. depthFirstSearch: To try to go through each vertex starting with vertex v, then determine its parent vertex
                g. displayGraph: To display the edges of the graph
                h. plotGraph: To plot the graph
     2. edge (used in graph_ and grow)           - OUTPUT: Returns a directed edge with indicated starting and ending vertex numbers. It adds a directed edge from 'from_node' to 'to_node' to a directed graph created using the class graph_.
           - INPUTS
                - from_node: starting vertex number (natural number)
                - to_node: ending vertex number (natural number)
     3. vertex (used in graph_)
           - OUTPUT: Returns a digraph with 'V' vertices and corresponding default properties.
           - INPUT: V: number of vertices in the digraph
===================================================================================================

  REWARDZ: tRanslation via Elementary flux modes towards WeAkly Reversible Deficiency Zero network

===================================================================================================

This MATLAB program has two versions. 

The first one incorporates network decomposition in the procedure. That is, it first breaks down the network into its finest independent subnetworks before performing the translation method. The second version, on the other hand, performs the translation procedure to the whole network as is.

The main functions are TranslationProgramWithDecomp for the first version and TranslationProgram for the second version.

==========================
Functions (first version)
==========================

Main function: TranslationProgramWithDecomp

The function TranslationProgramWithDecomp returns a weakly reversible and deficiency zero translation of a given CRN using the elementary flux mode-based method as outlined in the main paper. Independent network decomposition is incorporated into the implementation of the procedure. The output variables 'N', 'R', 'x', 'translatedSource', 'translatedProduct', and 'Index_all' allow the user to view the following, respectively:

        - Stoichiometric matrix of the network         
        - Set of elementary flux modes                       
        - Binary linear program solution in the construction of the reaction-to-reaction graph                       
        - Matrix of translated source complexes                          
        - Matrix of translated product complexes
        - Array mapping translated reactions back to their corresponding original reaction indices    
                             
Finally, the elapsed time for producing the output is also displayed using MATLAB's built-in tic and toc functions. 

INPUT - model: a structure representing the CRN (see below for the details on how to fill out the structure)


TranslationProgramWithDecomp uses the following functions:

     1. TranslationProgram
	   - OUTPUT: Returns the translated complexes by performing the elementary flux mode-based translation procedure. The output variables 'Solution', 'Index', and 'skip' allow the user to view the matrices of translated reactant and product complexes, the mapping of the translated reaction labels back to their corresponding original reaction indices, and indicator for ComputeEquilibria to skip solving the subnetwork, respectively.
	   - INPUTS
		- model: a structure representing the CRN
  		- parent_indices: a tracker of the original indices of the reactions in the CRN

     2. ZeroSet
	   - OUTPUT: Returns the indices of the row vectors of the matrix A that are satisfied by the vector v with equality. The output variable 'Z' allows the user to view the indices of the rows of A who dot product with v is zero. 
	   - INPUTS
		- A: matrix whose rows are tested
		- v: vector used for dot product evaluation

     3. isExtremeRayRankTest
	   - OUTPUT: Determines whether a candidate vector is an elementary flux mode of the CRN. The output variable 'flag' serves as an indicator whether or not a candidate vector is an elementary flux mode.
	   - INPUTS
		- A_new: constraint matrix
		- r_new: candidate ray vector
		- d: number of reactions in the CRN

     4. modelSpecies
           - OUTPUT: Creates a complete model structure where the species list is filled out. The output variables 'model' and 'm' allow the user to view the complete model and the number of species, respectively.
           - INPUT: model: a structure representing the CRN

     5. stoichMatrix           - OUTPUT: Creates the stoichiometric matrix of the system. The output variables 'N', 'reactant_complex', 'product_complex', and 'r' allow the user to view the stoichiometric matrix, matrix of reactant complexes, matrix of product complexes, and number of reactions, respectively.
           - INPUTS
                - model: a structure representing the CRN
                - m: number of species

     6. linkageClass
           - OUTPUT: Determines the number of linkage and strong linkage classes of the CRN. This also builds the incidence matrix of the CRN as well as groups the reactions based on the linkage class they belong. The output variables 'l', 'sl', 'incidence', and 'linkageClasses' allow the user to view the number of linkage classes, strong linkage classes, incidence matrix of the CRN, and the groupings of reactions by linkage classes, respectively.
           - INPUTS
                - reactant_complex: matrix of reactant complexes
                - product_complex: matrix of product complexes

     7. groupBySourceComplex
	   - OUTPUT: Groups the reactions of the CRN according to their source complex. That is, reactions with the same source complex are grouped in a single list. The output variable 'F' allows the user to view the list of reaction groupings with a common source complex.
	   - INPUT: incidence: incidence matrix of the CRN

     8. findRoot
	   - OUTPUT: Determines equivalence class representatives of elementary flux modes. The output variable 'root' allows the user to track the representative of the equivalence class of a particular elementary flux mode. 
	   - INPUTS
		- i: index of the elementary flux mode
		- classVec: vector defining equivalence classes

     9. merge
	   - OUTPUT: Merges equivalence classes of two elementary flux modes. The output variable 'classVec' allows the user to view the updated vector defining the equivalence classes.
	   - INPUTS
		- i: index of the first elementary flux mode
		- j: index of the second elementary flux mode
		- classVec: vector defining the equivalence classes

     10. TranslationComplex
	   - OUTPUT: Determines the translation complexes necessary to obtain a valid weakly reversible and deficiency zero translation of a given network. The output variables 'alphaAdjusted', 'translatedSource', 'translatedProduct', 'Solution', and 'Index' allow the user to view the translation complexes, translated reactant complexes, translated product complexes, translated network, and the mapping of the translated reaction labels back to their corresponding original reaction indices, respectively.
	   - INPUTS:
		- edges: edge list of the reaction-to-reaction graph
		- sourceComplexes: original reactant complexes
		- productComplexes: original product complexes
		- linkageClasses: list of linkage classes

     11. computeLinkageClassesByReactions
	    - OUTPUT: Groups the reactions of the CRN according to its linkage classes. The output variable 'reactionClasses' allows the user to view the groupings of reactions by linkage classes.
	    - INPUTS:
		- sourceComplexes: reactant complexes
		- productComplexes: product complexes

     12. complexToString
	    - OUTPUT: Converts a numeric vector of complexes into a human-readable string using species name. The output variable 'str' allows the user to view the string representation of the complex.
	    - INPUTS:
		- vec: vector representing a complex
		- speciesName: array containing names of species

     13. indepDecomp
           - OUTPUT: Decomposes a network into its finest independent decomposition. The output variables 'model', 'R', 'G', and 'P' allow the user to view the completed structure, matrix of reaction vectors of the network, undirected graph of R, and partitions representing the decomposition of the reactions, respectively.
           - INPUT: model: a structure representing the CRN


==========================
Functions (second version)
==========================

Main function: TranslationProgram

The function TranslationProgram returns a weakly reversible and deficiency zero translation of a given CRN using the elementary flux mode-based method as outlined in the main paper. The output variables 'N', 'R', 'x', 'translatedSource', and 'translatedProduct' allow the user to view the following, respectively:

        - Stoichiometric matrix of the network         
        - Set of elementary flux modes                       
        - Binary linear program solution in the construction of the reaction-to-reaction graph                       
        - Matrix of translated source complexes                          
        - Matrix of translated product complexes   
                             
Finally, the elapsed time for producing the output is also displayed using MATLAB's built-in tic and toc functions. 

INPUT - model: a structure representing the CRN (see below for the details on how to fill out the structure)


TranslationProgram uses the following functions:

     1. ZeroSet
	   - OUTPUT: Returns the indices of the row vectors of the matrix A that are satisfied by the vector v with equality. The output variable 'Z' allows the user to view the indices of the rows of A who dot product with v is zero. 
	   - INPUTS
		- A: matrix whose rows are tested
		- v: vector used for dot product evaluation

     2. isExtremeRayRankTest
	   - OUTPUT: Determines whether a candidate vector is an elementary flux mode of the CRN. The output variable 'flag' serves as an indicator whether or not a candidate vector is an elementary flux mode.
	   - INPUTS
		- A_new: constraint matrix
		- r_new: candidate ray vector
		- d: number of reactions in the CRN

     3. modelSpecies
           - OUTPUT: Creates a complete model structure where the species list is filled out. The output variables 'model' and 'm' allow the user to view the complete model and the number of species, respectively.
           - INPUT: model: a structure representing the CRN

     4. stoichMatrix           - OUTPUT: Creates the stoichiometric matrix of the system. The output variables 'N', 'reactant_complex', 'product_complex', and 'r' allow the user to view the stoichiometric matrix, matrix of reactant complexes, matrix of product complexes, and number of reactions, respectively.
           - INPUTS
                - model: a structure representing the CRN
                - m: number of species

     5. linkageClass
           - OUTPUT: Determines the number of linkage and strong linkage classes of the CRN. This also builds the incidence matrix of the CRN as well as groups the reactions based on the linkage class they belong. The output variables 'l', 'sl', 'incidence', and 'linkageClasses' allow the user to view the number of linkage classes, strong linkage classes, incidence matrix of the CRN, and the groupings of reactions by linkage classes, respectively.
           - INPUTS
                - reactant_complex: matrix of reactant complexes
                - product_complex: matrix of product complexes

     6. groupBySourceComplex
	   - OUTPUT: Groups the reactions of the CRN according to their source complex. That is, reactions with the same source complex are grouped in a single list. The output variable 'F' allows the user to view the list of reaction groupings with a common source complex.
	   - INPUT: incidence: incidence matrix of the CRN

     7. findRoot
	   - OUTPUT: Determines equivalence class representatives of elementary flux modes. The output variable 'root' allows the user to track the representative of the equivalence class of a particular elementary flux mode. 
	   - INPUTS
		- i: index of the elementary flux mode
		- classVec: vector defining equivalence classes

     8. merge
	   - OUTPUT: Merges equivalence classes of two elementary flux modes. The output variable 'classVec' allows the user to view the updated vector defining the equivalence classes.
	   - INPUTS
		- i: index of the first elementary flux mode
		- j: index of the second elementary flux mode
		- classVec: vector defining the equivalence classes

     9. TranslationComplex
	   - OUTPUT: Determines the translation complexes necessary to obtain a valid weakly reversible and deficiency zero translation of a given network. The output variables 'alphaAdjusted', 'translatedSource', 'translatedProduct', 'Solution', and 'Index' allow the user to view the translation complexes, translated reactant complexes, translated product complexes, translated network, and the mapping of the translated reaction labels back to their corresponding original reaction indices, respectively.
	   - INPUTS:
		- edges: edge list of the reaction-to-reaction graph
		- sourceComplexes: original reactant complexes
		- productComplexes: original product complexes
		- linkageClasses: list of linkage classes

     10. computeLinkageClassesByReactions
	    - OUTPUT: Groups the reactions of the CRN according to its linkage classes. The output variable 'reactionClasses' allows the user to view the groupings of reactions by linkage classes.
	    - INPUTS:
		- sourceComplexes: reactant complexes
		- productComplexes: product complexes

     11. complexToString
	    - OUTPUT: Converts a numeric vector of complexes into a human-readable string using species name. The output variable 'str' allows the user to view the string representation of the complex.
	    - INPUTS:
		- vec: vector representing a complex
		- speciesName: array containing names of species


=====
Notes
=====

     1. CRITERIA builds on COMPILES [1] by improving its performance. The following are the improvements made:
	- The translation scheme of COMPILES is replaced by the elementary flux mode-based procedure.
	- The workflow of the algorithm is tweaked. That is, the translated subnetworks are first merged before solving the analytic equilibria. This avoids the merging of solutions per subnetwork.
	- Additional conditions are introduced in the procedure to solve the analytic equilibria of CRN with positive kinetic deficiency.

     2. The assumption is that the CRN has mass action kinetics.

     3. The algorithm begins by decomposing the network into its finest independent decomposition. Subnetworks that are not weakly reversible or have positive deficiency are then translated using the elementary flux mode–based method. The translated subnetworks are subsequently merged by taking the union of their reaction sets to form a one whole network. Finally, the analytic equilibria of the translated network are computed.

     4. The function TranslationProgramWithDecomp is part of the workflow of CRITERIA. Inside TranslationProgramWithDecomp, the functions indepDecomp and TranslationProgram are called which decomposes the network into its finest independent subnetworks and performs the elementary flux mode-based translation, respectively. 

     5. REWARDZ is another MATLAB program which returns a weakly reversible and deficiency zero translation of a given CRN. There are three major steps in the translation method:
	- Compute the elementary flux modes of the CRN via the Canonical Basis Method (a variant of the Double Description Method) [2].
	- Construct the reaction-to-reaction graph via solving a binary linear program [3].
	- Determine the translation complexes via a graph traversal method [3].

     6. The function TranslationProgram implements REWARDZ. Another version of it is the one which incorporates network decomposition in the translation procedure. That is, the network is first decomposed into its finest independent subnetworks before performing network translation. This is handled by the function TranslationProgramWithDecomp. The function TranslationProgram directly performs the translation method to the whole network as is. 

     7. The function TranslationProgramWithDecomp calls TranslationProgram in its implementation.

     8. Decomposition into the finest independent decomposition comes from [4].

     9. The elementary flux mode-based translation method comes from [3].

     10. Parametrization of steady state solution comes from [5].

     11. Computation of directed spanning trees toward vertices come from [6].

     12. Make sure that the classes graph_, edge, and vertex are in the same folder/path being used as the current working directory.


=================================
How to fill out 'model' structure
=================================

'model' is the input for the functions ComputeEquilibria, TranslationProgram, and TranslationProgramWithDecomp. It is a structure, representing the CRN, with the following fields:

   - id: name of the model
   - species: a list of all species in the network; this is left blank since incorporated into the function is a step which compiles all species used in the model
   - reaction: a list of all reactions in the network, each with the following subfields:
        - id: a string representing the reaction
        - reactant: has the following further subfields:
             - species: a list of strings representing the species in the reactant complex
             - stoichiometry: a list of numbers representing the stoichiometric coefficient of each species in the reactant complex (listed in the same order of the species)
        - product: has the following further subfields:
             - species: a list of strings representing the species in the product complex
             - stoichiometry: a list of numbers representing the stoichiometric coefficient of each species in the product complex (listed in the same order of the species)
        - reversible: has the value true or false indicating if the reaction is reversible or not, respectively
        - kinetic: has the following further subfields:
             - reactant1: a list of numbers representing the kinetic order of each species in the reactant complex in the left to right direction (listed in the same order of the species)
             - reactant2: a list of numbers representing the kinetic order of each species in the reactant complex in the right to left direction (listed in the same order of the species) (empty if the reaction is not reversible)

To fill out the 'model' structure, write a string for 'model.id': this is just to put a name to the network. To add the reactions to the network, use the function addReaction where the output is 'model'. addReaction is developed to make the input of reactions of the CRN easier than the input in [10]:

   addReaction
      - OUTPUT: Returns a structure called 'model' with added field 'reaction' with subfields 'id', 'reactant', 'product', 'reversible', and 'kinetic'. The output variable 'model' allows the user to view the network with the added reaction.
      - INPUTS
           - model: a structure, representing the CRN
           - id: visual representation of the reaction, e.g., reactant -> product (string)
           - reactant_species: species of the reactant complex (cell)
           - reactant_stoichiometry: stoichiometry of the species of the reactant complex (cell)
           - reactant_kinetic: kinetic orders of the species of the reactant complex (array)
           - product_species: species of the product complex (cell)
           - product_stoichiometry: stoichiometry of the species of the product complex (cell)
           - product_kinetic: "kinetic orders" of the species of the product complex, if the reaction is reversible (array); if the reaction in NOT reversible, leave blank
           - reversible: logical; whether the reaction is reversible or not (true or false)

      * Make sure the function addReaction is in the same folder/path being used as the current working directory.



========
Examples
========

26 examples are included in this folder:

   - Model A: Histidine Kinase [7]

   - Model B: Miao's Influenza Virus Model [8]

   - Model C: IDHKP-IDH [9]

   - Model D: 1-Site PD Network [10]

   - Model E: Hybrid Histidine Kinase [7]

   - Model F: PTM System [11]

   - Model G: 2-Protein Gene Transcription [7,12]

   - Model H: Reduced ERK Network [13]

   - Model I: 2-Site PD Network [10]

   - Model J: Two-Substrate Phosphorylation [7]

   - Model K: Two-Layer Cascade of Modification Cycles [11]

   - Model L: EnvZ-OmpR [5]

   - Model M: Two-Component Osmoregulator in E. Coli [14]

   - Model N: Hernandez's Influenza Virus Model [8]

   - Model O: Modified Two-Component Osmoregulator in E. Coli [14]

   - Model P: CRISPRi Model 1 [15]

   - Model Q: MAPK [3]

   - Model R: Full ERK Model [13]

   - Model S: 3-Site PD Network [10]

   - Model T: Zigzag Model of Plant-Pathogen Interactions [3]

   - Model U: CRISPRi Model 2 [15]

   - Model V: MAPK Signaling Cascade [11]

   - Model W: WNT Signaling Pathway [5]

   - Model X: Insulin Signaling Pathway [16]

   - Model Y: CRISPRi Model 3 [15]

   - Model Z: CRISPRi Model 4 [15]


All models include checker files to show that the solutions returned by CRITERA are indeed steady states of their respective ordinary differential equations.


===================
Contact Information
===================

For questions, comments, and suggestions, feel free to contact me at evvillejo@up.edu.ph or at exequieljun@gmail.com.


- Exequiel Jun Villejo (28 June 2026)

==========
References
==========

   [1] Hernandez BS, Lubenia PVN, Johnston MD, Kim JK (2023) A framework for deriving analytic steady states of biochemical reaction networks. PLoS Comput Biol. 19(4):e1011039.

   [2] Klapper I, Szyld DB, Zhao K. Metabolic networks, elementary flux modes, and polyhedral cones Society for Industrial and Applied Mathematics; 2021.

   [3] Johnston MD, Burton E. Computing weakly reversible deficiency zero network translations using elementary flux modes Bull Math Biol. 2019;81:1613–1644.

   [4] Hernandez B, De la Cruz R (2021) Independent decompositions of chemical reaction networks. Bull Math Biol 83(76):1–23. https://doi.org/10.1007/s11538-021-00906-3

   [5] Johnston M, Mueller S, Pantea C (2019) A deficiency-based approach to parametrizing positive equilibria of biochemical reaction systems. Bull Math Biol 81:1143–1172. https://doi.org/10.1007/s11538-018-00562-0

   [6] Gabow H and Meyers E (1978) Finding all spanning trees of directed and undirected graphs. SIAM J Comput 7(3):280-287. https://doi.org/10.1137/0207024

   [7] Conradi C, Feliu E, Mincheva M, Wiuf C. Identifying parameter regions for multistationarity. PLOS Comp Bio. 2017; 13(10): e1005751.

   [8] Peter S, Holzer M, Lamkiewicz K, Speroni di Fenizio P, Al Hwaeer H, Marz M, Schuster S, Dittrich P, Ibrahim B. Structure and hierarchy of influenza virus models revealed by reaction network analysis Viruses. 2019;11(5):449.

   [9] Shinar G, Rabinowitz J, Alon U. Robustness in glyoxylate bypass regulation PLOS Comp Bio. 2009;5(3):e1000297.

   [10] Villareal KA, Hernandez BS, Lubenia PV. Derivation of steady state parametrizations of chemical reaction networks with n independent and identical subnetworks MATCH Commun Math Comput Chem. 2024;91:337-365.

   [11] Feliu E, Wiuf C. Variable elimination in post-translational modification reaction networks with mass-action kinetics J Math Biol. 2013;66:281-310.

   [12] Siegal-Gaskins D, Franco E, Zhou T, Murray R. An analytical approach to bistable biological circuit discrimination using real algebraic geometry J R S Interface. 2015;12:20150288.

   [13] Obatake N, Shiu A, Tang X, Torres A. Oscillations and bistability in a model of ERK regulation J Math Biol. 2019;79:1515-1549.

   [14] Karp R, Perez Millan M, Dasgupta T, Dickenstein A, Gunawardena J. Complex-linear invariants of biochemical networks J Theor Biol. 2012;311:130-138.

   [15] Santos-Moreno J, Tasiudi E, Stelling J, Schaerli Y. Multistable and dynamic CRISPRi-based synthetic circuits. Nat Commun. 2020;11:2746.

   [16] Lubenia PVN, Mendoza ER, Lao AR. Reaction Network Analysis of Metabolic Insulin Signaling. Bull Math Biol. 2022;84:129.

