% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10
syms E EIp EIpI I Ip

% ODEs
odeE = EIp*k2 + EIp*k3 - E*Ip*k1;
odeEIp = EIpI*k5 - EIp*k3 - EIp*k2 + EIpI*k6 - EIp*I*k4 + E*Ip*k1;
odeEIpI = EIp*I*k4 - EIpI*k6 - EIpI*k5;
odeI = EIp*k3 + EIpI*k5 - EIp*I*k4;
odeIp = EIp*k2 + EIpI*k6 - E*Ip*k1;

% Solution
EIp = (EIpI*k6)/k3;
E = (EIpI*k6*(k2 + k3))/(Ip*k1*k3);
I = (k3*(k5 + k6))/(k4*k6);

% Check
checkE  = simplify(subs(odeE))
checkEIp  = simplify(subs(odeEIp))
checkEIpI  = simplify(subs(odeEIpI))
checkI  = simplify(subs(odeI))
checkIp  = simplify(subs(odeIp))
