% Clear all variables
clear all
clc;
clear;

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16
syms Cassg1 Cassg2 Casssg1 Casssg2 G1 G1P2 G1P2U1 G1P2U2 G2 G2P1 G2P1U1 G2P1U2

% ODEs
ODECassg1 = G1P2U1*k9 + G2P1U1*k5 - Cassg1*G1P2*k8 - Cassg1*G2P1*k4;
ODECassg2 = G1P2U2*k7 + G2P1U2*k16 - Cassg2*G1P2*k6 - Cassg2*G2P1*k15;
ODECasssg1 = G1*k1 - Casssg1*k13 + G2P1*k12 - Casssg1*G2*k11;
ODECasssg2 = G2*k10 - Casssg2*k14 + G1P2*k3 - Casssg2*G1*k2;
ODEG1 = G1P2*k3 - Casssg2*G1*k2;
ODEG1P2 = G1P2U2*k7 - G1P2*k3 + G1P2U1*k9 + Casssg2*G1*k2 - Cassg2*G1P2*k6 - Cassg1*G1P2*k8;
ODEG1P2U1 = Cassg1*G1P2*k8 - G1P2U1*k9;
ODEG1P2U2 = Cassg2*G1P2*k6 - G1P2U2*k7;
ODEG2 = G2P1*k12 - Casssg1*G2*k11;
ODEG2P1 = G2P1U1*k5 - G2P1*k12 + G2P1U2*k16 + Casssg1*G2*k11 - Cassg1*G2P1*k4 - Cassg2*G2P1*k15;
ODEG2P1U1 = Cassg1*G2P1*k4 - G2P1U1*k5;
ODEG2P1U2 = Cassg2*G2P1*k15 - G2P1U2*k16;

% Solution
Cassg1 = (G1P2U1*k9)/(G1P2*k8);
Cassg2 = (G1P2U2*k7)/(G1P2*k6);
Casssg1 = (G1P2*k1*k3*k14)/(G2*k2*k10*k13);
Casssg2 = (G2*k10)/k14;
G1 = (G1P2*k3*k14)/(G2*k2*k10);
G2P1 = (G1P2*k1*k3*k11*k14)/(k2*k10*k12*k13);
G2P1U1 = (G1P2U1*k1*k3*k4*k9*k11*k14)/(k2*k5*k8*k10*k12*k13);
G2P1U2 = (G1P2U2*k1*k3*k7*k11*k14*k15)/(k2*k6*k10*k12*k13*k16);

% Check
checkCassg1  = simplify(subs(ODECassg1))
checkCassg2  = simplify(subs(ODECassg2))
checkCasssg1  = simplify(subs(ODECasssg1))
checkCasssg2  = simplify(subs(ODECasssg2))
checkG1  = simplify(subs(ODEG1))
checkG1P2  = simplify(subs(ODEG1P2))
checkG1P2U1  = simplify(subs(ODEG1P2U1))
checkG1P2U2  = simplify(subs(ODEG1P2U2))
checkG2  = simplify(subs(ODEG2))
checkG2P1  = simplify(subs(ODEG2P1))
checkG2P1U1  = simplify(subs(ODEG2P1U1))
checkG2P1U2  = simplify(subs(ODEG2P1U2))