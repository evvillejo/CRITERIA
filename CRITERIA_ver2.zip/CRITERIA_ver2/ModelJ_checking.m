% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12
syms A AK Ap ApF B BK Bp BpF F K
syms tau4

% ODEs
ODEA = AK*k2 + ApF*k6 - A*K*k1;
ODEAK = A*K*k1 - AK*k3 - AK*k2;
ODEAp = AK*k3 + ApF*k5 - Ap*F*k4;
ODEApF = Ap*F*k4 - ApF*k6 - ApF*k5;
ODEB = BK*k8 + BpF*k12 - B*K*k7;
ODEBK = B*K*k7 - BK*k9 - BK*k8;
ODEBp = BK*k9 + BpF*k11 - Bp*F*k10;
ODEBpF = Bp*F*k10 - BpF*k12 - BpF*k11;
ODEF = ApF*k5 + ApF*k6 + BpF*k11 + BpF*k12 - Ap*F*k4 - Bp*F*k10;
ODEK = AK*k2 + AK*k3 + BK*k8 + BK*k9 - A*K*k1 - B*K*k7;

% Solution
A = (ApF*k6*k7*k9*(k2 + k3))/(k1*k3*k12*tau4*(k8 + k9));
AK = (ApF*k6)/k3;
Ap = (ApF*(k5 + k6))/(F*k4);
B = BpF/tau4;
BK = (BpF*k12)/k9;
Bp = (BpF*(k11 + k12))/(F*k10);
K = (k12*tau4*(k8 + k9))/(k7*k9);

% Check
checkA  = simplify(subs(ODEA))
checkAK  = simplify(subs(ODEAK))
checkAp  = simplify(subs(ODEAp))
checkApF  = simplify(subs(ODEApF))
checkB  = simplify(subs(ODEB))
checkBK  = simplify(subs(ODEBK))
checkBp  = simplify(subs(ODEBp))
checkBpF  = simplify(subs(ODEBpF))
checkF  = simplify(subs(ODEF))
checkK  = simplify(subs(ODEK))
