% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12
syms E F S1 S2 S3 S4 Y1 Y2 Y3 Y4

% ODEs
ODEE = k2*Y1 + k3*Y1 - E*k1*S1;
ODEF = k8*Y3 + k9*Y3 + k11*Y4 + k12*Y4 - F*k7*S2 - F*k10*S4;
ODES1 = k2*Y1 + k9*Y3 - E*k1*S1;
ODES2 = k3*Y1 + k5*Y2 + k6*Y2 + k8*Y3 - F*k7*S2 - k4*S2*S3;
ODES3 = k5*Y2 + k12*Y4 - k4*S2*S3;
ODES4 = k6*Y2 + k11*Y4 - F*k10*S4;
ODEY1 = E*k1*S1 - k3*Y1 - k2*Y1;
ODEY2 = k4*S2*S3 - k6*Y2 - k5*Y2;
ODEY3 = F*k7*S2 - k9*Y3 - k8*Y3;
ODEY4 = F*k10*S4 - k12*Y4 - k11*Y4;

% Solution
E = (Y3*k9*(k2 + k3))/(S1*k1*k3);
F = (Y2*k6*(k11 + k12))/(S4*k10*k12);
S2 = (S4*Y3*k10*k12*(k8 + k9))/(Y2*k6*k7*(k11 + k12));
S3 = (Y2^2*k6*k7*(k5 + k6)*(k11 + k12))/(S4*Y3*k4*k10*k12*(k8 + k9));
Y1 = (Y3*k9)/k3;
Y4 = (Y2*k6)/k12;

% Check
checkE  = simplify(subs(ODEE))
checkF  = simplify(subs(ODEF))
checkS1  = simplify(subs(ODES1))
checkS2  = simplify(subs(ODES2))
checkS3  = simplify(subs(ODES3))
checkS4  = simplify(subs(ODES4))
checkY1  = simplify(subs(ODEY1))
checkY2  = simplify(subs(ODEY2))
checkY3  = simplify(subs(ODEY3))
checkY4  = simplify(subs(ODEY4))

