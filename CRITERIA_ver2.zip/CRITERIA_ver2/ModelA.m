% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
%                                                                           %
%    MODEL A: Histidine-Kinase                                              %
%                                                                           %
%                                                                           %
% Reference: Conradi C, Feliu E, Mincheva M, Wiuf C. Identifying parameter  %
%               regions for multistationarity. PLOS Comp Bio. 2017; 13(10): %
%               e1005751.                                                   %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %


% Clear all variables
clear all
clc;
clear;

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'MODEL A: Histidine Kinase';
model = addReaction(model, 'X->Xp', ...         
                           {'X'}, {1}, [1], ...  
                           {'Xp'}, {1}, [ ], ...
                           false);      
model = addReaction(model, 'Xp+Y->X+Yp', ...
                           {'Xp', 'Y'}, {1, 1}, [1, 1], ...
                           {'X', 'Yp'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'X+Yp->Xp+Y', ...
                           {'X', 'Yp'}, {1, 1}, [1, 1], ...
                           {'Xp', 'Y'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'Yp->Y', ...
                           {'Yp'}, {1}, [1], ...
                           {'Y'}, {1}, [ ], ...
                           false);

% Generate a weakly reversible and deficiency zero translation via EFM-based network translation
% [N, R, X, translatedSource, translatedProduct] = TranslationProgram(model);
% [N, R, X, translatedSource, translatedProduct] = TranslationProgramWithDecomp(model);

% Compute analytic equilibria
[equation, species, free_parameter, conservation_law, model] = ComputeEquilibria(model);
