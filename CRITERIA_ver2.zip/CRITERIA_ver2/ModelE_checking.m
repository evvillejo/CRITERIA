% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6
syms HKoo HKop HKpo HKpp RR RRp

% ODEs
ODEHKoo = HKop*k4*RR - HKoo*k1;
ODEHKop = HKpo*k2 - HKop*k3 - HKop*k4*RR;
ODEHKpo = HKoo*k1 - HKpo*k2 + HKpp*k5*RR;
ODEHKpp = HKop*k3 - HKpp*k5*RR;
ODERR = k6*RRp - HKop*k4*RR - HKpp*k5*RR;
ODERRp = HKop*k4*RR - k6*RRp + HKpp*k5*RR;

% Solution
HKoo = (RR*RRp*k4*k6)/(k1*(k3 + RR*k4));
HKop = (RRp*k6)/(k3 + RR*k4);
HKpo = (RRp*k6)/k2;
HKpp = (RRp*k3*k6)/(RR*k5*(k3 + RR*k4));

% Check
checkHkoo  = simplify(subs(ODEHKoo))
checkHKop = simplify(subs(ODEHKop))
checkHKpo  = simplify(subs(ODEHKpo))
checkHKpp = simplify(subs(ODEHKpp))
checkRR = simplify(subs(ODERR))
checkRRp = simplify(subs(ODERRp))