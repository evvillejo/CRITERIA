% Clear all variables
clear all
clc;
clear;

% Define the symbols
syms k1 k2 k3 k4 k5 
syms Ep Epstar V

% ODEs
ODEEp = Ep*k1 - Ep*k2*V;
ODEEpstar = Ep*k2*V - Epstar*k3;
ODEV = Epstar*k4 - k5*V;

% Solution
Ep = (k3*k5)/(k2*k4);
Epstar = (k1*k5)/(k2*k4);
V = k1/k2;

% Check
checkEp  = simplify(subs(ODEEp))
checkEpstar  = simplify(subs(ODEEpstar))
checkV  = simplify(subs(ODEV))