% Clear all variables
clear all
clc;
clear;

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10
syms E F S00 S00E S01 S01E S10 S10F S11 S11F

% ODEs
ODEE = k3*S01E + k4*S01E - E*k1*S00;
ODEF = k8*S10F + k9*S10F - F*k6*S11;
ODES00 = k9*S10F - E*k1*S00 + F*k10*S01;
ODES00E = E*k1*S00 - k2*S00E;
ODES01 = k3*S01E - F*k10*S01;
ODES01E = k2*S00E - k3*S01E - k4*S01E;
ODES10 = k8*S10F - E*k5*S10;
ODES10F = k7*S11F - k8*S10F - k9*S10F;
ODES11 = k4*S01E + E*k5*S10 - F*k6*S11;
ODES11F = F*k6*S11 - k7*S11F;

% Solution
E = (S10F*k8)/(S10*k5);
F = (S10F*(k8 + k9))/(S11*k6);
S00 = (S10*k5*k9*(k3 + k4))/(k1*k4*k8);
S01 = (S11*k3*k6*k9)/(k4*k10*(k8 + k9));
S00E = (S10F*k9*(k3 + k4))/(k2*k4);
S01E = (S10F*k9)/k4;
S11F = (S10F*(k8 + k9))/k7;

% Check
checkE  = simplify(subs(ODEE))
checkF  = simplify(subs(ODEF))
checkS00  = simplify(subs(ODES00))
checkS00E  = simplify(subs(ODES00E))
checkS01  = simplify(subs(ODES01))
checkS01E  = simplify(subs(ODES01E))
checkS10  = simplify(subs(ODES10))
checkS10F  = simplify(subs(ODES10F))
checkS11  = simplify(subs(ODES11))
checkS11F  = simplify(subs(ODES11F))