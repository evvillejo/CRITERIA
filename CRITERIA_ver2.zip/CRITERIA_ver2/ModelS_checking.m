% Clear all variables
clear all
clc;
clear;

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16 k17 k18
syms F K S0 S0K S1 S1F S1K S2 S2F S2K S3 S3F
syms sigma2

% ODEs
ODEF = k11*S3F + k12*S3F + k14*S2F + k15*S2F + k17*S1F + k18*S1F - F*k10*S3 - F*k13*S2 - F*k16*S1;
ODEK = k2*S0K + k3*S0K + k5*S1K + k6*S1K + k8*S2K + k9*S2K - K*k1*S0 - K*k4*S1 - K*k7*S2;
ODES0 = k18*S1F + k2*S0K - K*k1*S0;
ODES0K = K*k1*S0 - k3*S0K - k2*S0K;
ODES1 = k15*S2F + k17*S1F + k3*S0K + k5*S1K - F*k16*S1 - K*k4*S1;
ODES1F = F*k16*S1 - k18*S1F - k17*S1F;
ODES1K = K*k4*S1 - k6*S1K - k5*S1K;
ODES2 = k12*S3F + k14*S2F + k6*S1K + k8*S2K - F*k13*S2 - K*k7*S2;
ODES2F = F*k13*S2 - k15*S2F - k14*S2F;
ODES2K = K*k7*S2 - k9*S2K - k8*S2K;
ODES3 = k11*S3F + k9*S2K - F*k10*S3;
ODES3F = F*k10*S3 - k12*S3F - k11*S3F;

sigma1 = (k13*sigma2)/(k16);

% Solution
F = (S2F*(k14 + k15))/(S2*k13);
K = (S2F*(k14 + k15))/(S2*sigma1);
S0 = (S2*k15*k18*sigma1*sigma2*(k2 + k3)*(k5 + k6))/(k1*k3*k4*k6*(k14 + k15)*(k17 + k18));
S1 = (S2*k15*sigma1*(k5 + k6))/(k4*k6*(k14 + k15));
S3 = (S2*k7*k9*k13*(k11 + k12))/(k10*k12*sigma1*(k8 + k9));
S1F = (S2F*k15*sigma2*(k5 + k6))/(k4*k6*(k17 + k18));
S3F = (S2F*k7*k9*(k14 + k15))/(k12*sigma1*(k8 + k9));
S0K = (S2F*k15*k18*sigma2*(k5 + k6))/(k3*k4*k6*(k17 + k18));
S1K = (S2F*k15)/k6;
S2K = (S2F*k7*(k14 + k15))/(sigma1*(k8 + k9));

% Check
checkF  = simplify(subs(ODEF))
checkK  = simplify(subs(ODEF))
checkS0  = simplify(subs(ODES0))
checkS0K  = simplify(subs(ODES0K))
checkS1  = simplify(subs(ODES1))
checkS1F  = simplify(subs(ODES1F))
checkS1K  = simplify(subs(ODES1K))
checkS2  = simplify(subs(ODES2))
checkS2F  = simplify(subs(ODES2F))
checkS2K  = simplify(subs(ODES2K))
checkS3  = simplify(subs(ODES3))
checkS3F  = simplify(subs(ODES3F))