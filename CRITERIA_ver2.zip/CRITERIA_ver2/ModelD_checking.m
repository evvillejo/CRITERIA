% Clear all variables
clear all
clc;
clear;

% Define the symbols
syms k1 k2 k3 k4 k5 k6 
syms F K S0 S0K S1 S1F

% ODEs
ODEF = k5*S1F + k6*S1F - F*k4*S1;
ODEK = k2*S0K + k3*S0K - K*k1*S0;
ODES0 = k6*S1F + k2*S0K - K*k1*S0;
ODES0K = K*k1*S0 - k3*S0K - k2*S0K;
ODES1 = k5*S1F + k3*S0K - F*k4*S1;
ODES1F = F*k4*S1 - k6*S1F - k5*S1F;

% Solution
F = (S1F*(k5 + k6))/(S1*k4);
K = (S1F*k6*(k2 + k3))/(S0*k1*k3);
S0K = (S1F*k6)/k3;

% Check
checkF  = simplify(subs(ODEF))
checkK  = simplify(subs(ODEK))
checkS0  = simplify(subs(ODES0))
checkS0K  = simplify(subs(ODES0K))
checkS1  = simplify(subs(ODES1))
checkS1F  = simplify(subs(ODES1F))