% Clear all variables
clear all
clc
clear

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15 k16 k17 k18 k19 k20 k21 k22 k23 k24
syms X1 X2 X4 X5 X6 X7 X8 X9 X10 X11 X12 X13 X14 X15 X16 X17 X18 
syms sigma1 tau1 tau2 tau3

% ODEs
ODEX1 = k2*X11 + k3*X11 - k1*X1*X5;
ODEX2 = k5*X12 + k6*X12 - k4*X2*X6;
ODEX4 = k20*X17 + k21*X17 + k23*X18 + k24*X18 - k19*X4*X10 - k22*X4*X8;
ODEX5 = k2*X11 + k6*X12 - k1*X1*X5;
ODEX6 = k3*X11 + k5*X12 + k8*X13 + k9*X13 + k11*X15 + k12*X15 + k14*X14 + k15*X14 + k17*X16 + k18*X16 - k4*X2*X6 - k7*X6*X7 - k10*X6*X8 - k13*X6*X7 - k16*X6*X9;
ODEX7 = k8*X13 + k14*X14 + k24*X18 - k7*X6*X7 - k13*X6*X7;
ODEX8 = k9*X13 + k11*X15 + k21*X17 + k23*X18 - k10*X6*X8 - k22*X4*X8;
ODEX9 = k15*X14 + k17*X16 - k16*X6*X9;
ODEX10 = k12*X15 + k18*X16 + k20*X17 - k19*X4*X10;
ODEX11 = k1*X1*X5 - k3*X11 - k2*X11;
ODEX12 = k4*X2*X6 - k6*X12 - k5*X12;
ODEX13 = k7*X6*X7 - k9*X13 - k8*X13;
ODEX14 = k13*X6*X7 - k15*X14 - k14*X14;
ODEX15 = k10*X6*X8 - k12*X15 - k11*X15;
ODEX16 = k16*X6*X9 - k18*X16 - k17*X16;
ODEX17 = k19*X4*X10 - k21*X17 - k20*X17;
ODEX18 = k22*X4*X8 - k24*X18 - k23*X18;

% Solution
X1 = (tau1*tau3)/tau2;
X2 = (k19*sigma1*tau1*(k5 + k6))/(k4*k22*(k20 + k21));
X4 = (tau3*(k20 + k21))/k19;
X5 = (k6*tau2*(k2 + k3))/(k1*k3);
X6 = (k22*tau3*(k20 + k21))/(k19*sigma1);
X7 = (X10*k19*k21*k24*sigma1^2*(k8 + k9)*(k11 + k12)*(k14 + k15))/(k22*(k20 + k21)*(k7*k9*k10*k12*k14*k23 + k7*k9*k10*k12*k14*k24 + k7*k9*k10*k12*k15*k23 + k7*k9*k10*k12*k15*k24 + k8*k10*k12*k13*k15*k23 + k8*k10*k12*k13*k15*k24 + k9*k10*k12*k13*k15*k23 + k9*k10*k12*k13*k15*k24 + k8*k11*k13*k15*k24*sigma1 + k8*k12*k13*k15*k24*sigma1 + k9*k11*k13*k15*k24*sigma1 + k9*k12*k13*k15*k24*sigma1));
X8 = (X10*k19*k21*sigma1*(k11 + k12)*(k23 + k24)*(k7*k9*k14 + k7*k9*k15 + k8*k13*k15 + k9*k13*k15))/(k22*(k20 + k21)*(k7*k9*k10*k12*k14*k23 + k7*k9*k10*k12*k14*k24 + k7*k9*k10*k12*k15*k23 + k7*k9*k10*k12*k15*k24 + k8*k10*k12*k13*k15*k23 + k8*k10*k12*k13*k15*k24 + k9*k10*k12*k13*k15*k23 + k9*k10*k12*k13*k15*k24 + k8*k11*k13*k15*k24*sigma1 + k8*k12*k13*k15*k24*sigma1 + k9*k11*k13*k15*k24*sigma1 + k9*k12*k13*k15*k24*sigma1));
X9 = (X10*k13*k15*k19*k21*k24*sigma1^2*(k8 + k9)*(k11 + k12)*(k17 + k18))/(k16*k18*k22*(k20 + k21)*(k7*k9*k10*k12*k14*k23 + k7*k9*k10*k12*k14*k24 + k7*k9*k10*k12*k15*k23 + k7*k9*k10*k12*k15*k24 + k8*k10*k12*k13*k15*k23 + k8*k10*k12*k13*k15*k24 + k9*k10*k12*k13*k15*k23 + k9*k10*k12*k13*k15*k24 + k8*k11*k13*k15*k24*sigma1 + k8*k12*k13*k15*k24*sigma1 + k9*k11*k13*k15*k24*sigma1 + k9*k12*k13*k15*k24*sigma1));
X11 = (k6*tau1*tau3)/k3;
X12 = tau1*tau3;
X13 = (X10*k7*k21*k24*sigma1*tau3*(k11 + k12)*(k14 + k15))/(k7*k9*k10*k12*k14*k23 + k7*k9*k10*k12*k14*k24 + k7*k9*k10*k12*k15*k23 + k7*k9*k10*k12*k15*k24 + k8*k10*k12*k13*k15*k23 + k8*k10*k12*k13*k15*k24 + k9*k10*k12*k13*k15*k23 + k9*k10*k12*k13*k15*k24 + k8*k11*k13*k15*k24*sigma1 + k8*k12*k13*k15*k24*sigma1 + k9*k11*k13*k15*k24*sigma1 + k9*k12*k13*k15*k24*sigma1);
X14 = (X10*k13*k21*k24*sigma1*tau3*(k8 + k9)*(k11 + k12))/(k7*k9*k10*k12*k14*k23 + k7*k9*k10*k12*k14*k24 + k7*k9*k10*k12*k15*k23 + k7*k9*k10*k12*k15*k24 + k8*k10*k12*k13*k15*k23 + k8*k10*k12*k13*k15*k24 + k9*k10*k12*k13*k15*k23 + k9*k10*k12*k13*k15*k24 + k8*k11*k13*k15*k24*sigma1 + k8*k12*k13*k15*k24*sigma1 + k9*k11*k13*k15*k24*sigma1 + k9*k12*k13*k15*k24*sigma1);
X15 = (X10*k10*k21*tau3*(k23 + k24)*(k7*k9*k14 + k7*k9*k15 + k8*k13*k15 + k9*k13*k15))/(k7*k9*k10*k12*k14*k23 + k7*k9*k10*k12*k14*k24 + k7*k9*k10*k12*k15*k23 + k7*k9*k10*k12*k15*k24 + k8*k10*k12*k13*k15*k23 + k8*k10*k12*k13*k15*k24 + k9*k10*k12*k13*k15*k23 + k9*k10*k12*k13*k15*k24 + k8*k11*k13*k15*k24*sigma1 + k8*k12*k13*k15*k24*sigma1 + k9*k11*k13*k15*k24*sigma1 + k9*k12*k13*k15*k24*sigma1);
X16 = (X10*k13*k15*k21*k24*sigma1*tau3*(k8 + k9)*(k11 + k12))/(k18*(k7*k9*k10*k12*k14*k23 + k7*k9*k10*k12*k14*k24 + k7*k9*k10*k12*k15*k23 + k7*k9*k10*k12*k15*k24 + k8*k10*k12*k13*k15*k23 + k8*k10*k12*k13*k15*k24 + k9*k10*k12*k13*k15*k23 + k9*k10*k12*k13*k15*k24 + k8*k11*k13*k15*k24*sigma1 + k8*k12*k13*k15*k24*sigma1 + k9*k11*k13*k15*k24*sigma1 + k9*k12*k13*k15*k24*sigma1));
X17 = X10*tau3;
X18 = (X10*k21*sigma1*tau3*(k11 + k12)*(k7*k9*k14 + k7*k9*k15 + k8*k13*k15 + k9*k13*k15))/(k7*k9*k10*k12*k14*k23 + k7*k9*k10*k12*k14*k24 + k7*k9*k10*k12*k15*k23 + k7*k9*k10*k12*k15*k24 + k8*k10*k12*k13*k15*k23 + k8*k10*k12*k13*k15*k24 + k9*k10*k12*k13*k15*k23 + k9*k10*k12*k13*k15*k24 + k8*k11*k13*k15*k24*sigma1 + k8*k12*k13*k15*k24*sigma1 + k9*k11*k13*k15*k24*sigma1 + k9*k12*k13*k15*k24*sigma1);

% Check
checkX1  = simplify(subs(ODEX1))
checkX2  = simplify(subs(ODEX2))
checkX4  = simplify(subs(ODEX4))
checkX5  = simplify(subs(ODEX5))
checkX6  = simplify(subs(ODEX6))
checkX7  = simplify(subs(ODEX7))
checkX8  = simplify(subs(ODEX8))
checkX9  = simplify(subs(ODEX9))
checkX10  = simplify(subs(ODEX10))
checkX11  = simplify(subs(ODEX11))
checkX12  = simplify(subs(ODEX12))
checkX13  = simplify(subs(ODEX13))
checkX14  = simplify(subs(ODEX14))
checkX15  = simplify(subs(ODEX15))
checkX16  = simplify(subs(ODEX16))
checkX17  = simplify(subs(ODEX17))
checkX18  = simplify(subs(ODEX18))