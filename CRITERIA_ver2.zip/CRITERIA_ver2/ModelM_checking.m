% Clear all variables
clc
clear all

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 k13 k14 k15
syms X1 X2 X3 X4 X5 X6 X7 X8 X9

% ODEs
ODEX1 = k2*X2 - k1*X1 + k14*X9 + k15*X9 - k13*X1*X7;
ODEX2 = k1*X1 - k2*X2 - k3*X2 + k4*X3 + k8*X6 - k9*X2*X7;
ODEX3 = k3*X2 - k4*X3 - k5*X3 + k11*X8 + k12*X8 - k10*X3*X7;
ODEX4 = k5*X3 + k7*X6 - k6*X4*X5;
ODEX5 = k7*X6 + k12*X8 + k15*X9 - k6*X4*X5;
ODEX6 = k6*X4*X5 - k8*X6 - k7*X6 + k9*X2*X7;
ODEX7 = k8*X6 + k11*X8 + k14*X9 - k9*X2*X7 - k10*X3*X7 - k13*X1*X7;
ODEX8 = k10*X3*X7 - k12*X8 - k11*X8;
ODEX9 = k13*X1*X7 - k15*X9 - k14*X9;

sigma1 = (k2*k13*(k4 + k5)) / (k1*k3);
sigma2 = (k5*k9*(k11 + k12)*(k14 + k15)) / (k10*k12*k14 + k10*k12*k15 + k11*k15*sigma1 + k12*k15*sigma1);

% Solution
X1 = (X9*k2*(k4 + k5)*(k10*k12*k14 + k10*k12*k15 + k11*k15*sigma1 + k12*k15*sigma1))/(k1*k3*k5*sigma1*(k11 + k12));
X2 = (X9*(k4 + k5)*(k10*k12*k14 + k10*k12*k15 + k11*k15*sigma1 + k12*k15*sigma1))/(k3*k5*sigma1*(k11 + k12));
X3 = (X9*(k10*k12*k14 + k10*k12*k15 + k11*k15*sigma1 + k12*k15*sigma1))/(k5*sigma1*(k11 + k12));
X4 = (X9*(k3*k5*k7 + k3*k5*k8 + k4*k7*sigma2 + k5*k7*sigma2)*(k10*k12*k14 + k10*k12*k15 + k11*k15*sigma1 + k12*k15*sigma1))/(X5*k3*k5*k6*k8*sigma1*(k11 + k12));
X6 = (X9*(k3*k5 + k4*sigma2 + k5*sigma2)*(k10*k12*k14 + k10*k12*k15 + k11*k15*sigma1 + k12*k15*sigma1))/(k3*k5*k8*sigma1*(k11 + k12));
X7 = (k5*(k11 + k12)*(k14 + k15))/(k10*k12*k14 + k10*k12*k15 + k11*k15*sigma1 + k12*k15*sigma1);
X8 = (X9*k10*(k14 + k15))/(sigma1*(k11 + k12));

% Check
checkX1  = simplify(subs(ODEX1))
checkX2  = simplify(subs(ODEX2))
checkX3  = simplify(subs(ODEX3))
checkX4  = simplify(subs(ODEX4))
checkX5  = simplify(subs(ODEX5))
checkX6  = simplify(subs(ODEX6))
checkX7  = simplify(subs(ODEX7))
checkX8  = simplify(subs(ODEX8))
checkX9  = simplify(subs(ODEX9))