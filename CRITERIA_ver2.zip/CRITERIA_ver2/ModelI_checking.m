% Clear all variables
clear all
clc;
clear;

% Define the symbols
syms k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 k11 k12 
syms F K S0 S0K S1 S1F S1K S2 S2F
syms sigma1

% ODEs
ODEF = k5*S1F + k6*S1F + k11*S2F + k12*S2F - F*k4*S1 - F*k10*S2;
ODEK = k2*S0K + k3*S0K + k8*S1K + k9*S1K - K*k1*S0 - K*k7*S1;
ODES0 = k6*S1F + k2*S0K - K*k1*S0;
ODES0K = K*k1*S0 - k3*S0K - k2*S0K;
ODES1 = k5*S1F + k12*S2F + k3*S0K + k8*S1K - F*k4*S1 - K*k7*S1;
ODES1F = F*k4*S1 - k6*S1F - k5*S1F;
ODES1K = K*k7*S1 - k9*S1K - k8*S1K;
ODES2 = k11*S2F + k9*S1K - F*k10*S2;
ODES2F = F*k10*S2 - k12*S2F - k11*S2F;

% Solution
F = (S2F*(k11 + k12))/(S2*k10);
K = (S2F*sigma1*(k11 + k12))/(S2*k7*k10);
S0 = (S2*k4*k6*k7*k10*k12*(k2 + k3)*(k8 + k9))/(k1*k3*k9*sigma1^2*(k5 + k6)*(k11 + k12));
S1 = (S2*k10*k12*(k8 + k9))/(k9*sigma1*(k11 + k12));
S1F = (S2F*k4*k12*(k8 + k9))/(k9*sigma1*(k5 + k6));
S0K = (S2F*k4*k6*k12*(k8 + k9))/(k3*k9*sigma1*(k5 + k6));
S1K = (S2F*k12)/k9;

% Check
checkF  = simplify(subs(ODEF))
checkK  = simplify(subs(ODEF))
checkS0  = simplify(subs(ODES0))
checkS0K  = simplify(subs(ODES0K))
checkS1  = simplify(subs(ODES1))
checkS1F  = simplify(subs(ODES1F))
checkS1K  = simplify(subs(ODES1K))
checkS2  = simplify(subs(ODES2))
checkS2F  = simplify(subs(ODES2F))